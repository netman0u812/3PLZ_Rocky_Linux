GW-Platform-RC3.5-DNS
════════════════════════════════════════════════════════════════
Package:   GW-Platform-RC3.5-DNS.zip
Version:   RC3.5
Role:      Optional add-on — per-tenant DNS listener, conditional
           forwarding, and DNS rewrite rule management

WHAT THIS IS
─────────────
  Per-tenant DNS listener running on a tenant-specific VIP:53.
  No shared DNS service — every listener is tenant-isolated.

  Supports two forwarding models:
    Inbound:  3rd party points conditional forwarder → tenant VIP:53
              Listener forwards DNS lookups to internal DNS servers
    Outbound: Enterprise-facing listener → forwards to 3rd party DNS
              Same model, opposite direction

  Each tenant has its own dnsmasq process, systemd unit,
  nftables table, and config directory.

PREREQUISITES
─────────────
  - GW Platform RC3.3 installed and operational
  - dnsmasq on GW nodes (installer handles this)

INSTALLATION
─────────────
  cp rc35-dns/scripts/gw-dnsctl.sh /usr/local/bin/
  chmod +x /usr/local/bin/gw-dnsctl.sh

INBOUND WORKFLOW (3rd party → internal)
─────────────────────────────────────────
  # 1. Register tenant listener
  gw-dnsctl.sh add-listener <tenant> <tenant-vip>

  # 2. Add conditional forwarding rule
  gw-dnsctl.sh add-forwarder <tenant> corp.internal <internal-dns-ip> inbound

  # 3. Add DNS rewrite rules (FQDN → SNAT inbound IP)
  gw-dnsctl.sh add-rewrite <tenant> app.corp.internal <snat-inbound-ip>

  # 4. Push to GW node and start
  gw-dnsctl.sh apply <tenant>

  # 5. Tell the 3rd party to point their conditional forwarder at <tenant-vip>:53

OUTBOUND WORKFLOW (enterprise → 3rd party)
────────────────────────────────────────────
  gw-dnsctl.sh add-listener  <tenant> <tenant-vip>
  gw-dnsctl.sh add-forwarder <tenant> thirdparty.com <3rdparty-dns-ip> outbound
  gw-dnsctl.sh apply         <tenant>

MANAGEMENT
───────────
  gw-dnsctl.sh status  <tenant>           Listener state + rule count
  gw-dnsctl.sh list                       All tenant listeners
  gw-dnsctl.sh report  <tenant>           Full config + recent query log
  gw-dnsctl.sh stop    <tenant>           Stop listener on GW node

  Update rules (takes effect after apply):
    gw-dnsctl.sh add-forwarder    <tenant> <domain> <dns-ip>
    gw-dnsctl.sh remove-forwarder <tenant> <domain>
    gw-dnsctl.sh add-rewrite      <tenant> <fqdn> <ip>
    gw-dnsctl.sh remove-rewrite   <tenant> <fqdn>
    gw-dnsctl.sh apply            <tenant>   # push updated config

NFTABLES
─────────
  Each tenant DNS listener uses its own isolated nftables table
  (gw_dns_<tenant>). Created on apply, removed on stop.
  Restricted to tenant declared source networks (Sheet 4).

QUERY LOGGING
──────────────
  All DNS queries logged per tenant on GW node:
    /var/log/gw-dns/<tenant>/dns-queries.log
  Visible via: gw-dnsctl.sh report <tenant>

SEE ALSO
─────────
  RC3-Architecture.txt section 14      — RC3.5 planned architecture
  README-GW-Platform-RC3.5-AccessProxy — Access proxy add-on
  Onboarding workbook Sheet 9          — DNS rewriting and conditional forwarding
