#!/bin/bash
# gw-dnsctl.sh v RC3.5 — Per-tenant DNS listener, conditional forwarding,
# and rewrite rule management.
#
# Every listener runs on a tenant-specific VIP:53 — no shared DNS service.
# Each tenant has its own systemd unit (gw-dnslistener@<tenant>.service)
# and its own nftables table (gw_dns_<tenant>).
#
# Supports two forwarding models:
#   Inbound:  3rd party points conditional forwarder → tenant VIP:53
#             Tenant listener forwards DNS lookups to internal DNS servers
#   Outbound: Enterprise-facing listener on tenant VIP:53
#             Forwards 3rd party domain lookups to 3rd party DNS servers
#
# Config lives on Admin Portal at /etc/gw-dns/<tenant>/
# Listener process (dnsmasq) runs on GW node (primary only)
# Config is pushed to GW node via SSH (same pattern as gw-sshproxyctl.sh)
#
# Usage:
#   gw-dnsctl.sh add-listener    <tenant> <vip>          Register tenant DNS listener
#   gw-dnsctl.sh add-forwarder   <tenant> <domain> <dns-ip> [direction]
#   gw-dnsctl.sh add-rewrite     <tenant> <fqdn> <rewrite-ip>
#   gw-dnsctl.sh remove-listener <tenant>                Remove listener + all rules
#   gw-dnsctl.sh remove-forwarder <tenant> <domain>
#   gw-dnsctl.sh remove-rewrite  <tenant> <fqdn>
#   gw-dnsctl.sh apply           <tenant>                Push config to GW node + start
#   gw-dnsctl.sh stop            <tenant>                Stop listener on GW node
#   gw-dnsctl.sh status          <tenant>                Show listener state
#   gw-dnsctl.sh list                                    List all tenant listeners
#   gw-dnsctl.sh report          <tenant>                Show full config + DNS query log

set -euo pipefail
VERSION="RC3.5"

# ── Config ────────────────────────────────────────────────────────
PORTAL_CONF="${PORTAL_CONF:-/etc/gw-admin-portal/conf/portal.conf}"
[[ -f "$PORTAL_CONF" ]] && source "$PORTAL_CONF" 2>/dev/null || true

DNS_BASE="${DNS_BASE:-/etc/gw-dns}"
DNS_PORT="${DNS_PORT:-53}"
PORTAL_KEY="${PORTAL_KEY:-/var/lib/gw-admin-portal/sshkeys/gwportal_ed25519}"
KNOWN_HOSTS="${KNOWN_HOSTS:-/etc/ssh/ssh_known_hosts}"
LOG_DIR="${LOG_DIR:-/var/log/gw-dns}"

# ── Helpers ───────────────────────────────────────────────────────
isotime() { python3 -c "from datetime import datetime,timezone; \
print(datetime.now(timezone.utc).astimezone().isoformat(timespec='seconds'))"; }
die()  { echo ""; echo "ERROR: $*" >&2; exit 1; }
info() { echo "  $*"; }
ok()   { echo "  ✓ $*"; }
warn() { echo "  ⚠ $*"; }

LOG=/var/log/gw-dnsctl.log
log() { echo "[$(isotime)] $*" >> "$LOG" 2>/dev/null || true; }

require_root() {
    [[ "${EUID:-$(id -u)}" -eq 0 ]] || die "Run as root"
}

# Get primary GW node for tenant from registry
get_primary_node() {
    local tenant="$1"
    gwreg tenant show "$tenant" 2>/dev/null \
        | grep -E '^primary_node|primary' \
        | awk '{print $NF}' | head -1
}

# Get GW node IP from registry
get_node_ip() {
    local node="$1"
    gwreg node show "$node" 2>/dev/null \
        | grep -E '^ip|^mgmt_ip' \
        | awk '{print $NF}' | head -1
}

# SSH to GW node
gw_ssh() {
    local node_ip="$1"; shift
    ssh -i "$PORTAL_KEY" \
        -o StrictHostKeyChecking=yes \
        -o UserKnownHostsFile="$KNOWN_HOSTS" \
        "root@${node_ip}" "$@"
}

# SCP to GW node
gw_scp() {
    local src="$1" dst_node="$2" dst_path="$3"
    scp -i "$PORTAL_KEY" \
        -o StrictHostKeyChecking=yes \
        -o UserKnownHostsFile="$KNOWN_HOSTS" \
        "$src" "root@${dst_node}:${dst_path}"
}

# ── Tenant config directory ───────────────────────────────────────
tenant_dir() { echo "${DNS_BASE}/$1"; }

require_tenant() {
    local tenant="$1"
    [[ -d "$(tenant_dir "$tenant")" ]] \
        || die "Tenant DNS config not found: $tenant — run add-listener first"
}

# ── Validate IP ───────────────────────────────────────────────────
validate_ip() {
    python3 -c "
import ipaddress, sys
try:
    ipaddress.ip_address('$1')
    sys.exit(0)
except:
    sys.exit(1)
" || die "Invalid IP address: $1"
}

# ── Build dnsmasq config ──────────────────────────────────────────
build_dnsmasq_conf() {
    local tenant="$1"
    local dir; dir="$(tenant_dir "$tenant")"
    local vip; vip="$(cat "${dir}/vip" 2>/dev/null)"
    local conf="${dir}/dnsmasq.conf"

    cat > "$conf" << DNSEOF
# gw-dnsctl generated dnsmasq config — tenant: ${tenant}
# Generated: $(isotime)
# DO NOT EDIT MANUALLY — managed by gw-dnsctl.sh

# Bind to tenant VIP only — never on shared interfaces
listen-address=${vip}
bind-interfaces
port=${DNS_PORT}

# No default upstream — all forwarding must be explicit
no-resolv
no-poll

# Log queries to tenant log
log-queries
log-facility=${LOG_DIR}/${tenant}/dns-queries.log

# No DHCP
no-dhcp-interface=*

DNSEOF

    # Add forwarding rules
    if [[ -f "${dir}/forwarders.conf" ]]; then
        echo "# Conditional forwarding rules" >> "$conf"
        cat "${dir}/forwarders.conf" >> "$conf"
        echo "" >> "$conf"
    fi

    # Add rewrite rules (A-record overrides)
    if [[ -f "${dir}/rewrites.conf" ]]; then
        echo "# DNS A-record rewrite rules" >> "$conf"
        cat "${dir}/rewrites.conf" >> "$conf"
        echo "" >> "$conf"
    fi

    echo "$conf"
}

# ── Build systemd unit ────────────────────────────────────────────
build_systemd_unit() {
    local tenant="$1"
    local dir; dir="$(tenant_dir "$tenant")"
    local vip; vip="$(cat "${dir}/vip" 2>/dev/null)"

    cat << UNITEOF
[Unit]
Description=GW Platform DNS Listener — tenant: ${tenant}
After=network.target
PartOf=gw-platform.target

[Service]
Type=simple
ExecStart=/usr/sbin/dnsmasq --no-daemon --conf-file=/etc/gw-dns/${tenant}/dnsmasq.conf
ExecReload=/bin/kill -HUP \$MAINPID
Restart=on-failure
RestartSec=5
StandardOutput=journal
StandardError=journal
SyslogIdentifier=gw-dns-${tenant}

[Install]
WantedBy=multi-user.target
UNITEOF
}

# ── Build nftables rules ──────────────────────────────────────────
build_nftables() {
    local tenant="$1"
    local dir; dir="$(tenant_dir "$tenant")"
    local vip; vip="$(cat "${dir}/vip" 2>/dev/null)"
    local table="gw_dns_${tenant}"

    # Read tenant source networks from registry
    local nets
    nets=$(gwreg tenant show "$tenant" 2>/dev/null \
           | grep -E 'remote_prefix|source_network' \
           | awk '{print $NF}' || echo "")

    cat << NFTEOF
# gw-dnsctl nftables — tenant: ${tenant}
# Generated: $(isotime)
table inet ${table} {
    chain input {
        type filter hook input priority 0; policy drop;
        ct state established,related accept
        iif lo accept
NFTEOF

    if [[ -z "$nets" ]]; then
        echo "        # No source networks declared — open with log"
        echo "        ip daddr ${vip} udp dport ${DNS_PORT} log prefix \"gw-dns-${tenant}: \" accept"
        echo "        ip daddr ${vip} tcp dport ${DNS_PORT} log prefix \"gw-dns-${tenant}: \" accept"
    else
        while IFS= read -r net; do
            [[ -z "$net" ]] && continue
            echo "        ip saddr ${net} ip daddr ${vip} udp dport ${DNS_PORT} accept"
            echo "        ip saddr ${net} ip daddr ${vip} tcp dport ${DNS_PORT} accept"
        done <<< "$nets"
        echo "        ip daddr ${vip} udp dport ${DNS_PORT} log prefix \"gw-dns-${tenant}-DENY: \" drop"
        echo "        ip daddr ${vip} tcp dport ${DNS_PORT} log prefix \"gw-dns-${tenant}-DENY: \" drop"
    fi

    cat << NFTEOF
    }
}
NFTEOF
}

# ══════════════════════════════════════════════════════════════════
# COMMANDS
# ══════════════════════════════════════════════════════════════════

cmd_add_listener() {
    local tenant="${1:-}" vip="${2:-}"
    [[ -n "$tenant" && -n "$vip" ]] \
        || die "Usage: gw-dnsctl.sh add-listener <tenant> <vip>"
    require_root
    validate_ip "$vip"

    local dir; dir="$(tenant_dir "$tenant")"
    mkdir -p "$dir"
    mkdir -p "${LOG_DIR}/${tenant}"

    echo "$vip" > "${dir}/vip"
    touch "${dir}/forwarders.conf"
    touch "${dir}/rewrites.conf"

    # Metadata
    cat > "${dir}/meta.conf" << METAEOF
tenant=${tenant}
vip=${vip}
created=$(isotime)
version=${VERSION}
METAEOF

    ok "DNS listener registered: tenant=${tenant} vip=${vip}"
    info "Add forwarding rules: gw-dnsctl.sh add-forwarder ${tenant} <domain> <dns-ip>"
    info "Push to GW node:      gw-dnsctl.sh apply ${tenant}"
    log "ADD_LISTENER: tenant=${tenant} vip=${vip}"
}

cmd_add_forwarder() {
    local tenant="${1:-}" domain="${2:-}" dns_ip="${3:-}" direction="${4:-inbound}"
    [[ -n "$tenant" && -n "$domain" && -n "$dns_ip" ]] \
        || die "Usage: gw-dnsctl.sh add-forwarder <tenant> <domain> <dns-ip> [inbound|outbound]"
    require_root
    require_tenant "$tenant"
    validate_ip "$dns_ip"

    local dir; dir="$(tenant_dir "$tenant")"

    # dnsmasq server directive: server=/domain/dns-ip
    local rule="server=/${domain}/${dns_ip}"
    local comment="# ${direction}: ${domain} → ${dns_ip} (added $(isotime))"

    # Check for duplicate
    if grep -q "^server=/${domain}/" "${dir}/forwarders.conf" 2>/dev/null; then
        warn "Forwarder for ${domain} already exists — updating"
        sed -i "/^server=\/${domain}\//d" "${dir}/forwarders.conf"
        sed -i "/^# .*${domain}/d" "${dir}/forwarders.conf"
    fi

    echo "$comment" >> "${dir}/forwarders.conf"
    echo "$rule"    >> "${dir}/forwarders.conf"

    ok "Forwarder added: ${domain} → ${dns_ip} (${direction})"
    info "Apply changes:  gw-dnsctl.sh apply ${tenant}"
    log "ADD_FORWARDER: tenant=${tenant} domain=${domain} dns=${dns_ip} direction=${direction}"
}

cmd_add_rewrite() {
    local tenant="${1:-}" fqdn="${2:-}" rewrite_ip="${3:-}"
    [[ -n "$tenant" && -n "$fqdn" && -n "$rewrite_ip" ]] \
        || die "Usage: gw-dnsctl.sh add-rewrite <tenant> <fqdn> <rewrite-ip>"
    require_root
    require_tenant "$tenant"
    validate_ip "$rewrite_ip"

    local dir; dir="$(tenant_dir "$tenant")"

    # dnsmasq address directive: address=/fqdn/rewrite-ip
    local rule="address=/${fqdn}/${rewrite_ip}"
    local comment="# rewrite: ${fqdn} → ${rewrite_ip} (added $(isotime))"

    if grep -q "^address=/${fqdn}/" "${dir}/rewrites.conf" 2>/dev/null; then
        warn "Rewrite for ${fqdn} already exists — updating"
        sed -i "/^address=\/${fqdn}\//d" "${dir}/rewrites.conf"
        sed -i "/^# .*${fqdn}/d" "${dir}/rewrites.conf"
    fi

    echo "$comment" >> "${dir}/rewrites.conf"
    echo "$rule"    >> "${dir}/rewrites.conf"

    ok "Rewrite added: ${fqdn} → ${rewrite_ip}"
    info "Apply changes: gw-dnsctl.sh apply ${tenant}"
    log "ADD_REWRITE: tenant=${tenant} fqdn=${fqdn} rewrite=${rewrite_ip}"
}

cmd_remove_forwarder() {
    local tenant="${1:-}" domain="${2:-}"
    [[ -n "$tenant" && -n "$domain" ]] \
        || die "Usage: gw-dnsctl.sh remove-forwarder <tenant> <domain>"
    require_root
    require_tenant "$tenant"

    local dir; dir="$(tenant_dir "$tenant")"
    sed -i "/^server=\/${domain}\//d" "${dir}/forwarders.conf"
    sed -i "/^# .*${domain}/d"        "${dir}/forwarders.conf"

    ok "Forwarder removed: ${domain}"
    info "Apply changes: gw-dnsctl.sh apply ${tenant}"
    log "REMOVE_FORWARDER: tenant=${tenant} domain=${domain}"
}

cmd_remove_rewrite() {
    local tenant="${1:-}" fqdn="${2:-}"
    [[ -n "$tenant" && -n "$fqdn" ]] \
        || die "Usage: gw-dnsctl.sh remove-rewrite <tenant> <fqdn>"
    require_root
    require_tenant "$tenant"

    local dir; dir="$(tenant_dir "$tenant")"
    sed -i "/^address=\/${fqdn}\//d" "${dir}/rewrites.conf"
    sed -i "/^# .*${fqdn}/d"         "${dir}/rewrites.conf"

    ok "Rewrite removed: ${fqdn}"
    info "Apply changes: gw-dnsctl.sh apply ${tenant}"
    log "REMOVE_REWRITE: tenant=${tenant} fqdn=${fqdn}"
}

cmd_apply() {
    local tenant="${1:-}"
    [[ -n "$tenant" ]] || die "Usage: gw-dnsctl.sh apply <tenant>"
    require_root
    require_tenant "$tenant"

    local dir; dir="$(tenant_dir "$tenant")"
    local vip; vip="$(cat "${dir}/vip")"

    echo ""
    info "Applying DNS listener config: tenant=${tenant}"

    # Get primary GW node
    local node; node="$(get_primary_node "$tenant")"
    [[ -n "$node" ]] || die "Cannot determine primary node for tenant: ${tenant}"
    local node_ip; node_ip="$(get_node_ip "$node")"
    [[ -n "$node_ip" ]] || die "Cannot determine IP for node: ${node}"

    # Build dnsmasq config
    build_dnsmasq_conf "$tenant" > /dev/null

    # Build systemd unit
    build_systemd_unit "$tenant" > "${dir}/gw-dnslistener@${tenant}.service"

    # Build nftables
    build_nftables "$tenant" > "${dir}/nftables.conf"

    # Push config to GW node
    info "Pushing config to ${node} (${node_ip})..."
    gw_ssh "$node_ip" "mkdir -p /etc/gw-dns/${tenant} ${LOG_DIR}/${tenant}"
    gw_scp "${dir}/dnsmasq.conf"   "$node_ip" "/etc/gw-dns/${tenant}/dnsmasq.conf"
    gw_scp "${dir}/nftables.conf"  "$node_ip" "/etc/gw-dns/${tenant}/nftables.conf"
    gw_scp "${dir}/gw-dnslistener@${tenant}.service" \
           "$node_ip" "/etc/systemd/system/gw-dnslistener@${tenant}.service"
    ok "Config pushed"

    # Apply nftables and start service on GW node
    gw_ssh "$node_ip" "
        set -e
        # Apply nftables (remove old table first if exists)
        nft delete table inet gw_dns_${tenant} 2>/dev/null || true
        nft -f /etc/gw-dns/${tenant}/nftables.conf

        # Ensure dnsmasq is installed
        command -v dnsmasq >/dev/null 2>&1 || dnf install -y dnsmasq

        # Enable and start service
        systemctl daemon-reload
        systemctl enable --now gw-dnslistener@${tenant}.service
        systemctl is-active gw-dnslistener@${tenant}.service
    "

    ok "DNS listener active: tenant=${tenant} vip=${vip}:${DNS_PORT}"
    info "Status: gw-dnsctl.sh status ${tenant}"
    log "APPLY: tenant=${tenant} vip=${vip} node=${node}"
}

cmd_stop() {
    local tenant="${1:-}"
    [[ -n "$tenant" ]] || die "Usage: gw-dnsctl.sh stop <tenant>"
    require_root

    local node; node="$(get_primary_node "$tenant")"
    [[ -n "$node" ]] || die "Cannot determine primary node for tenant: ${tenant}"
    local node_ip; node_ip="$(get_node_ip "$node")"

    gw_ssh "$node_ip" "
        systemctl disable --now gw-dnslistener@${tenant}.service 2>/dev/null || true
        nft delete table inet gw_dns_${tenant} 2>/dev/null || true
    "

    ok "DNS listener stopped: tenant=${tenant}"
    log "STOP: tenant=${tenant}"
}

cmd_remove_listener() {
    local tenant="${1:-}"
    [[ -n "$tenant" ]] || die "Usage: gw-dnsctl.sh remove-listener <tenant>"
    require_root

    local dir; dir="$(tenant_dir "$tenant")"
    [[ -d "$dir" ]] || die "No DNS config found for tenant: ${tenant}"

    warn "Removing DNS listener for tenant: ${tenant}"
    read -r -p "  Confirm removal? [y/N] " confirm
    [[ "${confirm,,}" == "y" ]] || { echo "  Cancelled."; exit 0; }

    # Stop on GW node first
    cmd_stop "$tenant" 2>/dev/null || true

    # Remove portal config
    rm -rf "$dir"
    ok "DNS listener removed: tenant=${tenant}"
    log "REMOVE_LISTENER: tenant=${tenant}"
}

cmd_status() {
    local tenant="${1:-}"
    [[ -n "$tenant" ]] || die "Usage: gw-dnsctl.sh status <tenant>"

    local dir; dir="$(tenant_dir "$tenant")"
    [[ -d "$dir" ]] || die "No DNS config found for tenant: ${tenant}"

    local vip; vip="$(cat "${dir}/vip" 2>/dev/null || echo 'unknown')"

    echo ""
    echo "=== DNS Listener Status: ${tenant} ==="
    echo ""
    info "VIP:        ${vip}:${DNS_PORT}"
    info "Config:     ${dir}"

    # Forwarders
    local fwd_count; fwd_count=$(grep -c "^server=" "${dir}/forwarders.conf" 2>/dev/null || echo 0)
    info "Forwarders: ${fwd_count} rule(s)"
    grep "^server=" "${dir}/forwarders.conf" 2>/dev/null | while IFS= read -r line; do
        info "  ${line}"
    done

    # Rewrites
    local rw_count; rw_count=$(grep -c "^address=" "${dir}/rewrites.conf" 2>/dev/null || echo 0)
    info "Rewrites:   ${rw_count} rule(s)"
    grep "^address=" "${dir}/rewrites.conf" 2>/dev/null | while IFS= read -r line; do
        info "  ${line}"
    done

    # Check GW node status
    local node; node="$(get_primary_node "$tenant" 2>/dev/null || echo '')"
    if [[ -n "$node" ]]; then
        local node_ip; node_ip="$(get_node_ip "$node" 2>/dev/null || echo '')"
        if [[ -n "$node_ip" ]]; then
            local svc_state
            svc_state=$(gw_ssh "$node_ip" \
                "systemctl is-active gw-dnslistener@${tenant}.service 2>/dev/null" \
                || echo "unknown")
            info "GW node:    ${node} (${node_ip}) — service: ${svc_state}"
        fi
    fi
    echo ""
}

cmd_list() {
    echo ""
    echo "=== Tenant DNS Listeners ==="
    echo ""
    printf "  %-20s %-18s %-8s %s\n" "Tenant" "VIP" "Port" "Forwarders"
    printf "  %-20s %-18s %-8s %s\n" "------" "---" "----" "----------"

    local found=0
    for dir in "${DNS_BASE}"/*/; do
        [[ -d "$dir" ]] || continue
        local tenant; tenant="$(basename "$dir")"
        local vip; vip="$(cat "${dir}/vip" 2>/dev/null || echo 'unknown')"
        local fwd_count; fwd_count=$(grep -c "^server=" "${dir}/forwarders.conf" 2>/dev/null || echo 0)
        printf "  %-20s %-18s %-8s %s\n" "$tenant" "$vip" "$DNS_PORT" "${fwd_count} rule(s)"
        found=$(( found + 1 ))
    done

    echo ""
    [[ $found -eq 0 ]] && info "No tenant DNS listeners configured" \
                       || info "Total: ${found} tenant(s)"
    echo ""
}

cmd_report() {
    local tenant="${1:-}"
    [[ -n "$tenant" ]] || die "Usage: gw-dnsctl.sh report <tenant>"

    local dir; dir="$(tenant_dir "$tenant")"
    [[ -d "$dir" ]] || die "No DNS config found for tenant: ${tenant}"

    echo ""
    echo "════════════════════════════════════════════════════════"
    echo "  DNS LISTENER REPORT — ${tenant}"
    echo "  Generated: $(isotime)"
    echo "════════════════════════════════════════════════════════"
    echo ""
    echo "--- VIP ---"
    cat "${dir}/vip" 2>/dev/null
    echo ""
    echo "--- Forwarding Rules ---"
    grep -v "^#" "${dir}/forwarders.conf" 2>/dev/null | grep -v "^$" || echo "(none)"
    echo ""
    echo "--- Rewrite Rules ---"
    grep -v "^#" "${dir}/rewrites.conf" 2>/dev/null | grep -v "^$" || echo "(none)"
    echo ""
    echo "--- dnsmasq Config ---"
    cat "${dir}/dnsmasq.conf" 2>/dev/null || echo "(not generated — run apply)"
    echo ""
    echo "--- Recent DNS Queries ---"
    tail -20 "${LOG_DIR}/${tenant}/dns-queries.log" 2>/dev/null || echo "(no query log)"
    echo ""
}

# ── Dispatch ──────────────────────────────────────────────────────
case "${1:-}" in
    add-listener)     cmd_add_listener    "${2:-}" "${3:-}" ;;
    add-forwarder)    cmd_add_forwarder   "${2:-}" "${3:-}" "${4:-}" "${5:-inbound}" ;;
    add-rewrite)      cmd_add_rewrite     "${2:-}" "${3:-}" "${4:-}" ;;
    remove-listener)  cmd_remove_listener "${2:-}" ;;
    remove-forwarder) cmd_remove_forwarder "${2:-}" "${3:-}" ;;
    remove-rewrite)   cmd_remove_rewrite  "${2:-}" "${3:-}" ;;
    apply)            cmd_apply           "${2:-}" ;;
    stop)             cmd_stop            "${2:-}" ;;
    status)           cmd_status          "${2:-}" ;;
    list)             cmd_list ;;
    report)           cmd_report          "${2:-}" ;;
    -h|--help|help|"")
        echo ""
        echo "gw-dnsctl.sh ${VERSION} — Per-tenant DNS listener management"
        echo ""
        echo "Usage:"
        echo "  gw-dnsctl.sh add-listener    <tenant> <vip>"
        echo "  gw-dnsctl.sh add-forwarder   <tenant> <domain> <dns-ip> [inbound|outbound]"
        echo "  gw-dnsctl.sh add-rewrite     <tenant> <fqdn> <rewrite-ip>"
        echo "  gw-dnsctl.sh remove-listener <tenant>"
        echo "  gw-dnsctl.sh remove-forwarder <tenant> <domain>"
        echo "  gw-dnsctl.sh remove-rewrite  <tenant> <fqdn>"
        echo "  gw-dnsctl.sh apply           <tenant>   Push config to GW node + start"
        echo "  gw-dnsctl.sh stop            <tenant>   Stop listener on GW node"
        echo "  gw-dnsctl.sh status          <tenant>   Show listener state"
        echo "  gw-dnsctl.sh list                       List all tenant listeners"
        echo "  gw-dnsctl.sh report          <tenant>   Full config + query log"
        echo ""
        echo "Typical inbound workflow (3rd party → internal):"
        echo "  gw-dnsctl.sh add-listener   <tenant> <tenant-vip>"
        echo "  gw-dnsctl.sh add-forwarder  <tenant> corp.internal <internal-dns-ip> inbound"
        echo "  gw-dnsctl.sh add-rewrite    <tenant> app.corp.internal <snat-inbound-ip>"
        echo "  gw-dnsctl.sh apply          <tenant>"
        echo ""
        echo "Typical outbound workflow (enterprise → 3rd party):"
        echo "  gw-dnsctl.sh add-listener   <tenant> <tenant-vip>"
        echo "  gw-dnsctl.sh add-forwarder  <tenant> thirdparty.com <3rdparty-dns-ip> outbound"
        echo "  gw-dnsctl.sh apply          <tenant>"
        echo ""
        ;;
    *) die "Unknown command: ${1} — run gw-dnsctl.sh help" ;;
esac
