GW-Platform-RC3.4-AdminTOTP
════════════════════════════════════════════════════════════════
Package:   GW-Platform-RC3.4-AdminTOTP.zip
Version:   RC3.4

NOTE: As of RC3.4, gw-totp-setup.sh (RC3.4) is included in the
core GW-Platform-RC3-Build.zip. This package is an upgrade shim
for existing RC3.3 installations only.

FOR NEW INSTALLS
─────────────────
  gw-totp-setup.sh RC3.4 is already in the core build.
  Proceed directly to first-time setup:

    gw-totp-setup.sh install-pam       # Once per portal
    gw-totp-setup.sh enroll <user>     # Per admin user
    gw-totp-setup.sh verify <user>     # Confirm before logout

FOR EXISTING RC3.3 INSTALLATIONS (upgrade)
───────────────────────────────────────────
  1. Copy updated script:
       cp rc34-admintotp/scripts/gw-totp-setup.sh /usr/local/bin/
       chmod +x /usr/local/bin/gw-totp-setup.sh

  2. If TOTP not yet configured on this portal:
       gw-totp-setup.sh install-pam

  3. Re-enroll any users if needed:
       gw-totp-setup.sh list            # Check current enrollment state
       gw-totp-setup.sh reenroll <user> # If re-enrollment needed

  Existing ~/.google_authenticator files are preserved — enrolled
  users do not need to re-enroll unless you choose to.

COMMANDS
─────────
  gw-totp-setup.sh enroll      <user>   Enroll new admin user (QR to terminal)
  gw-totp-setup.sh reenroll    <user>   Re-enroll (lost authenticator)
  gw-totp-setup.sh revoke      <user>   Revoke TOTP access
  gw-totp-setup.sh verify      <user>   Test TOTP without a login attempt
  gw-totp-setup.sh list                 List all enrolled users
  gw-totp-setup.sh status      <user>   Enrollment status + PAM check
  gw-totp-setup.sh install-pam          Configure PAM + sshd (once per portal)

OPTIONAL DEPENDENCIES
──────────────────────
  dnf install -y oathtool
  pip3 install qrcode --break-system-packages

  oathtool:  improves TOTP code validation accuracy
  qrcode:    enables ASCII QR rendering in terminal
             (falls back to manual key entry if not installed)

SEE ALSO
─────────
  RC3-Architecture.txt section 8   — Portal authentication model
  README-AdminPortal.txt           — Admin portal installation
