GW-Platform-RC3.5-AccessProxy
════════════════════════════════════════════════════════════════
Package:   GW-Platform-RC3.5-AccessProxy.zip
Version:   RC3.5
Role:      Optional add-on — per-tenant managed SSH/SFTP access proxy
           with TOTP authentication and transparent credential injection

WHAT THIS IS
─────────────
  A native SSH/SFTP terminating proxy — completely separate from the
  existing gw-sshproxy passthrough model (which is unchanged).

  For each tenant:
    - Dedicated proxy process on GW node primary (tenant VIP:22)
    - User authenticates with email + TOTP code (OTP retrieved via HTTP GET)
    - Per-service ACL checked at connection time
    - Downstream credentials fetched from GPG vault transparently
    - User never sees internal host credentials
    - Full session audit log per tenant per service

  Every component is per-tenant — no shared processes.

PREREQUISITES
─────────────
  - GW Platform RC3.3 installed and operational
  - GW Platform RC3.4-CertDeliver installed (mTLS certs issued to users)
  - python3, pip3, gpg on Admin Portal and GW nodes
  - paramiko installed on GW nodes (installer handles this)

SCRIPTS IN THIS PACKAGE
────────────────────────
  gw-accessproxyctl.sh  Portal-side proxy management (apply/stop/status/logs)
  gw-accessvaultctl.sh  Per-tenant GPG credential store management
  gw-accessctl.sh       Per-service user ACL management
  gw-otpctl.sh          TOTP provisioning and HTTP OTP endpoint management

INSTALLATION
─────────────
  cp rc35-accessproxy/scripts/*.sh /usr/local/bin/
  chmod +x /usr/local/bin/gw-access*.sh /usr/local/bin/gw-otpctl.sh

FULL PROVISIONING WORKFLOW (per tenant)
─────────────────────────────────────────
  1. Initialise vault:
       gw-accessvaultctl.sh init <tenant>

  2. Add internal service credentials to vault:
       gw-accessvaultctl.sh add <tenant> <email> <service> <host> <user> <pass>
       (repeat for each user/service combination)

  3. Define service instances:
       gw-accessctl.sh add-service <tenant> ssh-terminal-1 <internal-host> 22 ssh
       gw-accessctl.sh add-service <tenant> sftp-store-1   <internal-host> 22 sftp

  4. Assign users to services:
       gw-accessctl.sh add-user <tenant> ssh-terminal-1 alice@example.com
       gw-accessctl.sh import-list <tenant> sftp-store-1 /tmp/sftp-users.txt

  5. Provision TOTP secrets (one per user):
       gw-otpctl.sh provision <tenant> alice@example.com
       (or bulk: while read e; do gw-otpctl.sh provision <tenant> $e; done < users.txt)

  6. Deploy OTP endpoint to GW node:
       gw-otpctl.sh apply <tenant>

  7. Deploy access proxy to GW node:
       gw-accessproxyctl.sh apply <tenant>

  8. Verify:
       gw-accessproxyctl.sh status <tenant>
       gw-otpctl.sh status <tenant>
       gw-otpctl.sh test <tenant> <email>   # check OTP endpoint works

USER CONNECTION FLOW
─────────────────────
  # Step 1 — retrieve current OTP
  curl http://<tenant-vip>:8444/otp/alice@example.com
  # Returns: 123456

  # Step 2 — SSH using email + OTP
  ssh alice@example.com@<tenant-vip>
  # Password: 123456

  # For SFTP:
  sftp alice@example.com@<tenant-vip>

NFTABLES
─────────
  Each component uses its own isolated nftables table:
    gw_accessproxy_<tenant>  — SSH/SFTP proxy port
    gw_otp_<tenant>          — OTP HTTP endpoint port
  Both are created on apply and removed on stop.
  Source networks restricted to tenant declared networks (Sheet 4).

ACL MANAGEMENT
───────────────
  Add user to service:     gw-accessctl.sh add-user    <tenant> <service> <email>
  Remove user:             gw-accessctl.sh remove-user <tenant> <service> <email>
  View access matrix:      gw-accessctl.sh access-matrix <tenant>
  Bulk import from file:   gw-accessctl.sh import-list  <tenant> <service> <file>

VAULT MANAGEMENT
─────────────────
  List entries (no passwords): gw-accessvaultctl.sh list   <tenant>
  Rotate a password:           gw-accessvaultctl.sh rotate <tenant> <email> <service> <new-pass>
  Verify vault integrity:      gw-accessvaultctl.sh verify <tenant>
  Backup vault:                gw-accessvaultctl.sh backup <tenant>
  Re-key vault:                gw-accessvaultctl.sh rekey  <tenant>

SESSION AUDIT LOG
──────────────────
  gw-accessproxyctl.sh logs <tenant>
  Live on GW node: /var/log/gw-access/<tenant>/sessions.log
  Records: AUTH_OK/AUTH_FAIL, ACL_ALLOW/ACL_DENY, SESSION_START/SESSION_END

SEE ALSO
─────────
  RC3-Architecture.txt section 14  — RC3.5 planned architecture
  README-GW-Platform-RC3.5-DNS.txt — DNS listener add-on
  RC3-Runbook.txt                  — Day-2 operations
