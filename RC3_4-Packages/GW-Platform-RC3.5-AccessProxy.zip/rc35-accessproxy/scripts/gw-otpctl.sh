#!/bin/bash
# gw-otpctl.sh v RC3.5 — Per-tenant TOTP provisioning and HTTP OTP endpoint.
#
# TOTP secrets provisioned per user at cert issuance time.
# HTTP GET endpoint returns the current 6-digit OTP code:
#   GET http://<tenant-vip>:<otp-port>/otp/<email>
#
# Endpoint runs on GW node (primary) on tenant VIP only.
# nftables restricted to tenant source networks.
# Secrets stored at: /etc/gw-accessproxy/<tenant>/totp/<email>.secret
#
# Usage:
#   gw-otpctl.sh provision  <tenant> <email>     Create TOTP secret for user
#   gw-otpctl.sh revoke     <tenant> <email>     Remove TOTP secret
#   gw-otpctl.sh list       <tenant>             List provisioned users
#   gw-otpctl.sh status     <tenant>             Endpoint status on GW node
#   gw-otpctl.sh apply      <tenant>             Push secrets + start endpoint
#   gw-otpctl.sh stop       <tenant>             Stop endpoint on GW node
#   gw-otpctl.sh test       <tenant> <email>     Show current OTP (engineer use)

set -euo pipefail
VERSION="RC3.5"

PORTAL_CONF="${PORTAL_CONF:-/etc/gw-admin-portal/conf/portal.conf}"
[[ -f "$PORTAL_CONF" ]] && source "$PORTAL_CONF" 2>/dev/null || true

ACCESS_BASE="${ACCESS_BASE:-/etc/gw-accessproxy}"
OTP_PORT="${OTP_PORT:-8444}"
PORTAL_KEY="${PORTAL_KEY:-/var/lib/gw-admin-portal/sshkeys/gwportal_ed25519}"
KNOWN_HOSTS="${KNOWN_HOSTS:-/etc/ssh/ssh_known_hosts}"
LOG=/var/log/gw-otpctl.log

isotime() { python3 -c "from datetime import datetime,timezone; \
print(datetime.now(timezone.utc).astimezone().isoformat(timespec='seconds'))"; }
die()  { echo ""; echo "ERROR: $*" >&2; exit 1; }
ok()   { echo "  ✓ $*"; }
info() { echo "  $*"; }
warn() { echo "  ⚠ $*"; }
log()  { echo "[$(isotime)] $*" >> "$LOG" 2>/dev/null || true; }

require_root() { [[ "${EUID:-$(id -u)}" -eq 0 ]] || die "Run as root"; }

totp_dir()    { echo "${ACCESS_BASE}/$1/totp"; }
totp_secret() { echo "${ACCESS_BASE}/$1/totp/$2.secret"; }

get_primary_node() { gwreg tenant show "$1" 2>/dev/null \
    | grep -E '^primary_node|primary' | awk '{print $NF}' | head -1; }
get_node_ip()      { gwreg node show "$1" 2>/dev/null \
    | grep -E '^ip|^mgmt_ip' | awk '{print $NF}' | head -1; }

gw_ssh() { local node_ip="$1"; shift
    ssh -i "$PORTAL_KEY" -o StrictHostKeyChecking=yes \
        -o UserKnownHostsFile="$KNOWN_HOSTS" "root@${node_ip}" "$@"; }

generate_totp_secret() {
    python3 -c "import os,base64; \
print(base64.b32encode(os.urandom(20)).decode().rstrip('='))"
}

get_vip() {
    cat "${ACCESS_BASE}/$1/vip" 2>/dev/null \
        || gwreg tenant show "$1" 2>/dev/null \
            | grep -E '^access_proxy_vip|^loopback_vip' \
            | awk '{print $NF}' | head -1 \
        || die "Cannot determine VIP for tenant: $1"
}

# ── Build OTP endpoint Python server ─────────────────────────────
build_otp_server() {
    local tenant="$1" vip="$2"
    cat << PYEOF
#!/usr/bin/env python3
# gw-otpctl OTP endpoint — tenant: ${tenant}
# Generated: $(isotime)
import http.server, hmac, hashlib, struct, time, base64, os, json, logging

logging.basicConfig(
    filename='/var/log/gw-access/${tenant}/otp-requests.log',
    level=logging.INFO,
    format='%(asctime)s %(message)s'
)

TOTP_DIR = '/etc/gw-accessproxy/${tenant}/totp'
HOST     = '${vip}'
PORT     = ${OTP_PORT}

def totp(secret_b32, offset=0):
    try:
        key = base64.b32decode(secret_b32.upper() + '=' * (-len(secret_b32) % 8))
    except Exception:
        return None
    t   = int((time.time() + offset * 30) / 30)
    msg = struct.pack('>Q', t)
    h   = hmac.new(key, msg, hashlib.sha1).digest()
    o   = h[-1] & 0xf
    code = (struct.unpack('>I', h[o:o+4])[0] & 0x7fffffff) % 1000000
    return f'{code:06d}'

class OTPHandler(http.server.BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):
        pass  # suppress default access log, we do our own

    def do_GET(self):
        parts = self.path.strip('/').split('/')
        if len(parts) != 2 or parts[0] != 'otp':
            self.send_response(404)
            self.end_headers()
            return

        email     = parts[1]
        secret_f  = os.path.join(TOTP_DIR, f'{email}.secret')
        client_ip = self.client_address[0]

        if not os.path.exists(secret_f):
            logging.warning(f'NOT_PROVISIONED ip={client_ip} email={email}')
            self.send_response(404)
            self.end_headers()
            self.wfile.write(b'not found')
            return

        with open(secret_f) as f:
            secret = f.read().strip()

        code = totp(secret)
        if code is None:
            logging.error(f'TOTP_ERROR ip={client_ip} email={email}')
            self.send_response(500)
            self.end_headers()
            return

        logging.info(f'OTP_SERVED ip={client_ip} email={email}')
        self.send_response(200)
        self.send_header('Content-Type', 'text/plain')
        self.end_headers()
        self.wfile.write(code.encode())

    def do_HEAD(self):
        self.send_response(200)
        self.end_headers()

os.makedirs('/var/log/gw-access/${tenant}', exist_ok=True)
server = http.server.HTTPServer((HOST, PORT), OTPHandler)
logging.info(f'OTP endpoint starting: {HOST}:{PORT} tenant=${tenant}')
server.serve_forever()
PYEOF
}

# ── Build systemd unit for OTP endpoint ──────────────────────────
build_otp_unit() {
    local tenant="$1"
    cat << UNITEOF
[Unit]
Description=GW Platform OTP Endpoint — tenant: ${tenant}
After=network.target
PartOf=gw-platform.target

[Service]
Type=simple
ExecStart=/usr/bin/python3 /etc/gw-accessproxy/${tenant}/otp-server.py
Restart=on-failure
RestartSec=5
StandardOutput=journal
StandardError=journal
SyslogIdentifier=gw-otp-${tenant}

[Install]
WantedBy=multi-user.target
UNITEOF
}

# ── Build nftables for OTP endpoint ──────────────────────────────
build_otp_nftables() {
    local tenant="$1" vip="$2"
    local table="gw_otp_${tenant}"
    local nets
    nets=$(gwreg tenant show "$tenant" 2>/dev/null \
        | grep -E 'remote_prefix|source_network' \
        | awk '{print $NF}' || echo "")

    cat << NFTEOF
table inet ${table} {
    chain input {
        type filter hook input priority 0; policy drop;
        ct state established,related accept
        iif lo accept
NFTEOF
    if [[ -z "$nets" ]]; then
        echo "        ip daddr ${vip} tcp dport ${OTP_PORT} log prefix \"gw-otp-${tenant}: \" accept"
    else
        while IFS= read -r net; do
            [[ -z "$net" ]] && continue
            echo "        ip saddr ${net} ip daddr ${vip} tcp dport ${OTP_PORT} accept"
        done <<< "$nets"
        echo "        ip daddr ${vip} tcp dport ${OTP_PORT} log prefix \"gw-otp-${tenant}-DENY: \" drop"
    fi
    echo "    }"
    echo "}"
}

# ══════════════════════════════════════════════════════════════════
# COMMANDS
# ══════════════════════════════════════════════════════════════════

cmd_provision() {
    local tenant="${1:-}" email="${2:-}"
    [[ -n "$tenant" && -n "$email" ]] \
        || die "Usage: gw-otpctl.sh provision <tenant> <email>"
    require_root

    mkdir -p "$(totp_dir "$tenant")"
    chmod 700 "$(totp_dir "$tenant")"

    local sf; sf="$(totp_secret "$tenant" "$email")"

    if [[ -f "$sf" ]]; then
        warn "TOTP secret already exists for ${email} — re-provisioning"
        cp "$sf" "${sf}.bak.$(date +%Y%m%d%H%M%S)"
    fi

    local secret; secret="$(generate_totp_secret)"
    echo "$secret" > "$sf"
    chmod 600 "$sf"

    ok "TOTP provisioned: ${email} (tenant: ${tenant})"
    info "Push to GW node: gw-otpctl.sh apply ${tenant}"
    log "PROVISION: tenant=${tenant} email=${email}"
}

cmd_revoke() {
    local tenant="${1:-}" email="${2:-}"
    [[ -n "$tenant" && -n "$email" ]] \
        || die "Usage: gw-otpctl.sh revoke <tenant> <email>"
    require_root

    local sf; sf="$(totp_secret "$tenant" "$email")"
    [[ -f "$sf" ]] || { warn "No TOTP secret found for ${email}"; exit 0; }

    cp "$sf" "${sf}.revoked.$(date +%Y%m%d%H%M%S)"
    rm -f "$sf"

    ok "TOTP revoked: ${email}"
    info "Apply changes: gw-otpctl.sh apply ${tenant}"
    log "REVOKE: tenant=${tenant} email=${email}"
}

cmd_list() {
    local tenant="${1:-}"
    [[ -n "$tenant" ]] || die "Usage: gw-otpctl.sh list <tenant>"

    local tdir; tdir="$(totp_dir "$tenant")"
    echo ""
    echo "=== Provisioned TOTP Users: ${tenant} ==="
    echo ""

    local found=0
    for sf in "${tdir}/"*.secret; do
        [[ -f "$sf" ]] || continue
        local email; email=$(basename "$sf" .secret)
        local modified; modified=$(stat -c '%y' "$sf" 2>/dev/null | cut -d'.' -f1 || echo "unknown")
        info "${email}  (provisioned: ${modified})"
        found=$(( found + 1 ))
    done

    echo ""
    [[ $found -eq 0 ]] && info "No users provisioned" || info "Total: ${found}"
    echo ""
}

cmd_test() {
    local tenant="${1:-}" email="${2:-}"
    [[ -n "$tenant" && -n "$email" ]] \
        || die "Usage: gw-otpctl.sh test <tenant> <email>"

    local sf; sf="$(totp_secret "$tenant" "$email")"
    [[ -f "$sf" ]] || die "No TOTP secret for ${email} in tenant ${tenant}"

    local secret; secret="$(cat "$sf")"
    local code
    code=$(python3 -c "
import hmac, hashlib, struct, time, base64
secret='${secret}'
key = base64.b32decode(secret.upper() + '=' * (-len(secret) % 8))
t   = int(time.time() / 30)
msg = struct.pack('>Q', t)
h   = hmac.new(key, msg, hashlib.sha1).digest()
o   = h[-1] & 0xf
code = (struct.unpack('>I', h[o:o+4])[0] & 0x7fffffff) % 1000000
print(f'{code:06d}')
")

    echo ""
    info "Current OTP for ${email}: ${code}"
    info "(valid for ~$(python3 -c "import time; print(30 - int(time.time()) % 30)") more seconds)"
    echo ""
}

cmd_apply() {
    local tenant="${1:-}"
    [[ -n "$tenant" ]] || die "Usage: gw-otpctl.sh apply <tenant>"
    require_root

    local vip; vip="$(get_vip "$tenant")"
    local node; node="$(get_primary_node "$tenant")"
    [[ -n "$node" ]] || die "Cannot determine primary node for tenant: ${tenant}"
    local node_ip; node_ip="$(get_node_ip "$node")"

    echo ""
    info "Deploying OTP endpoint: tenant=${tenant} vip=${vip}:${OTP_PORT}"

    local tdir; tdir="$(totp_dir "$tenant")"
    local base; base="${ACCESS_BASE}/${tenant}"

    # Write server script and systemd unit
    build_otp_server   "$tenant" "$vip" > "${base}/otp-server.py"
    build_otp_unit     "$tenant"        > "${base}/gw-otpendpoint@${tenant}.service"
    build_otp_nftables "$tenant" "$vip" > "${base}/otp-nftables.conf"

    # Push to GW node
    gw_ssh "$node_ip" "mkdir -p /etc/gw-accessproxy/${tenant}/totp \
                                /var/log/gw-access/${tenant}"

    # Push secrets
    for sf in "${tdir}/"*.secret; do
        [[ -f "$sf" ]] || continue
        local email; email=$(basename "$sf" .secret)
        scp -q -i "$PORTAL_KEY" \
            -o StrictHostKeyChecking=yes \
            -o UserKnownHostsFile="$KNOWN_HOSTS" \
            "$sf" "root@${node_ip}:/etc/gw-accessproxy/${tenant}/totp/${email}.secret"
    done

    # Push server + unit + nftables
    for f in otp-server.py "gw-otpendpoint@${tenant}.service" otp-nftables.conf; do
        scp -q -i "$PORTAL_KEY" \
            -o StrictHostKeyChecking=yes \
            -o UserKnownHostsFile="$KNOWN_HOSTS" \
            "${base}/${f}" "root@${node_ip}:/etc/gw-accessproxy/${tenant}/${f}"
    done

    gw_ssh "$node_ip" "
        set -e
        cp /etc/gw-accessproxy/${tenant}/gw-otpendpoint@${tenant}.service \
           /etc/systemd/system/gw-otpendpoint@${tenant}.service

        nft delete table inet gw_otp_${tenant} 2>/dev/null || true
        nft -f /etc/gw-accessproxy/${tenant}/otp-nftables.conf

        systemctl daemon-reload
        systemctl enable --now gw-otpendpoint@${tenant}.service
        systemctl is-active gw-otpendpoint@${tenant}.service
    "

    ok "OTP endpoint active: ${vip}:${OTP_PORT}/otp/<email>"
    log "APPLY: tenant=${tenant} vip=${vip} node=${node}"
}

cmd_stop() {
    local tenant="${1:-}"
    [[ -n "$tenant" ]] || die "Usage: gw-otpctl.sh stop <tenant>"
    require_root

    local node; node="$(get_primary_node "$tenant")"
    local node_ip; node_ip="$(get_node_ip "$node")"

    gw_ssh "$node_ip" "
        systemctl disable --now gw-otpendpoint@${tenant}.service 2>/dev/null || true
        nft delete table inet gw_otp_${tenant} 2>/dev/null || true
    "
    ok "OTP endpoint stopped: tenant=${tenant}"
    log "STOP: tenant=${tenant}"
}

cmd_status() {
    local tenant="${1:-}"
    [[ -n "$tenant" ]] || die "Usage: gw-otpctl.sh status <tenant>"

    local tdir; tdir="$(totp_dir "$tenant")"
    local count; count=$(ls "${tdir}"/*.secret 2>/dev/null | wc -l || echo 0)
    local vip; vip="$(get_vip "$tenant" 2>/dev/null || echo 'unknown')"

    echo ""
    echo "=== OTP Endpoint Status: ${tenant} ==="
    echo ""
    info "VIP:        ${vip}:${OTP_PORT}"
    info "Provisioned: ${count} user(s)"

    local node; node="$(get_primary_node "$tenant" 2>/dev/null || echo '')"
    if [[ -n "$node" ]]; then
        local node_ip; node_ip="$(get_node_ip "$node" 2>/dev/null || echo '')"
        if [[ -n "$node_ip" ]]; then
            local svc_state
            svc_state=$(gw_ssh "$node_ip" \
                "systemctl is-active gw-otpendpoint@${tenant}.service 2>/dev/null" \
                || echo "unknown")
            info "GW node:    ${node} (${node_ip}) — service: ${svc_state}"
        fi
    fi
    echo ""
}

# ── Dispatch ──────────────────────────────────────────────────────
case "${1:-}" in
    provision) cmd_provision "${2:-}" "${3:-}" ;;
    revoke)    cmd_revoke    "${2:-}" "${3:-}" ;;
    list)      cmd_list      "${2:-}" ;;
    test)      cmd_test      "${2:-}" "${3:-}" ;;
    apply)     cmd_apply     "${2:-}" ;;
    stop)      cmd_stop      "${2:-}" ;;
    status)    cmd_status    "${2:-}" ;;
    -h|--help|help|"")
        echo ""
        echo "gw-otpctl.sh ${VERSION} — Per-tenant TOTP provisioning and OTP endpoint"
        echo ""
        echo "Usage:"
        echo "  gw-otpctl.sh provision <tenant> <email>   Create TOTP secret for user"
        echo "  gw-otpctl.sh revoke    <tenant> <email>   Remove TOTP secret"
        echo "  gw-otpctl.sh list      <tenant>           List provisioned users"
        echo "  gw-otpctl.sh test      <tenant> <email>   Show current OTP code (engineer)"
        echo "  gw-otpctl.sh apply     <tenant>           Push secrets + start endpoint on GW node"
        echo "  gw-otpctl.sh stop      <tenant>           Stop endpoint on GW node"
        echo "  gw-otpctl.sh status    <tenant>           Show endpoint status"
        echo ""
        echo "User retrieves OTP via:"
        echo "  curl http://<tenant-vip>:${OTP_PORT}/otp/<email>"
        echo "  wget -qO- http://<tenant-vip>:${OTP_PORT}/otp/<email>"
        echo ""
        ;;
    *) die "Unknown command: ${1} — run gw-otpctl.sh help" ;;
esac
