#!/bin/bash
# gw-accessctl.sh v RC3.5 — Per-service user ACL and service instance management.
#
# Each service instance has a named user list (flat file, one email per line).
# Access decision made at connection time by gw-accessproxy:
#   email in list = allow, absent = reject
#
# Service config at: /etc/gw-accessproxy/<tenant>/services/<service>.conf
# ACL files at:      /etc/gw-accessproxy/<tenant>/acls/<service>.txt
#
# Usage:
#   gw-accessctl.sh add-service    <tenant> <service> <host> <port> <type>
#   gw-accessctl.sh remove-service <tenant> <service>
#   gw-accessctl.sh add-user       <tenant> <service> <email>
#   gw-accessctl.sh remove-user    <tenant> <service> <email>
#   gw-accessctl.sh list-services  <tenant>
#   gw-accessctl.sh list-access    <tenant> <service>
#   gw-accessctl.sh show-user      <tenant> <email>
#   gw-accessctl.sh import-list    <tenant> <service> <file>
#   gw-accessctl.sh export-list    <tenant> <service>
#   gw-accessctl.sh access-matrix  <tenant>

set -euo pipefail
VERSION="RC3.5"

PORTAL_CONF="${PORTAL_CONF:-/etc/gw-admin-portal/conf/portal.conf}"
[[ -f "$PORTAL_CONF" ]] && source "$PORTAL_CONF" 2>/dev/null || true

ACCESS_BASE="${ACCESS_BASE:-/etc/gw-accessproxy}"
LOG=/var/log/gw-accessctl.log

isotime() { python3 -c "from datetime import datetime,timezone; \
print(datetime.now(timezone.utc).astimezone().isoformat(timespec='seconds'))"; }
die()  { echo ""; echo "ERROR: $*" >&2; exit 1; }
ok()   { echo "  ✓ $*"; }
info() { echo "  $*"; }
warn() { echo "  ⚠ $*"; }
log()  { echo "[$(isotime)] $*" >> "$LOG" 2>/dev/null || true; }

require_root() { [[ "${EUID:-$(id -u)}" -eq 0 ]] || die "Run as root"; }

tenant_dir()  { echo "${ACCESS_BASE}/$1"; }
services_dir(){ echo "${ACCESS_BASE}/$1/services"; }
acl_dir()     { echo "${ACCESS_BASE}/$1/acls"; }
service_conf(){ echo "${ACCESS_BASE}/$1/services/$2.conf"; }
acl_file()    { echo "${ACCESS_BASE}/$1/acls/$2.txt"; }

require_tenant_dir() {
    [[ -d "$(tenant_dir "$1")" ]] \
        || die "Tenant not found: $1 — run add-service first"
}

require_service() {
    [[ -f "$(service_conf "$1" "$2")" ]] \
        || die "Service not found: $2 for tenant $1"
}

# ══════════════════════════════════════════════════════════════════
# COMMANDS
# ══════════════════════════════════════════════════════════════════

cmd_add_service() {
    local tenant="${1:-}" service="${2:-}" host="${3:-}" \
          port="${4:-}" svc_type="${5:-ssh}"
    [[ -n "$tenant" && -n "$service" && -n "$host" && -n "$port" ]] \
        || die "Usage: gw-accessctl.sh add-service <tenant> <service> <host> <port> <type:ssh|sftp>"
    [[ "$svc_type" =~ ^(ssh|sftp)$ ]] \
        || die "Type must be: ssh or sftp"
    require_root

    mkdir -p "$(services_dir "$tenant")" "$(acl_dir "$tenant")"
    chmod 750 "$(tenant_dir "$tenant")"

    local conf; conf="$(service_conf "$tenant" "$service")"
    if [[ -f "$conf" ]]; then
        warn "Service already exists: $service — updating"
    fi

    cat > "$conf" << CONFEOF
service=${service}
host=${host}
port=${port}
type=${svc_type}
tenant=${tenant}
created=$(isotime)
CONFEOF
    chmod 600 "$conf"

    # Create empty ACL file if not exists
    local acl; acl="$(acl_file "$tenant" "$service")"
    [[ -f "$acl" ]] || touch "$acl"
    chmod 600 "$acl"

    ok "Service added: ${service} → ${host}:${port} (${svc_type})"
    info "Add users: gw-accessctl.sh add-user ${tenant} ${service} <email>"
    log "ADD_SERVICE: tenant=${tenant} service=${service} host=${host} port=${port} type=${svc_type}"
}

cmd_remove_service() {
    local tenant="${1:-}" service="${2:-}"
    [[ -n "$tenant" && -n "$service" ]] \
        || die "Usage: gw-accessctl.sh remove-service <tenant> <service>"
    require_root
    require_service "$tenant" "$service"

    local acl_count=0
    [[ -f "$(acl_file "$tenant" "$service")" ]] && \
        acl_count=$(grep -c "." "$(acl_file "$tenant" "$service")" 2>/dev/null || echo 0)

    warn "Removing service: ${service} (tenant: ${tenant}, ${acl_count} users in ACL)"
    read -r -p "  Confirm? [y/N] " confirm
    [[ "${confirm,,}" == "y" ]] || { echo "  Cancelled."; exit 0; }

    rm -f "$(service_conf "$tenant" "$service")"
    rm -f "$(acl_file "$tenant" "$service")"

    ok "Service removed: ${service}"
    log "REMOVE_SERVICE: tenant=${tenant} service=${service}"
}

cmd_add_user() {
    local tenant="${1:-}" service="${2:-}" email="${3:-}"
    [[ -n "$tenant" && -n "$service" && -n "$email" ]] \
        || die "Usage: gw-accessctl.sh add-user <tenant> <service> <email>"
    require_root
    require_service "$tenant" "$service"

    local acl; acl="$(acl_file "$tenant" "$service")"

    if grep -qxF "$email" "$acl" 2>/dev/null; then
        warn "${email} already in ACL for ${service}"
        exit 0
    fi

    echo "$email" >> "$acl"
    ok "User added: ${email} → ${service}"
    log "ADD_USER: tenant=${tenant} service=${service} email=${email}"
}

cmd_remove_user() {
    local tenant="${1:-}" service="${2:-}" email="${3:-}"
    [[ -n "$tenant" && -n "$service" && -n "$email" ]] \
        || die "Usage: gw-accessctl.sh remove-user <tenant> <service> <email>"
    require_root
    require_service "$tenant" "$service"

    local acl; acl="$(acl_file "$tenant" "$service")"

    if ! grep -qxF "$email" "$acl" 2>/dev/null; then
        warn "${email} not found in ACL for ${service}"
        exit 0
    fi

    grep -vxF "$email" "$acl" > "${acl}.tmp" && mv "${acl}.tmp" "$acl"
    ok "User removed: ${email} from ${service}"
    log "REMOVE_USER: tenant=${tenant} service=${service} email=${email}"
}

cmd_list_services() {
    local tenant="${1:-}"
    [[ -n "$tenant" ]] || die "Usage: gw-accessctl.sh list-services <tenant>"

    local svc_dir; svc_dir="$(services_dir "$tenant")"
    echo ""
    echo "=== Services: ${tenant} ==="
    echo ""
    printf "  %-24s %-20s %-8s %-6s %s\n" "Service" "Host" "Port" "Type" "Users"
    printf "  %-24s %-20s %-8s %-6s %s\n" "-------" "----" "----" "----" "-----"

    local found=0
    for conf in "${svc_dir}/"*.conf; do
        [[ -f "$conf" ]] || continue
        local svc host port svc_type user_count
        svc=$(grep "^service=" "$conf" | cut -d= -f2)
        host=$(grep "^host=" "$conf" | cut -d= -f2)
        port=$(grep "^port=" "$conf" | cut -d= -f2)
        svc_type=$(grep "^type=" "$conf" | cut -d= -f2)
        user_count=$(wc -l < "$(acl_file "$tenant" "$svc")" 2>/dev/null || echo 0)
        printf "  %-24s %-20s %-8s %-6s %s\n" "$svc" "$host" "$port" "$svc_type" "$user_count"
        found=$(( found + 1 ))
    done

    echo ""
    [[ $found -eq 0 ]] && info "No services configured" \
                       || info "Total: ${found} service(s)"
    echo ""
}

cmd_list_access() {
    local tenant="${1:-}" service="${2:-}"
    [[ -n "$tenant" && -n "$service" ]] \
        || die "Usage: gw-accessctl.sh list-access <tenant> <service>"
    require_service "$tenant" "$service"

    local acl; acl="$(acl_file "$tenant" "$service")"
    local count; count=$(grep -c "." "$acl" 2>/dev/null || echo 0)

    echo ""
    echo "=== ACL: ${service} (tenant: ${tenant}) — ${count} user(s) ==="
    echo ""
    if [[ "$count" -eq 0 ]]; then
        info "(no users authorised)"
    else
        while IFS= read -r email; do
            [[ -z "$email" ]] && continue
            info "${email}"
        done < "$acl"
    fi
    echo ""
}

cmd_show_user() {
    local tenant="${1:-}" email="${2:-}"
    [[ -n "$tenant" && -n "$email" ]] \
        || die "Usage: gw-accessctl.sh show-user <tenant> <email>"

    local svc_dir; svc_dir="$(services_dir "$tenant")"
    echo ""
    echo "=== Access for ${email} (tenant: ${tenant}) ==="
    echo ""

    local found=0
    for conf in "${svc_dir}/"*.conf; do
        [[ -f "$conf" ]] || continue
        local svc; svc=$(grep "^service=" "$conf" | cut -d= -f2)
        local acl; acl="$(acl_file "$tenant" "$svc")"
        if grep -qxF "$email" "$acl" 2>/dev/null; then
            local host port svc_type
            host=$(grep "^host=" "$conf" | cut -d= -f2)
            port=$(grep "^port=" "$conf" | cut -d= -f2)
            svc_type=$(grep "^type=" "$conf" | cut -d= -f2)
            info "${svc} → ${host}:${port} (${svc_type})"
            found=$(( found + 1 ))
        fi
    done

    echo ""
    [[ $found -eq 0 ]] && info "No service access for ${email}" \
                       || info "Total: ${found} service(s) authorised"
    echo ""
}

cmd_import_list() {
    local tenant="${1:-}" service="${2:-}" file="${3:-}"
    [[ -n "$tenant" && -n "$service" && -n "$file" ]] \
        || die "Usage: gw-accessctl.sh import-list <tenant> <service> <file>"
    require_root
    require_service "$tenant" "$service"
    [[ -f "$file" ]] || die "File not found: $file"

    local acl; acl="$(acl_file "$tenant" "$service")"
    local added=0 skipped=0

    while IFS= read -r email; do
        email="${email//[[:space:]]/}"
        [[ -z "$email" || "$email" =~ ^# ]] && continue
        if grep -qxF "$email" "$acl" 2>/dev/null; then
            skipped=$(( skipped + 1 ))
        else
            echo "$email" >> "$acl"
            added=$(( added + 1 ))
        fi
    done < "$file"

    ok "Import complete: ${service} — added=${added} skipped=${skipped}"
    log "IMPORT_LIST: tenant=${tenant} service=${service} added=${added}"
}

cmd_export_list() {
    local tenant="${1:-}" service="${2:-}"
    [[ -n "$tenant" && -n "$service" ]] \
        || die "Usage: gw-accessctl.sh export-list <tenant> <service>"
    require_service "$tenant" "$service"

    local acl; acl="$(acl_file "$tenant" "$service")"
    cat "$acl" 2>/dev/null || echo ""
}

cmd_access_matrix() {
    local tenant="${1:-}"
    [[ -n "$tenant" ]] || die "Usage: gw-accessctl.sh access-matrix <tenant>"

    local svc_dir; svc_dir="$(services_dir "$tenant")"
    echo ""
    echo "=== User Access Matrix: ${tenant} ==="
    echo ""

    # Collect all services and users
    python3 << PYEOF
import os, glob

svc_dir  = "${svc_dir}"
acl_dir  = "$(acl_dir "$tenant")"

services = sorted([
    os.path.splitext(os.path.basename(f))[0]
    for f in glob.glob(f"{svc_dir}/*.conf")
])

# Collect all unique users across all services
all_users = set()
acls = {}
for svc in services:
    acl_file = f"{acl_dir}/{svc}.txt"
    acls[svc] = set()
    if os.path.exists(acl_file):
        with open(acl_file) as f:
            for line in f:
                email = line.strip()
                if email and not email.startswith('#'):
                    acls[svc].add(email)
                    all_users.add(email)

if not services:
    print("  No services configured")
else:
    # Header
    header = f"  {'User Email':<32}"
    for svc in services:
        header += f"  {svc[:12]:<12}"
    print(header)
    print("  " + "-"*32 + ("  " + "-"*12) * len(services))

    # Rows
    for user in sorted(all_users):
        row = f"  {user:<32}"
        for svc in services:
            access = "Y" if user in acls[svc] else ""
            row += f"  {access:<12}"
        print(row)

    # Summary
    print()
    totals = f"  {'TOTAL AUTHORISED':<32}"
    for svc in services:
        totals += f"  {len(acls[svc]):<12}"
    print(totals)
PYEOF
    echo ""
}

# ── Dispatch ──────────────────────────────────────────────────────
case "${1:-}" in
    add-service)    cmd_add_service    "${2:-}" "${3:-}" "${4:-}" "${5:-}" "${6:-ssh}" ;;
    remove-service) cmd_remove_service "${2:-}" "${3:-}" ;;
    add-user)       cmd_add_user       "${2:-}" "${3:-}" "${4:-}" ;;
    remove-user)    cmd_remove_user    "${2:-}" "${3:-}" "${4:-}" ;;
    list-services)  cmd_list_services  "${2:-}" ;;
    list-access)    cmd_list_access    "${2:-}" "${3:-}" ;;
    show-user)      cmd_show_user      "${2:-}" "${3:-}" ;;
    import-list)    cmd_import_list    "${2:-}" "${3:-}" "${4:-}" ;;
    export-list)    cmd_export_list    "${2:-}" "${3:-}" ;;
    access-matrix)  cmd_access_matrix  "${2:-}" ;;
    -h|--help|help|"")
        echo ""
        echo "gw-accessctl.sh ${VERSION} — Per-service user ACL management"
        echo ""
        echo "Usage:"
        echo "  gw-accessctl.sh add-service    <tenant> <service> <host> <port> [ssh|sftp]"
        echo "  gw-accessctl.sh remove-service <tenant> <service>"
        echo "  gw-accessctl.sh add-user       <tenant> <service> <email>"
        echo "  gw-accessctl.sh remove-user    <tenant> <service> <email>"
        echo "  gw-accessctl.sh list-services  <tenant>"
        echo "  gw-accessctl.sh list-access    <tenant> <service>"
        echo "  gw-accessctl.sh show-user      <tenant> <email>"
        echo "  gw-accessctl.sh import-list    <tenant> <service> <file>"
        echo "  gw-accessctl.sh export-list    <tenant> <service>"
        echo "  gw-accessctl.sh access-matrix  <tenant>"
        echo ""
        ;;
    *) die "Unknown command: ${1} — run gw-accessctl.sh help" ;;
esac
