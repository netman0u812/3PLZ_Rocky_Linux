#!/bin/bash
# gw-accessproxyctl.sh v RC3.5 — Portal-side management for per-tenant
# SSH/SFTP access proxy (gw-accessproxy).
#
# Each tenant gets a dedicated gw-accessproxy process on the GW node
# (primary only), listening on tenant VIP:22.
# Proxy terminates the inbound SSH session, validates TOTP, checks the
# per-service ACL, fetches vault credentials, and opens the outbound
# session to the internal host — transparent to the user.
#
# Per-tenant on GW node:
#   Process:   gw-accessproxy-<tenant>.py  (Python/paramiko)
#   Systemd:   gw-accessproxy@<tenant>.service
#   nftables:  gw_accessproxy_<tenant>
#   Config:    /etc/gw-accessproxy/<tenant>/
#
# Usage:
#   gw-accessproxyctl.sh apply   <tenant>   Push config + start on GW node
#   gw-accessproxyctl.sh stop    <tenant>   Stop proxy on GW node
#   gw-accessproxyctl.sh status  <tenant>   Show proxy state
#   gw-accessproxyctl.sh list               List all tenant proxies
#   gw-accessproxyctl.sh logs    <tenant>   Show recent session audit log
#   gw-accessproxyctl.sh report  <tenant>   Full access report

set -euo pipefail
VERSION="RC3.5"

PORTAL_CONF="${PORTAL_CONF:-/etc/gw-admin-portal/conf/portal.conf}"
[[ -f "$PORTAL_CONF" ]] && source "$PORTAL_CONF" 2>/dev/null || true

ACCESS_BASE="${ACCESS_BASE:-/etc/gw-accessproxy}"
PROXY_PORT="${PROXY_PORT:-22}"
PORTAL_KEY="${PORTAL_KEY:-/var/lib/gw-admin-portal/sshkeys/gwportal_ed25519}"
KNOWN_HOSTS="${KNOWN_HOSTS:-/etc/ssh/ssh_known_hosts}"
LOG=/var/log/gw-accessproxyctl.log

isotime() { python3 -c "from datetime import datetime,timezone; \
print(datetime.now(timezone.utc).astimezone().isoformat(timespec='seconds'))"; }
die()  { echo ""; echo "ERROR: $*" >&2; exit 1; }
ok()   { echo "  ✓ $*"; }
info() { echo "  $*"; }
warn() { echo "  ⚠ $*"; }
log()  { echo "[$(isotime)] $*" >> "$LOG" 2>/dev/null || true; }

require_root() { [[ "${EUID:-$(id -u)}" -eq 0 ]] || die "Run as root"; }

get_primary_node() { gwreg tenant show "$1" 2>/dev/null \
    | grep -E '^primary_node|primary' | awk '{print $NF}' | head -1; }
get_node_ip() { gwreg node show "$1" 2>/dev/null \
    | grep -E '^ip|^mgmt_ip' | awk '{print $NF}' | head -1; }
gw_ssh() { local ip="$1"; shift
    ssh -i "$PORTAL_KEY" -o StrictHostKeyChecking=yes \
        -o UserKnownHostsFile="$KNOWN_HOSTS" "root@${ip}" "$@"; }
scp_push() { local src="$1" ip="$2" dst="$3"
    scp -q -i "$PORTAL_KEY" -o StrictHostKeyChecking=yes \
        -o UserKnownHostsFile="$KNOWN_HOSTS" "$src" "root@${ip}:${dst}"; }

get_vip() {
    cat "${ACCESS_BASE}/$1/vip" 2>/dev/null \
        || gwreg tenant show "$1" 2>/dev/null \
            | grep -E '^access_proxy_vip|^loopback_vip' \
            | awk '{print $NF}' | head -1 \
        || die "Cannot determine VIP for tenant: $1"
}

# ── Generate per-tenant SSH host key for the proxy ───────────────
ensure_host_key() {
    local tenant="$1"
    local key_path="${ACCESS_BASE}/${tenant}/proxy_host_key"
    if [[ ! -f "$key_path" ]]; then
        ssh-keygen -t ed25519 -N "" -C "gw-accessproxy-${tenant}" \
            -f "$key_path" >/dev/null 2>&1
        chmod 600 "$key_path"
        info "Generated proxy host key for ${tenant}"
    fi
    echo "$key_path"
}

# ── Build paramiko proxy Python script ───────────────────────────
build_proxy_script() {
    local tenant="$1" vip="$2"
    cat << PYEOF
#!/usr/bin/env python3
# gw-accessproxy — tenant: ${tenant}
# Generated: $(isotime)
# Terminates inbound SSH session, validates TOTP, checks ACL,
# fetches vault credentials, opens outbound session transparently.

import paramiko, socket, threading, logging, json, os, sys
import hmac, hashlib, struct, time, base64, gpg

TENANT    = '${tenant}'
HOST      = '${vip}'
PORT      = ${PROXY_PORT}
HOST_KEY  = '/etc/gw-accessproxy/${tenant}/proxy_host_key'
TOTP_DIR  = '/etc/gw-accessproxy/${tenant}/totp'
ACL_DIR   = '/etc/gw-accessproxy/${tenant}/acls'
SVC_DIR   = '/etc/gw-accessproxy/${tenant}/services'
VAULT_F   = '/etc/gw-accessproxy/${tenant}/vault/credentials.gpg'
KEY_F     = '/etc/gw-accessproxy/${tenant}/vault/.keyref'
LOG_DIR   = '/var/log/gw-access/${tenant}'
AUDIT_LOG = f'{LOG_DIR}/sessions.log'

os.makedirs(LOG_DIR, exist_ok=True)
logging.basicConfig(
    filename=AUDIT_LOG,
    level=logging.INFO,
    format='%(asctime)s %(message)s'
)

# ── TOTP validation ──────────────────────────────────────────────
def validate_totp(email, code):
    sf = os.path.join(TOTP_DIR, f'{email}.secret')
    if not os.path.exists(sf):
        return False
    with open(sf) as f:
        secret = f.read().strip()
    for offset in (-1, 0, 1):
        try:
            key = base64.b32decode(secret.upper() + '=' * (-len(secret) % 8))
            t   = int((time.time() + offset * 30) / 30)
            msg = struct.pack('>Q', t)
            h   = hmac.new(key, msg, hashlib.sha1).digest()
            o   = h[-1] & 0xf
            expected = (struct.unpack('>I', h[o:o+4])[0] & 0x7fffffff) % 1000000
            if code == f'{expected:06d}':
                return True
        except Exception:
            pass
    return False

# ── ACL check ────────────────────────────────────────────────────
def check_acl(email, service):
    acl_f = os.path.join(ACL_DIR, f'{service}.txt')
    if not os.path.exists(acl_f):
        return False
    with open(acl_f) as f:
        return email.strip() in [l.strip() for l in f if l.strip()]

# ── Vault lookup ─────────────────────────────────────────────────
def get_credentials(email, service):
    if not os.path.exists(VAULT_F) or not os.path.exists(KEY_F):
        return None
    with open(KEY_F) as f:
        passphrase = f.read().strip()
    try:
        result = os.popen(
            f'gpg --quiet --batch --yes --passphrase "{passphrase}" '
            f'--decrypt {VAULT_F} 2>/dev/null'
        ).read()
        data = json.loads(result)
        return data.get(f'{email}:{service}')
    except Exception:
        return None

# ── Get service config ───────────────────────────────────────────
def get_service(service):
    conf_f = os.path.join(SVC_DIR, f'{service}.conf')
    if not os.path.exists(conf_f):
        return None
    conf = {}
    with open(conf_f) as f:
        for line in f:
            if '=' in line:
                k, v = line.strip().split('=', 1)
                conf[k] = v
    return conf

# ── Session pipe ─────────────────────────────────────────────────
def pipe_data(src_chan, dst_chan, label):
    try:
        while True:
            data = src_chan.recv(4096)
            if not data:
                break
            dst_chan.sendall(data)
    except Exception:
        pass
    try:
        dst_chan.close()
    except Exception:
        pass

# ── SSH server interface ──────────────────────────────────────────
class ProxyServer(paramiko.ServerInterface):
    def __init__(self, client_ip):
        self.client_ip  = client_ip
        self.email      = None
        self.otp        = None
        self.service    = None
        self.authed     = False
        self.event      = threading.Event()

    def check_channel_request(self, kind, chanid):
        if kind in ('session',):
            return paramiko.OPEN_SUCCEEDED
        return paramiko.OPEN_FAILED_ADMINISTRATIVELY_PROHIBITED

    def check_auth_password(self, username, password):
        # username = email, password = OTP code
        email   = username.strip()
        otp     = password.strip()

        if not validate_totp(email, otp):
            logging.warning(f'AUTH_FAIL ip={self.client_ip} email={email} reason=invalid_otp')
            return paramiko.AUTH_FAILED

        self.email  = email
        self.otp    = otp
        self.authed = True
        logging.info(f'AUTH_OK ip={self.client_ip} email={email}')
        return paramiko.AUTH_SUCCESSFUL

    def check_channel_shell_request(self, channel):
        self.event.set()
        return True

    def check_channel_pty_request(self, channel, term, w, h, pw, ph, modes):
        return True

    def check_channel_subsystem_request(self, channel, name):
        if name == 'sftp':
            self.event.set()
            return True
        return False

    def get_allowed_auths(self, username):
        return 'password'


def handle_client(client_sock, client_addr):
    client_ip = client_addr[0]
    transport = None
    try:
        host_key = paramiko.Ed25519Key.from_private_key_file(HOST_KEY)
        transport = paramiko.Transport(client_sock)
        transport.add_server_key(host_key)

        server = ProxyServer(client_ip)
        transport.start_server(server=server)

        chan = transport.accept(30)
        if chan is None or not server.authed:
            logging.warning(f'CONNECT_FAIL ip={client_ip} reason=no_auth')
            return

        server.event.wait(10)
        email = server.email

        # Determine which service — for POC, use first service the user has access to
        # In production this would be determined by the SSH target hostname via DNS
        service = None
        if os.path.exists(SVC_DIR):
            for conf_f in os.listdir(SVC_DIR):
                if not conf_f.endswith('.conf'):
                    continue
                svc_name = conf_f[:-5]
                if check_acl(email, svc_name):
                    service = svc_name
                    break

        if service is None:
            logging.warning(f'ACL_DENY ip={client_ip} email={email} reason=no_service_access')
            chan.send('Access denied: no authorised services\r\n')
            chan.close()
            return

        logging.info(f'ACL_ALLOW ip={client_ip} email={email} service={service}')

        svc_conf = get_service(service)
        if not svc_conf:
            logging.error(f'SVC_NOT_FOUND ip={client_ip} email={email} service={service}')
            chan.close()
            return

        creds = get_credentials(email, service)
        if not creds:
            logging.error(f'VAULT_MISS ip={client_ip} email={email} service={service}')
            chan.close()
            return

        # Open outbound SSH session to internal host
        out_client = paramiko.SSHClient()
        out_client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        session_start = time.time()

        try:
            out_client.connect(
                hostname = creds['host'],
                port     = int(svc_conf.get('port', 22)),
                username = creds['username'],
                password = creds['password'],
                timeout  = 10,
            )
        except Exception as e:
            logging.error(f'OUTBOUND_FAIL ip={client_ip} email={email} '
                          f'service={service} host={creds["host"]} err={e}')
            chan.send(f'Connection to internal host failed\r\n')
            chan.close()
            return

        logging.info(f'SESSION_START ip={client_ip} email={email} '
                     f'service={service} host={creds["host"]}')

        out_transport = out_client.get_transport()
        out_chan = out_transport.open_session()

        # Mirror channel type (shell or sftp)
        is_sftp = svc_conf.get('type') == 'sftp'
        if is_sftp:
            out_chan.invoke_subsystem('sftp')
        else:
            out_chan.get_pty()
            out_chan.invoke_shell()

        # Bidirectional pipe
        t1 = threading.Thread(target=pipe_data, args=(chan, out_chan, 'inbound'), daemon=True)
        t2 = threading.Thread(target=pipe_data, args=(out_chan, chan, 'outbound'), daemon=True)
        t1.start(); t2.start()
        t1.join(); t2.join()

        duration = int(time.time() - session_start)
        logging.info(f'SESSION_END ip={client_ip} email={email} '
                     f'service={service} duration={duration}s')

    except Exception as e:
        logging.error(f'PROXY_ERROR ip={client_ip} err={e}')
    finally:
        if transport:
            transport.close()
        client_sock.close()


def main():
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    sock.bind((HOST, PORT))
    sock.listen(20)
    logging.info(f'gw-accessproxy starting: tenant={TENANT} {HOST}:{PORT}')

    while True:
        try:
            client, addr = sock.accept()
            t = threading.Thread(target=handle_client, args=(client, addr), daemon=True)
            t.start()
        except KeyboardInterrupt:
            break
        except Exception as e:
            logging.error(f'ACCEPT_ERROR: {e}')

    sock.close()

if __name__ == '__main__':
    main()
PYEOF
}

# ── Build systemd unit ────────────────────────────────────────────
build_proxy_unit() {
    local tenant="$1"
    cat << UNITEOF
[Unit]
Description=GW Platform Access Proxy — tenant: ${tenant}
After=network.target
PartOf=gw-platform.target

[Service]
Type=simple
ExecStart=/usr/bin/python3 /etc/gw-accessproxy/${tenant}/proxy.py
Restart=on-failure
RestartSec=5
StandardOutput=journal
StandardError=journal
SyslogIdentifier=gw-proxy-${tenant}

[Install]
WantedBy=multi-user.target
UNITEOF
}

# ── Build nftables ────────────────────────────────────────────────
build_proxy_nftables() {
    local tenant="$1" vip="$2"
    local table="gw_accessproxy_${tenant}"
    local nets
    nets=$(gwreg tenant show "$tenant" 2>/dev/null \
        | grep -E 'remote_prefix|source_network' \
        | awk '{print $NF}' || echo "")

    cat << NFTEOF
table inet ${table} {
    chain input {
        type filter hook input priority 0; policy drop;
        ct state established,related accept
        iif lo accept
NFTEOF
    if [[ -z "$nets" ]]; then
        echo "        ip daddr ${vip} tcp dport ${PROXY_PORT} log prefix \"gw-proxy-${tenant}: \" accept"
    else
        while IFS= read -r net; do
            [[ -z "$net" ]] && continue
            echo "        ip saddr ${net} ip daddr ${vip} tcp dport ${PROXY_PORT} accept"
        done <<< "$nets"
        echo "        ip daddr ${vip} tcp dport ${PROXY_PORT} log prefix \"gw-proxy-${tenant}-DENY: \" drop"
    fi
    echo "    }"
    echo "}"
}

# ══════════════════════════════════════════════════════════════════
# COMMANDS
# ══════════════════════════════════════════════════════════════════

cmd_apply() {
    local tenant="${1:-}"
    [[ -n "$tenant" ]] || die "Usage: gw-accessproxyctl.sh apply <tenant>"
    require_root

    local vip; vip="$(get_vip "$tenant")"
    local node; node="$(get_primary_node "$tenant")"
    [[ -n "$node" ]] || die "Cannot determine primary node for tenant: ${tenant}"
    local node_ip; node_ip="$(get_node_ip "$node")"
    local base; base="${ACCESS_BASE}/${tenant}"

    echo ""
    info "Deploying access proxy: tenant=${tenant} vip=${vip}:${PROXY_PORT}"

    # Ensure host key
    ensure_host_key "$tenant" > /dev/null

    # Build artefacts
    build_proxy_script   "$tenant" "$vip" > "${base}/proxy.py"
    build_proxy_unit     "$tenant"        > "${base}/gw-accessproxy@${tenant}.service"
    build_proxy_nftables "$tenant" "$vip" > "${base}/proxy-nftables.conf"

    # Push to GW node
    gw_ssh "$node_ip" "
        mkdir -p /etc/gw-accessproxy/${tenant}/{totp,acls,services,vault} \
                 /var/log/gw-access/${tenant}
        chmod 750 /etc/gw-accessproxy/${tenant}
    "

    for f in proxy.py "gw-accessproxy@${tenant}.service" proxy-nftables.conf \
              proxy_host_key; do
        scp_push "${base}/${f}" "$node_ip" "/etc/gw-accessproxy/${tenant}/${f}"
    done

    # Push ACLs, service configs (vault pushed separately by gw-accessvaultctl)
    local acl_dir="${base}/acls"
    local svc_dir="${base}/services"
    [[ -d "$acl_dir" ]] && for f in "${acl_dir}"/*.txt; do
        [[ -f "$f" ]] || continue
        scp_push "$f" "$node_ip" "/etc/gw-accessproxy/${tenant}/acls/$(basename "$f")"
    done
    [[ -d "$svc_dir" ]] && for f in "${svc_dir}"/*.conf; do
        [[ -f "$f" ]] || continue
        scp_push "$f" "$node_ip" "/etc/gw-accessproxy/${tenant}/services/$(basename "$f")"
    done

    gw_ssh "$node_ip" "
        set -e
        # Install paramiko if needed
        python3 -c 'import paramiko' 2>/dev/null || pip3 install paramiko --break-system-packages

        cp /etc/gw-accessproxy/${tenant}/gw-accessproxy@${tenant}.service \
           /etc/systemd/system/gw-accessproxy@${tenant}.service

        chmod 600 /etc/gw-accessproxy/${tenant}/proxy_host_key
        chmod 700 /etc/gw-accessproxy/${tenant}/proxy.py

        nft delete table inet gw_accessproxy_${tenant} 2>/dev/null || true
        nft -f /etc/gw-accessproxy/${tenant}/proxy-nftables.conf

        systemctl daemon-reload
        systemctl enable --now gw-accessproxy@${tenant}.service
        systemctl is-active gw-accessproxy@${tenant}.service
    "

    ok "Access proxy active: tenant=${tenant} ${vip}:${PROXY_PORT}"
    info "Users connect:  ssh <email>@${vip}"
    info "Get OTP first:  curl http://${vip}:8444/otp/<email>"
    log "APPLY: tenant=${tenant} vip=${vip} node=${node}"
}

cmd_stop() {
    local tenant="${1:-}"
    [[ -n "$tenant" ]] || die "Usage: gw-accessproxyctl.sh stop <tenant>"
    require_root

    local node; node="$(get_primary_node "$tenant")"
    local node_ip; node_ip="$(get_node_ip "$node")"

    gw_ssh "$node_ip" "
        systemctl disable --now gw-accessproxy@${tenant}.service 2>/dev/null || true
        nft delete table inet gw_accessproxy_${tenant} 2>/dev/null || true
    "
    ok "Access proxy stopped: tenant=${tenant}"
    log "STOP: tenant=${tenant}"
}

cmd_status() {
    local tenant="${1:-}"
    [[ -n "$tenant" ]] || die "Usage: gw-accessproxyctl.sh status <tenant>"

    local vip; vip="$(get_vip "$tenant" 2>/dev/null || echo 'unknown')"
    local base; base="${ACCESS_BASE}/${tenant}"
    local svc_count=0; local user_count=0

    [[ -d "${base}/services" ]] && \
        svc_count=$(ls "${base}/services/"*.conf 2>/dev/null | wc -l || echo 0)
    [[ -d "${base}/acls" ]] && \
        user_count=$(sort -u "${base}/acls/"*.txt 2>/dev/null | wc -l || echo 0)

    echo ""
    echo "=== Access Proxy Status: ${tenant} ==="
    echo ""
    info "VIP:       ${vip}:${PROXY_PORT}"
    info "Services:  ${svc_count}"
    info "Users:     ${user_count} (unique across all services)"

    local node; node="$(get_primary_node "$tenant" 2>/dev/null || echo '')"
    if [[ -n "$node" ]]; then
        local node_ip; node_ip="$(get_node_ip "$node" 2>/dev/null || echo '')"
        if [[ -n "$node_ip" ]]; then
            local svc_state
            svc_state=$(gw_ssh "$node_ip" \
                "systemctl is-active gw-accessproxy@${tenant}.service 2>/dev/null" \
                || echo "unknown")
            info "GW node:   ${node} (${node_ip}) — service: ${svc_state}"
        fi
    fi
    echo ""
}

cmd_list() {
    echo ""
    echo "=== Tenant Access Proxies ==="
    echo ""
    printf "  %-20s %-18s %-8s %-10s %s\n" "Tenant" "VIP" "Port" "Services" "Users"
    printf "  %-20s %-18s %-8s %-10s %s\n" "------" "---" "----" "--------" "-----"

    local found=0
    for dir in "${ACCESS_BASE}"/*/; do
        [[ -d "$dir" ]] || continue
        local tenant; tenant="$(basename "$dir")"
        [[ -d "${dir}/services" ]] || continue
        local vip; vip="$(cat "${dir}/vip" 2>/dev/null || echo 'unknown')"
        local svc_count; svc_count=$(ls "${dir}/services/"*.conf 2>/dev/null | wc -l || echo 0)
        local user_count; user_count=$(sort -u "${dir}/acls/"*.txt 2>/dev/null | wc -l || echo 0)
        printf "  %-20s %-18s %-8s %-10s %s\n" \
            "$tenant" "$vip" "$PROXY_PORT" "$svc_count" "$user_count"
        found=$(( found + 1 ))
    done
    echo ""
    [[ $found -eq 0 ]] && info "No access proxies configured" || info "Total: ${found}"
    echo ""
}

cmd_logs() {
    local tenant="${1:-}"
    [[ -n "$tenant" ]] || die "Usage: gw-accessproxyctl.sh logs <tenant>"
    local log_f="/var/log/gw-access/${tenant}/sessions.log"

    local node; node="$(get_primary_node "$tenant" 2>/dev/null || echo '')"
    if [[ -n "$node" ]]; then
        local node_ip; node_ip="$(get_node_ip "$node")"
        gw_ssh "$node_ip" "tail -50 ${log_f} 2>/dev/null || echo '(no session log)'"
    else
        [[ -f "$log_f" ]] && tail -50 "$log_f" || echo "(no session log)"
    fi
}

cmd_report() {
    local tenant="${1:-}"
    [[ -n "$tenant" ]] || die "Usage: gw-accessproxyctl.sh report <tenant>"

    echo ""
    echo "════════════════════════════════════════════════════════"
    echo "  ACCESS PROXY REPORT — ${tenant}"
    echo "  Generated: $(isotime)"
    echo "════════════════════════════════════════════════════════"
    echo ""
    cmd_status "$tenant"
    echo "--- Services ---"
    gw-accessctl.sh list-services "$tenant" 2>/dev/null || info "(gw-accessctl.sh not available)"
    echo "--- Access Matrix ---"
    gw-accessctl.sh access-matrix "$tenant" 2>/dev/null || true
    echo "--- Recent Sessions ---"
    cmd_logs "$tenant"
}

# ── Dispatch ──────────────────────────────────────────────────────
case "${1:-}" in
    apply)   cmd_apply   "${2:-}" ;;
    stop)    cmd_stop    "${2:-}" ;;
    status)  cmd_status  "${2:-}" ;;
    list)    cmd_list ;;
    logs)    cmd_logs    "${2:-}" ;;
    report)  cmd_report  "${2:-}" ;;
    -h|--help|help|"")
        echo ""
        echo "gw-accessproxyctl.sh ${VERSION} — Per-tenant SSH/SFTP access proxy management"
        echo ""
        echo "Usage:"
        echo "  gw-accessproxyctl.sh apply  <tenant>   Push config + start on GW node"
        echo "  gw-accessproxyctl.sh stop   <tenant>   Stop proxy on GW node"
        echo "  gw-accessproxyctl.sh status <tenant>   Show proxy state"
        echo "  gw-accessproxyctl.sh list              List all tenant proxies"
        echo "  gw-accessproxyctl.sh logs   <tenant>   Show session audit log"
        echo "  gw-accessproxyctl.sh report <tenant>   Full access report"
        echo ""
        echo "Full RC3.5 provisioning workflow for a tenant:"
        echo "  1. gw-accessvaultctl.sh  init   <tenant>"
        echo "  2. gw-accessvaultctl.sh  add    <tenant> <email> <service> <host> <user> <pass>"
        echo "  3. gw-accessctl.sh       add-service <tenant> <service> <host> <port>"
        echo "  4. gw-accessctl.sh       add-user    <tenant> <service> <email>"
        echo "  5. gw-otpctl.sh          provision   <tenant> <email>"
        echo "  6. gw-otpctl.sh          apply       <tenant>"
        echo "  7. gw-accessproxyctl.sh  apply       <tenant>"
        echo "  8. gw-dnsctl.sh          apply       <tenant>"
        echo ""
        ;;
    *) die "Unknown command: ${1} — run gw-accessproxyctl.sh help" ;;
esac
