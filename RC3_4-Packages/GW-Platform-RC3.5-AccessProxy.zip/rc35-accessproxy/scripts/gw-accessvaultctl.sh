#!/bin/bash
# gw-accessvaultctl.sh v RC3.5 — Per-tenant GPG encrypted credential store.
#
# Maps user email → {service, internal-host, username, password} per tenant.
# Store is GPG AES-256 symmetric encrypted JSON at:
#   /etc/gw-accessproxy/<tenant>/vault/credentials.gpg
#
# Passphrase stored in portal keyring at:
#   /etc/gw-accessproxy/<tenant>/vault/.keyref
#   (root-owned, mode 600)
#
# Usage:
#   gw-accessvaultctl.sh init     <tenant>                      Create new vault
#   gw-accessvaultctl.sh add      <tenant> <email> <service> <host> <user> <pass>
#   gw-accessvaultctl.sh update   <tenant> <email> <service> [field] [value]
#   gw-accessvaultctl.sh remove   <tenant> <email> <service>
#   gw-accessvaultctl.sh list     <tenant>                      List entries (no passwords)
#   gw-accessvaultctl.sh show     <tenant> <email>              Show entries for user
#   gw-accessvaultctl.sh rotate   <tenant> <email> <service> <new-pass>
#   gw-accessvaultctl.sh verify   <tenant>                      Decrypt and validate vault
#   gw-accessvaultctl.sh backup   <tenant>                      Encrypted backup to stdout
#   gw-accessvaultctl.sh rekey    <tenant>                      Re-encrypt with new passphrase

set -euo pipefail
VERSION="RC3.5"

PORTAL_CONF="${PORTAL_CONF:-/etc/gw-admin-portal/conf/portal.conf}"
[[ -f "$PORTAL_CONF" ]] && source "$PORTAL_CONF" 2>/dev/null || true

VAULT_BASE="${VAULT_BASE:-/etc/gw-accessproxy}"
LOG=/var/log/gw-accessvaultctl.log

isotime() { python3 -c "from datetime import datetime,timezone; \
print(datetime.now(timezone.utc).astimezone().isoformat(timespec='seconds'))"; }
die()  { echo ""; echo "ERROR: $*" >&2; exit 1; }
ok()   { echo "  ✓ $*"; }
info() { echo "  $*"; }
warn() { echo "  ⚠ $*"; }
log()  { echo "[$(isotime)] $*" >> "$LOG" 2>/dev/null || true; }

require_root() { [[ "${EUID:-$(id -u)}" -eq 0 ]] || die "Run as root"; }

vault_dir()  { echo "${VAULT_BASE}/$1/vault"; }
vault_file() { echo "${VAULT_BASE}/$1/vault/credentials.gpg"; }
key_file()   { echo "${VAULT_BASE}/$1/vault/.keyref"; }

require_vault() {
    local tenant="$1"
    [[ -f "$(vault_file "$tenant")" ]] \
        || die "Vault not found for tenant: $tenant — run init first"
}

# ── GPG helpers ───────────────────────────────────────────────────
get_passphrase() {
    local tenant="$1"
    local kf; kf="$(key_file "$tenant")"
    [[ -f "$kf" ]] || die "Key file not found: $kf"
    cat "$kf"
}

decrypt_vault() {
    local tenant="$1"
    local pass; pass="$(get_passphrase "$tenant")"
    gpg --quiet --batch --yes \
        --passphrase "$pass" \
        --decrypt "$(vault_file "$tenant")" 2>/dev/null
}

encrypt_vault() {
    local tenant="$1" json="$2"
    local pass; pass="$(get_passphrase "$tenant")"
    local vf; vf="$(vault_file "$tenant")"
    echo "$json" | gpg --quiet --batch --yes \
        --passphrase "$pass" \
        --symmetric --cipher-algo AES256 \
        --output "${vf}.tmp" 2>/dev/null
    mv "${vf}.tmp" "$vf"
}

generate_passphrase() {
    python3 -c "import secrets, string; \
chars = string.ascii_letters + string.digits; \
print(''.join(secrets.choice(chars) for _ in range(32)))"
}

# ── JSON helpers (python3) ────────────────────────────────────────
json_add() {
    local json="$1" email="$2" service="$3" \
          host="$4" user="$5" pass="$6"
    python3 << PYEOF
import json, sys
data = json.loads('''${json}''')
key = "${email}:${service}"
if key in data:
    print("EXISTS", file=sys.stderr)
    sys.exit(1)
data[key] = {
    "email":    "${email}",
    "service":  "${service}",
    "host":     "${host}",
    "username": "${user}",
    "password": "${pass}",
    "updated":  "$(isotime)"
}
print(json.dumps(data, indent=2))
PYEOF
}

json_update() {
    local json="$1" email="$2" service="$3" field="$4" value="$5"
    python3 << PYEOF
import json, sys
data = json.loads('''${json}''')
key = "${email}:${service}"
if key not in data:
    print(f"Entry not found: {key}", file=sys.stderr)
    sys.exit(1)
data[key]["${field}"] = "${value}"
data[key]["updated"]  = "$(isotime)"
print(json.dumps(data, indent=2))
PYEOF
}

json_remove() {
    local json="$1" email="$2" service="$3"
    python3 << PYEOF
import json, sys
data = json.loads('''${json}''')
key = "${email}:${service}"
if key not in data:
    print(f"Entry not found: {key}", file=sys.stderr)
    sys.exit(1)
del data[key]
print(json.dumps(data, indent=2))
PYEOF
}

# ══════════════════════════════════════════════════════════════════
# COMMANDS
# ══════════════════════════════════════════════════════════════════

cmd_init() {
    local tenant="${1:-}"
    [[ -n "$tenant" ]] || die "Usage: gw-accessvaultctl.sh init <tenant>"
    require_root

    local vdir; vdir="$(vault_dir "$tenant")"
    local vf;   vf="$(vault_file "$tenant")"
    local kf;   kf="$(key_file "$tenant")"

    mkdir -p "$vdir"
    chmod 700 "$vdir"

    if [[ -f "$vf" ]]; then
        warn "Vault already exists for tenant: $tenant"
        read -r -p "  Re-initialise (destroys existing vault)? [y/N] " confirm
        [[ "${confirm,,}" == "y" ]] || { echo "  Cancelled."; exit 0; }
        cp "$vf" "${vf}.bak.$(date +%Y%m%d%H%M%S)"
        info "Existing vault archived"
    fi

    # Generate passphrase
    local pass; pass="$(generate_passphrase)"
    echo "$pass" > "$kf"
    chmod 600 "$kf"

    # Create empty vault
    local empty_json='{}'; 
    echo "$empty_json" | gpg --quiet --batch --yes \
        --passphrase "$pass" \
        --symmetric --cipher-algo AES256 \
        --output "$vf" 2>/dev/null
    chmod 600 "$vf"

    echo ""
    ok "Vault initialised: tenant=${tenant}"
    info "Location: ${vf}"
    warn "Vault passphrase stored at: ${kf}"
    warn "Back up ${kf} separately from the vault file"
    info "Backup: gw-accessvaultctl.sh backup ${tenant}"
    log "INIT: tenant=${tenant}"
}

cmd_add() {
    local tenant="${1:-}" email="${2:-}" service="${3:-}" \
          host="${4:-}" user="${5:-}" pass="${6:-}"
    [[ -n "$tenant" && -n "$email" && -n "$service" && \
       -n "$host"   && -n "$user"  && -n "$pass" ]] \
        || die "Usage: gw-accessvaultctl.sh add <tenant> <email> <service> <host> <user> <pass>"
    require_root
    require_vault "$tenant"

    local json; json="$(decrypt_vault "$tenant")"
    local updated; updated="$(json_add "$json" "$email" "$service" "$host" "$user" "$pass")" \
        || die "Entry already exists: ${email}:${service} — use update to change"
    encrypt_vault "$tenant" "$updated"

    ok "Vault entry added: ${email} → ${service} @ ${host}"
    log "ADD: tenant=${tenant} email=${email} service=${service} host=${host}"
}

cmd_update() {
    local tenant="${1:-}" email="${2:-}" service="${3:-}" \
          field="${4:-}" value="${5:-}"
    [[ -n "$tenant" && -n "$email" && -n "$service" && \
       -n "$field"  && -n "$value" ]] \
        || die "Usage: gw-accessvaultctl.sh update <tenant> <email> <service> <field> <value>"
    [[ "$field" =~ ^(host|username|password)$ ]] \
        || die "Field must be: host, username, or password"
    require_root
    require_vault "$tenant"

    local json; json="$(decrypt_vault "$tenant")"
    local updated; updated="$(json_update "$json" "$email" "$service" "$field" "$value")" \
        || die "Entry not found: ${email}:${service}"
    encrypt_vault "$tenant" "$updated"

    ok "Vault entry updated: ${email}:${service} field=${field}"
    log "UPDATE: tenant=${tenant} email=${email} service=${service} field=${field}"
}

cmd_rotate() {
    local tenant="${1:-}" email="${2:-}" service="${3:-}" new_pass="${4:-}"
    [[ -n "$tenant" && -n "$email" && -n "$service" && -n "$new_pass" ]] \
        || die "Usage: gw-accessvaultctl.sh rotate <tenant> <email> <service> <new-pass>"
    require_root
    require_vault "$tenant"

    local json; json="$(decrypt_vault "$tenant")"
    local updated; updated="$(json_update "$json" "$email" "$service" "password" "$new_pass")" \
        || die "Entry not found: ${email}:${service}"
    encrypt_vault "$tenant" "$updated"

    ok "Password rotated: ${email}:${service}"
    log "ROTATE: tenant=${tenant} email=${email} service=${service}"
}

cmd_remove() {
    local tenant="${1:-}" email="${2:-}" service="${3:-}"
    [[ -n "$tenant" && -n "$email" && -n "$service" ]] \
        || die "Usage: gw-accessvaultctl.sh remove <tenant> <email> <service>"
    require_root
    require_vault "$tenant"

    warn "Removing vault entry: ${email}:${service} from tenant ${tenant}"
    read -r -p "  Confirm? [y/N] " confirm
    [[ "${confirm,,}" == "y" ]] || { echo "  Cancelled."; exit 0; }

    local json; json="$(decrypt_vault "$tenant")"
    local updated; updated="$(json_remove "$json" "$email" "$service")" \
        || die "Entry not found: ${email}:${service}"
    encrypt_vault "$tenant" "$updated"

    ok "Vault entry removed: ${email}:${service}"
    log "REMOVE: tenant=${tenant} email=${email} service=${service}"
}

cmd_list() {
    local tenant="${1:-}"
    [[ -n "$tenant" ]] || die "Usage: gw-accessvaultctl.sh list <tenant>"
    require_vault "$tenant"

    local json; json="$(decrypt_vault "$tenant")"
    echo ""
    echo "=== Vault Entries: ${tenant} ==="
    echo ""
    python3 << PYEOF
import json
data = json.loads('''${json}''')
if not data:
    print("  (empty vault)")
else:
    print(f"  {'Email':<30} {'Service':<20} {'Host':<20} {'Username':<15} {'Updated'}")
    print(f"  {'-'*30} {'-'*20} {'-'*20} {'-'*15} {'-'*20}")
    for key, entry in sorted(data.items()):
        print(f"  {entry['email']:<30} {entry['service']:<20} "
              f"{entry['host']:<20} {entry['username']:<15} "
              f"{entry.get('updated','')}")
PYEOF
    echo ""
    log "LIST: tenant=${tenant}"
}

cmd_show() {
    local tenant="${1:-}" email="${2:-}"
    [[ -n "$tenant" && -n "$email" ]] \
        || die "Usage: gw-accessvaultctl.sh show <tenant> <email>"
    require_vault "$tenant"

    local json; json="$(decrypt_vault "$tenant")"
    echo ""
    echo "=== Vault Entries for ${email} (tenant: ${tenant}) ==="
    echo ""
    python3 << PYEOF
import json
data = json.loads('''${json}''')
found = {k:v for k,v in data.items() if v['email'] == '${email}'}
if not found:
    print("  No entries found for ${email}")
else:
    for key, entry in sorted(found.items()):
        print(f"  Service:  {entry['service']}")
        print(f"  Host:     {entry['host']}")
        print(f"  Username: {entry['username']}")
        print(f"  Password: {'*' * len(entry['password'])}  (use --reveal to show)")
        print(f"  Updated:  {entry.get('updated','')}")
        print()
PYEOF
    log "SHOW: tenant=${tenant} email=${email}"
}

cmd_verify() {
    local tenant="${1:-}"
    [[ -n "$tenant" ]] || die "Usage: gw-accessvaultctl.sh verify <tenant>"
    require_vault "$tenant"

    local json
    if json="$(decrypt_vault "$tenant")"; then
        python3 -c "import json; data=json.loads('''${json}'''); \
print(f'  Vault OK — {len(data)} entries')" && \
        ok "Vault integrity verified: tenant=${tenant}"
    else
        die "Vault decryption failed — vault may be corrupt or passphrase changed"
    fi
    log "VERIFY: tenant=${tenant}"
}

cmd_backup() {
    local tenant="${1:-}"
    [[ -n "$tenant" ]] || die "Usage: gw-accessvaultctl.sh backup <tenant>"
    require_vault "$tenant"

    local backup_file="/tmp/gw-vault-${tenant}-$(date +%Y%m%d%H%M%S).gpg"
    cp "$(vault_file "$tenant")" "$backup_file"
    ok "Vault backed up: ${backup_file}"
    warn "Also back up the passphrase: $(key_file "$tenant")"
    warn "Store vault backup and passphrase SEPARATELY"
    log "BACKUP: tenant=${tenant} file=${backup_file}"
}

cmd_rekey() {
    local tenant="${1:-}"
    [[ -n "$tenant" ]] || die "Usage: gw-accessvaultctl.sh rekey <tenant>"
    require_root
    require_vault "$tenant"

    # Decrypt with old key, re-encrypt with new key
    local json; json="$(decrypt_vault "$tenant")"
    local new_pass; new_pass="$(generate_passphrase)"
    local kf; kf="$(key_file "$tenant")"

    cp "$kf" "${kf}.bak.$(date +%Y%m%d%H%M%S)"
    echo "$new_pass" > "$kf"
    chmod 600 "$kf"
    encrypt_vault "$tenant" "$json"

    ok "Vault re-keyed: tenant=${tenant}"
    warn "Old passphrase backed up at ${kf}.bak.*"
    warn "Update any processes that use the vault passphrase"
    log "REKEY: tenant=${tenant}"
}

# ── Dispatch ──────────────────────────────────────────────────────
case "${1:-}" in
    init)    cmd_init    "${2:-}" ;;
    add)     cmd_add     "${2:-}" "${3:-}" "${4:-}" "${5:-}" "${6:-}" "${7:-}" ;;
    update)  cmd_update  "${2:-}" "${3:-}" "${4:-}" "${5:-}" "${6:-}" ;;
    rotate)  cmd_rotate  "${2:-}" "${3:-}" "${4:-}" "${5:-}" ;;
    remove)  cmd_remove  "${2:-}" "${3:-}" "${4:-}" ;;
    list)    cmd_list    "${2:-}" ;;
    show)    cmd_show    "${2:-}" "${3:-}" ;;
    verify)  cmd_verify  "${2:-}" ;;
    backup)  cmd_backup  "${2:-}" ;;
    rekey)   cmd_rekey   "${2:-}" ;;
    -h|--help|help|"")
        echo ""
        echo "gw-accessvaultctl.sh ${VERSION} — Per-tenant credential vault management"
        echo ""
        echo "Usage:"
        echo "  gw-accessvaultctl.sh init   <tenant>"
        echo "  gw-accessvaultctl.sh add    <tenant> <email> <service> <host> <user> <pass>"
        echo "  gw-accessvaultctl.sh update <tenant> <email> <service> <field> <value>"
        echo "  gw-accessvaultctl.sh rotate <tenant> <email> <service> <new-pass>"
        echo "  gw-accessvaultctl.sh remove <tenant> <email> <service>"
        echo "  gw-accessvaultctl.sh list   <tenant>"
        echo "  gw-accessvaultctl.sh show   <tenant> <email>"
        echo "  gw-accessvaultctl.sh verify <tenant>"
        echo "  gw-accessvaultctl.sh backup <tenant>"
        echo "  gw-accessvaultctl.sh rekey  <tenant>"
        echo ""
        ;;
    *) die "Unknown command: ${1} — run gw-accessvaultctl.sh help" ;;
esac
