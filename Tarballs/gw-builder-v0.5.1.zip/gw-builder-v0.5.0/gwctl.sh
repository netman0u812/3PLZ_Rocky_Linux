#!/usr/bin/env bash
set -euo pipefail

VERSION="0.5.0"
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CONF="${ROOT_DIR}/gw.conf"

# shellcheck source=/dev/null
source "${ROOT_DIR}/modules/00-common.sh"
# shellcheck source=/dev/null
source "${ROOT_DIR}/modules/85-nginx-mtls-wrapper.sh"
# shellcheck source=/dev/null
source "${ROOT_DIR}/modules/72-portal-enroll.sh"
# shellcheck source=/dev/null
source "${ROOT_DIR}/modules/75-inspection-export.sh"
# shellcheck source=/dev/null
source "${ROOT_DIR}/modules/71-pki-revocation.sh"

usage() {
  cat <<EOF
gwctl.sh v${VERSION}

Core:
  $0 -h | --help
  $0 check
  $0 init
  $0 core-setup
  $0 fw-apply

Tenant:
  $0 add-tenant <tenant> --peer <peer_public_ip>
  $0 del-tenant <tenant>
  $0 show-tenant <tenant>
  $0 list-tenants
  $0 tenant-start <tenant>
  $0 tenant-stop <tenant>
  $0 tenant-restart <tenant>
  $0 tenant-status <tenant>
  $0 diag <tenant>

Routing:
  $0 apply-bgp <tenant>

PKI:
  $0 pki-init
  $0 pki-tenant <tenant>
  $0 issue-user <tenant> <email>
  $0 issue-app-cert <tenant> <fqdn>

Catalog (Envoy reverse proxy):
  $0 add-app <tenant> <fqdn> <upstream_ip:port> [inspect=inherit|on|off] [auto_cert=yes|no]
  $0 del-app <tenant> <fqdn>
  $0 list-apps <tenant>

NGINX mTLS + Portal:
  $0 mtls-enable <tenant> [crl=on|off]
  $0 mtls-reload <tenant>
  $0 portal-enable <tenant>
  $0 portal-disable <tenant>
  $0 otp-create <tenant> <email> [ttl_seconds=900]

Inspection Export (Phase 1):
  $0 inspect-export enable|disable

Revocation:
  $0 revoke-user <tenant> <email>
  $0 gen-crl <tenant>
  $0 publish-crl <tenant>
  $0 ocsp-note

EOF
}

require_conf() {
  [[ -f "$CONF" ]] || die "Missing config: $CONF"
  # shellcheck source=/dev/null
  source "$CONF"
}

tenant_conf_path() { echo "${TENANTS_DIR}/${1}.conf"; }


tenant_conf_set_kv() {
  local tconf="$1" key="$2" val="$3"
  if grep -qE "^${key}=" "$tconf"; then
    sed -i "s|^${key}=.*|${key}=\"${val}\"|g" "$tconf"
  else
    echo "${key}=\"${val}\"" >>"$tconf"
  fi
}


cmd_check() { require_conf; check_requirements; }

cmd_init() {
  require_conf
  prompt_for_interfaces_if_needed "$CONF"
  # shellcheck source=/dev/null
  source "$CONF"
  ensure_dirs
  ensure_sysctls
  ensure_packages
  ensure_services
  echo "Init complete. WAN_IF=$WAN_IF LAN_IF=$LAN_IF"
}

cmd_core_setup() {
  require_conf
  ensure_dirs
  run_module "05-core" ""
  run_module "55-tier2-proxies" ""
  run_module "15-firewall-nft" "" apply
  echo "Core setup complete."
}

cmd_fw_apply() { require_conf; run_module "15-firewall-nft" "" apply; }

cmd_add_tenant() {
  require_conf
  local tenant="$1"; shift
  local peer_ip=""

  while [[ $# -gt 0 ]]; do
    case "$1" in
      --peer) peer_ip="$2"; shift 2;;
      *) die "Unknown arg: $1";;
    esac
  done
  [[ -n "$tenant" && -n "$peer_ip" ]] || die "Usage: add-tenant <tenant> --peer <peer_public_ip>"

  local tconf="${TENANTS_DIR}/${tenant}.conf"
  [[ ! -f "$tconf" ]] || die "Tenant already exists: $tenant"

  local idx; idx="$(allocate_tenant_index "$tenant" "$TENANT_INDEX_FILE")"

  echo "Tenant build options for $tenant:"
  read -r -p " Squid mode [${DEFAULT_SQUID_MODE}] explicit|transparent|both: " squid_mode
  squid_mode="${squid_mode:-$DEFAULT_SQUID_MODE}"

  read -r -p " Firewall mode [${DEFAULT_FW_MODE}] permit-all|enforced: " fw_mode
  fw_mode="${fw_mode:-$DEFAULT_FW_MODE}"

  read -r -p " Reverse proxy inspect default [${DEFAULT_REVPROXY_INSPECT}] on|off: " rp_inspect
  rp_inspect="${rp_inspect:-$DEFAULT_REVPROXY_INSPECT}"

  read -r -p " Reverse proxy tap mode [${DEFAULT_TAP_MODE}] logs|tap: " tap_mode
  tap_mode="${tap_mode:-$DEFAULT_TAP_MODE}"

  local ike_lo egress_id vti_net vti_local vti_remote tenant24
  ike_lo="$(alloc_host_from_pool24 "$IKE_LOOPBACK_POOL_CIDR" "$idx")"
  egress_id="$(alloc_host_from_pool24 "$EGRESS_ID_POOL_CIDR" "$idx")"

  vti_net="$(alloc_vti_30_from_pool "$VTI_POOL_CIDR" "$idx")"
  vti_local="$(vti_local_ip "$vti_net")"
  vti_remote="$(vti_remote_ip "$vti_net")"

  tenant24="$(alloc_tenant_subnet24 "$TENANT_NET_BASE_CIDR" "$idx")"
  local lower25 upper25
  read -r lower25 upper25 <<<"$(split_24_to_25s "$tenant24")"

  local squid_vip portal_vip dns_vip
  squid_vip="$(host_in_subnet "$lower25" 1)"
  portal_vip="$(host_in_subnet "$lower25" 2)"
  dns_vip="$(host_in_subnet "$lower25" 3)"

  local table=$((VRF_TABLE_BASE + idx))
  local mark; mark="$(printf "0x%x" $(( (FWMARK_BASE_DEC) + idx )))"

  cat >"$tconf" <<EOF
TENANT="$tenant"
TENANT_INDEX=$idx
PEER_PUBLIC_IP="$peer_ip"

VRF_NAME="vrf-$tenant"
VRF_TABLE=$table
FWMARK="$mark"

IKE_LOOPBACK="${ike_lo}/32"
EGRESS_ID="${egress_id}/32"

VTI_NET="$vti_net"
VTI_LOCAL="${vti_local}/30"
VTI_REMOTE="${vti_remote}"

TENANT_NET="${tenant24}"
TENANT_LOWER25="${lower25}"
TENANT_UPPER25="${upper25}"

SQUID_VIP="${squid_vip}/32"
PORTAL_VIP="${portal_vip}/32"
DNS_VIP="${dns_vip}/32"

TENANT_CORE_LINK_NET="$(alloc_veth_30_from_pool "$TENANT_CORE_VETH_POOL_CIDR" "$idx")"

SQUID_MODE="${squid_mode}"
FW_MODE="${fw_mode}"
REVPROXY_INSPECT="${rp_inspect}"
TAP_MODE="${tap_mode}"
EOF

  run_module "10-tenant-vrf" "$tconf"
  run_module "21-ipsec-managed" "$tconf"
  run_module "30-bgp-frr" "$tconf"
  run_module "70-pki" "$tconf"
  run_module "60-dns-unbound" "$tconf"
  run_module "40-tier1-squid" "$tconf"
  run_module "15-firewall-nft" "$tconf" apply

  echo "Tenant created: $tenant"
  echo "Next:"
  echo "  1) Set PSK in /etc/ipsec.d/tenants/${tenant}.secrets"
  echo "  2) Apply BGP: $0 apply-bgp $tenant"
  echo "  3) Start tenant services: $0 tenant-start $tenant"
}

cmd_del_tenant() {
  require_conf
  local tenant="$1"
  local tconf; tconf="$(tenant_conf_path "$tenant")"
  [[ -f "$tconf" ]] || die "Tenant not found: $tenant"

  systemctl disable --now "envoy-tenant@${tenant}" 2>/dev/null || true

  run_module "40-tier1-squid" "$tconf" --delete
  run_module "60-dns-unbound" "$tconf" --delete
  run_module "70-pki" "$tconf" --delete
  run_module "30-bgp-frr" "$tconf" --delete
  run_module "21-ipsec-managed" "$tconf" --delete
  run_module "10-tenant-vrf" "$tconf" --delete

  rm -f "$tconf"
  deallocate_tenant_index "$tenant" "$TENANT_INDEX_FILE"

  rm -f "${NFT_DIR}/30-tenants/${tenant}.nft" 2>/dev/null || true
  run_module "15-firewall-nft" "" apply

  echo "Tenant deleted: $tenant"
}

cmd_apply_bgp() {
  require_conf
  local tenant="$1"
  local f="${FRR_SNIPPETS_DIR}/${tenant}.bgp.conf"
  [[ -f "$f" ]] || die "No BGP snippet found: $f"
  vtysh -f "$f"
  echo "Applied BGP config for $tenant"
}

cmd_tenant_service() {
  require_conf
  local action="$1" tenant="$2"
  [[ -n "$tenant" ]] || die "Tenant required"
  local tconf; tconf="$(tenant_conf_path "$tenant")"
  [[ -f "$tconf" ]] || die "Tenant not found: $tenant"

  case "$action" in
    start)
      systemctl enable --now "unbound-tenant@${tenant}" || true
      systemctl enable --now "squid-tenant@${tenant}" || true
      systemctl start "envoy-tenant@${tenant}" 2>/dev/null || true
      systemctl start "nginx-tenant@${tenant}" 2>/dev/null || true
      systemctl start "gw-portal@${tenant}" 2>/dev/null || true
      systemctl restart strongswan || true
      ;;
    stop)
      systemctl stop "envoy-tenant@${tenant}" 2>/dev/null || true
      systemctl stop "squid-tenant@${tenant}" || true
      systemctl stop "unbound-tenant@${tenant}" || true
      systemctl stop "gw-portal@${tenant}" 2>/dev/null || true
      systemctl stop "nginx-tenant@${tenant}" 2>/dev/null || true
      ;;
    restart)
      systemctl restart "unbound-tenant@${tenant}" || true
      systemctl restart "squid-tenant@${tenant}" || true
      systemctl restart "envoy-tenant@${tenant}" 2>/dev/null || true
      systemctl restart "gw-portal@${tenant}" 2>/dev/null || true
      systemctl restart "nginx-tenant@${tenant}" 2>/dev/null || true
      systemctl restart strongswan || true
      ;;
    status)
      systemctl --no-pager status "unbound-tenant@${tenant}" || true
      systemctl --no-pager status "squid-tenant@${tenant}" || true
      systemctl --no-pager status "envoy-tenant@${tenant}" 2>/dev/null || true
      systemctl --no-pager status "nginx-tenant@${tenant}" 2>/dev/null || true
      systemctl --no-pager status "gw-portal@${tenant}" 2>/dev/null || true
      ;;
    *) die "Unknown tenant service action: $action";;
  esac
}

cmd_diag() {
  require_conf
  local tenant="$1"
  local tconf; tconf="$(tenant_conf_path "$tenant")"
  [[ -f "$tconf" ]] || die "Tenant not found: $tenant"
  # shellcheck source=/dev/null
  source "$tconf"

  echo "== DIAG tenant=$tenant =="
  echo "-- ipsec status (summary) --"
  ipsec statusall 2>/dev/null | head -n 120 || true

  echo "-- xfrm state/policy --"
  ip xfrm state 2>/dev/null | head -n 120 || true
  ip xfrm policy 2>/dev/null | head -n 120 || true

  echo "-- vrf routes --"
  ip vrf exec "$VRF_NAME" ip route || true
  echo "-- core routes --"
  ip vrf exec "$CORE_VRF_NAME" ip route || true

  echo "-- bgp summary (if available) --"
  vtysh -c "show bgp vrf $tenant summary" 2>/dev/null || true

  echo "-- services --"
  systemctl --no-pager status "unbound-tenant@${tenant}" || true
  systemctl --no-pager status "squid-tenant@${tenant}" || true
  systemctl --no-pager status "envoy-tenant@${tenant}" 2>/dev/null || true

  echo "-- firewall (first 200 lines) --"
  nft list ruleset | head -n 200 || true

  echo "-- catalog vip set (if enforced) --"
  nft list set inet gw "catalog_vips_${tenant}" 2>/dev/null || true
}

cmd_add_app() {
  require_conf
  local tenant="$1" fqdn="$2" upstream="$3" inspect="${4:-inherit}" auto_cert="${5:-no}"
  local tconf; tconf="$(tenant_conf_path "$tenant")"
  [[ -f "$tconf" ]] || die "Tenant not found: $tenant"
  run_module "80-app-envoy" "$tconf" add-app "$fqdn" "$upstream" "$inspect" "$auto_cert"
  # If tenant mTLS NGINX plane is enabled, create/update VIP listener for this app.
  # shellcheck source=/dev/null
  source "$tconf"
  if [[ "${NGINX_MTLS_MODE:-off}" == "on" ]]; then
    local apps_file="${APPS_DIR}/${tenant}.apps"
    if [[ -f "$apps_file" ]]; then
      local line; line="$(grep -E "^${fqdn} " "$apps_file" | tail -n 1 || true)"
      if [[ -n "$line" ]]; then
        local _fqdn vip _upstream _insp
        read -r _fqdn vip _upstream _insp <<<"$line"
        write_nginx_app_server "$tenant" "$fqdn" "$vip" "$_upstream" "$_insp"
        nginx_tenant_reload "$tenant"
      fi
    fi
  fi
}

cmd_del_app() {
  require_conf
  local tenant="$1" fqdn="$2"
  local tconf; tconf="$(tenant_conf_path "$tenant")"
  [[ -f "$tconf" ]] || die "Tenant not found: $tenant"
  run_module "80-app-envoy" "$tconf" del-app "$fqdn"
}

cmd_list_apps() {
  require_conf
  local tenant="$1"
  local tconf; tconf="$(tenant_conf_path "$tenant")"
  [[ -f "$tconf" ]] || die "Tenant not found: $tenant"
  run_module "80-app-envoy" "$tconf" list-apps
}

cmd_pki_init() { require_conf; ensure_dirs; run_module "70-pki" "" --root-only; }
cmd_pki_tenant(){ require_conf; local tconf; tconf="$(tenant_conf_path "$1")"; run_module "70-pki" "$tconf" --tenant-only; }
cmd_issue_user(){ require_conf; local tconf; tconf="$(tenant_conf_path "$1")"; run_module "70-pki" "$tconf" --issue-user "$2"; }
cmd_issue_app_cert(){ require_conf; local tconf; tconf="$(tenant_conf_path "$1")"; run_module "70-pki" "$tconf" --issue-app-cert "$2"; }

cmd_show_tenant(){ require_conf; cat "$(tenant_conf_path "$1")"; }
cmd_list_tenants(){ require_conf; ls -1 "$TENANTS_DIR"/*.conf 2>/dev/null | sed 's#.*/##; s/\.conf$//' || true; }


cmd_mtls_enable() {
  require_conf
  local tenant="$1" crl="${2:-off}"
  [[ -n "$tenant" ]] || die "Usage: mtls-enable <tenant> [crl=on|off]"
  local tconf; tconf="$(tenant_conf_path "$tenant")"
  [[ -f "$tconf" ]] || die "Tenant not found: $tenant"

  # Load tenant conf for VIPs and PKI paths
  # shellcheck source=/dev/null
  source "$tconf"

  # Determine CA bundle path for client verification
  local ca_chain="/etc/gateway/pki/${tenant}/intermediate/certs/ca-chain.cert.pem"
  local ca_int="/etc/gateway/pki/${tenant}/intermediate/certs/intermediate.cert.pem"
  local ca_pem="$ca_chain"
  [[ -f "$ca_pem" ]] || ca_pem="$ca_int"

  tenant_conf_set_kv "$tconf" "NGINX_MTLS_MODE" "on"
  tenant_conf_set_kv "$tconf" "CRL_ENFORCE" "${crl}"
  tenant_conf_set_kv "$tconf" "TENANT_CA_PEM" "${ca_pem}"

  # Ensure portal cert exists (signed by tenant CA) via PKI module; store under portal/
  mkdir -p "/etc/gateway/tls/${tenant}/portal"
  if [[ ! -f "/etc/gateway/tls/${tenant}/portal/cert.pem" || ! -f "/etc/gateway/tls/${tenant}/portal/key.pem" ]]; then
    # generate portal cert as an "app" cert then copy
    /opt/gw-builder/modules/70-pki.sh "$tconf" --issue-app-cert "portal.${tenant}.local" || true
    local src_dir="/etc/gateway/tls/${tenant}/apps/portal.${tenant}.local"
    if [[ -f "${src_dir}/cert.pem" && -f "${src_dir}/key.pem" ]]; then
      cp -f "${src_dir}/cert.pem" "/etc/gateway/tls/${tenant}/portal/cert.pem"
      cp -f "${src_dir}/key.pem"  "/etc/gateway/tls/${tenant}/portal/key.pem"
      chmod 600 "/etc/gateway/tls/${tenant}/portal/key.pem"
    else
      warn "Portal cert not found under ${src_dir}; you may need to issue it manually."
    fi
  fi

  ensure_nginx_base
  write_nginx_tenant_conf "$tenant"
  nginx_tenant_enable "$tenant"

  echo "mTLS enabled for tenant ${tenant} (CRL_ENFORCE=${crl})"
}

cmd_mtls_reload() {
  require_conf
  local tenant="$1"
  [[ -n "$tenant" ]] || die "Usage: mtls-reload <tenant>"
  local tconf; tconf="$(tenant_conf_path "$tenant")"
  [[ -f "$tconf" ]] || die "Tenant not found: $tenant"
  write_nginx_tenant_conf "$tenant"
  nginx_tenant_reload "$tenant"
  echo "NGINX tenant config reloaded for ${tenant}"
}

cmd_portal_enable() {
  require_conf
  local tenant="$1"
  [[ -n "$tenant" ]] || die "Usage: portal-enable <tenant>"
  local tconf; tconf="$(tenant_conf_path "$tenant")"
  [[ -f "$tconf" ]] || die "Tenant not found: $tenant"

  # portal backend (127.0.0.1:9443 inside tenant VRF)
  portal_enable "$tenant"

  # ensure NGINX tenant is present; if not, enable mTLS with defaults
  if ! systemctl is-enabled "nginx-tenant@${tenant}" >/dev/null 2>&1; then
    cmd_mtls_enable "$tenant" "off"
  else
    cmd_mtls_reload "$tenant"
  fi

  echo "Portal enabled for tenant ${tenant} at PORTAL_VIP:443"
}

cmd_portal_disable() {
  require_conf
  local tenant="$1"
  [[ -n "$tenant" ]] || die "Usage: portal-disable <tenant>"
  portal_disable "$tenant"
  echo "Portal disabled for tenant ${tenant}"
}

cmd_otp_create() {
  require_conf
  local tenant="$1" email="$2" ttl="${3:-900}"
  [[ -n "$tenant" && -n "$email" ]] || die "Usage: otp-create <tenant> <email> [ttl_seconds=900]"

  local token
  token="$(tr -dc 'A-Z2-7' </dev/urandom | head -c 22)"
  local now exp
  now="$(date +%s)"
  exp="$((now + ttl))"

  local dir="/etc/gateway/portal/${tenant}/tokens"
  mkdir -p "$dir"
  cat >"${dir}/${token}.json" <<EOF
{"tenant":"${tenant}","email":"${email}","iat":${now},"exp":${exp},"used":false}
EOF
  chmod 600 "${dir}/${token}.json"

  echo "OTP created (share out-of-band):"
  echo "  tenant: ${tenant}"
  echo "  email:  ${email}"
  echo "  token:  ${token}"
  echo "  exp:    ${exp} (epoch)"
}

cmd_inspect_export() {
  require_conf
  local action="$1"
  case "$action" in
    enable) inspect_export_enable;;
    disable) inspect_export_disable;;
    *) die "Usage: inspect-export enable|disable";;
  esac
}

cmd_revoke_user() {
  require_conf
  local tenant="$1" email="$2"
  [[ -n "$tenant" && -n "$email" ]] || die "Usage: revoke-user <tenant> <email>"
  pki_revoke_user "$tenant" "$email"
  echo "Revoked user cert for ${email} in tenant ${tenant} and regenerated CRL."
}

cmd_gen_crl() {
  require_conf
  local tenant="$1"
  [[ -n "$tenant" ]] || die "Usage: gen-crl <tenant>"
  pki_gen_crl "$tenant"
  echo "Generated CRL for tenant ${tenant}"
}

cmd_publish_crl() {
  require_conf
  local tenant="$1"
  [[ -n "$tenant" ]] || die "Usage: publish-crl <tenant>"
  pki_publish_crl "$tenant"
  echo "Published CRL for tenant ${tenant}"
}

cmd_ocsp_note() {
  require_conf
  pki_ocsp_note
}


main() {
  [[ $# -ge 1 ]] || { usage; exit 1; }
  case "$1" in
    -h|--help) usage;;
    check) cmd_check;;
    init) cmd_init;;
    core-setup) cmd_core_setup;;
    fw-apply) cmd_fw_apply;;

    add-tenant) shift; cmd_add_tenant "$@";;
    del-tenant) shift; cmd_del_tenant "$@";;
    show-tenant) shift; cmd_show_tenant "$@";;
    list-tenants) shift; cmd_list_tenants;;

    tenant-start) shift; cmd_tenant_service start "$@";;
    tenant-stop) shift; cmd_tenant_service stop "$@";;
    tenant-restart) shift; cmd_tenant_service restart "$@";;
    tenant-status) shift; cmd_tenant_service status "$@";;
    diag) shift; cmd_diag "$@";;

    apply-bgp) shift; cmd_apply_bgp "$@";;

    pki-init) shift; cmd_pki_init;;
    pki-tenant) shift; cmd_pki_tenant "$@";;
    issue-user) shift; cmd_issue_user "$@";;
    issue-app-cert) shift; cmd_issue_app_cert "$@";;

    add-app) shift; cmd_add_app "$@";;
    del-app) shift; cmd_del_app "$@";;
    list-apps) shift; cmd_list_apps "$@";;

mtls-enable) shift; cmd_mtls_enable "$@";;
mtls-reload) shift; cmd_mtls_reload "$@";;
portal-enable) shift; cmd_portal_enable "$@";;
portal-disable) shift; cmd_portal_disable "$@";;
otp-create) shift; cmd_otp_create "$@";;

inspect-export) shift; cmd_inspect_export "$@";;

revoke-user) shift; cmd_revoke_user "$@";;
gen-crl) shift; cmd_gen_crl "$@";;
publish-crl) shift; cmd_publish_crl "$@";;
ocsp-note) shift; cmd_ocsp_note;;

    *) usage; die "Unknown command: $1";;
  esac
}

main "$@"
