Gateway Builder (Rocky Linux 9)
Script Bundle Version: 0.4.2

What this builds
- Multi-tenant secure gateway with:
  - strongSwan IKEv2 PSK route-based tunnels (VTI)
  - Per-tenant VRFs (Linux VRF) for isolation
  - Per-tenant BGP over VTI (FRR zebra/bgpd)
  - Per-tenant DNS (Unbound) with conditional forward + rewrite overrides
  - Per-tenant Squid forward proxy (explicit CONNECT; optional transparent HTTP intercept)
  - Per-tenant Envoy reverse proxy catalog VIPs (upper /25), inspection via TLS termination optional
  - PKI: Root CA -> Tenant intermediate -> User mTLS certs; per-app MITM certs (SAN DNS:FQDN)
  - nftables firewall with per-tenant modes:
      permit-all: bootstrap; broad allowances within guardrails
      enforced  : least-privilege; reverse proxy VIPs allowed only if created in catalog

Install location
- Recommended: /opt/gw-builder
- Bundle includes files exactly as installed under /opt/gw-builder:
  gw.conf
  gwctl.sh
  modules/*.sh

Quick start (as root)
1) Place bundle at /opt/gw-builder and make executable:
   chmod +x /opt/gw-builder/gwctl.sh /opt/gw-builder/modules/*.sh

2) Initialize host (prompts for WAN/LAN if not set in gw.conf):
   /opt/gw-builder/gwctl.sh init

3) Core setup:
   /opt/gw-builder/gwctl.sh core-setup

4) Add tenant:
   /opt/gw-builder/gwctl.sh add-tenant tenantA --peer 203.0.113.50
   - prompts for squid mode, firewall mode, reverse proxy inspect default, tap mode
   - then edit PSK:
       /etc/ipsec.d/tenants/tenantA.secrets
   - apply BGP:
       /opt/gw-builder/gwctl.sh apply-bgp tenantA
   - start services:
       /opt/gw-builder/gwctl.sh tenant-start tenantA

Catalog reverse proxy (Envoy)
- Issue per-app cert (for MITM inspection / TLS termination):
   /opt/gw-builder/gwctl.sh issue-app-cert tenantA sap.outlan.net

- Add app VIP + DNS rewrite + Envoy listener:
   /opt/gw-builder/gwctl.sh add-app tenantA sap.outlan.net 10.99.40.7:443 on yes
   Arguments:
     inspect: inherit|on|off
     auto_cert: yes|no (issues per-app cert if inspect resolves to on)

- List/delete apps:
   /opt/gw-builder/gwctl.sh list-apps tenantA
   /opt/gw-builder/gwctl.sh del-app tenantA sap.outlan.net

Firewall behavior (v0.4.2)
- permit-all: tenant subnet broadly allowed (still guarded on WAN)
- enforced:
   - DNS VIP (53) allowed
   - Squid VIP (3128) allowed
   - Catalog VIPs (443) allowed ONLY if created via add-app
     (VIPs are maintained in nft set: inet gw catalog_vips_<tenant>)
   - Tenant->core veth transit allowed

Diagnostics
- /opt/gw-builder/gwctl.sh diag tenantA

Transparent proxy note
- This bundle supports transparent HTTP intercept via nft/iptables REDIRECT to Squid intercept port.
- Transparent HTTPS without MITM is not implemented; use explicit CONNECT unless you deliberately add MITM.

Envoy package
- The bundle checks if 'envoy' RPM is installed.
- If missing, install from an approved vendor repo for Rocky/RHEL 9, then re-run:
   /opt/gw-builder/gwctl.sh check

Files and generated state
- Tenant configs:
   /etc/gateway/tenants.d/<tenant>.conf
- DNS configs:
   /etc/unbound/tenants/<tenant>/
- Envoy configs:
   /etc/envoy/tenants/<tenant>/
- PKI:
   /etc/gateway/pki/
- TLS (issued certs/keys):
   /etc/gateway/tls/<tenant>/
- Firewall:
   /etc/nftables.conf
   /etc/nftables.d/


=== v0.5.0 Additions (Critical Functions Phase 1) ===
- Tenant mTLS enforcement plane using NGINX per tenant (nginx-tenant@TENANT)
- Enrollment portal backend (gw-portal@TENANT) supporting OTP token + CSR signing workflow (Phase 1)
- Inspection export Phase 1: rsyslog forwarding of NGINX/Squid/Envoy logs to external collector
- PKI revocation (CRL): revoke-user, gen-crl, publish-crl; optional NGINX CRL enforcement toggle

New/updated modules:
- modules/85-nginx-mtls-wrapper.sh
- modules/72-portal-enroll.sh
- modules/75-inspection-export.sh
- modules/71-pki-revocation.sh

NOTE: SAML/OIDC integration is a Phase 2 enhancement. Phase 1 uses admin-generated OTP tokens.
