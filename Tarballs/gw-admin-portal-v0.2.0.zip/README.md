# gw-admin-portal v0.2.0

Adds:
- connect / gateway-exec wrappers (sudo-run, no admin access to private keys)
- portal-managed SSH key rotation (24h) + systemd timer
- 4h session enforcement via timeout
- gwctl VLAN-preflight wiring helper
- user/admin guides

Generated: 20260218-232939
