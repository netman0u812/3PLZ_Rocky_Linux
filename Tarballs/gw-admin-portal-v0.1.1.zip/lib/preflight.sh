\
#!/usr/bin/env bash
set -euo pipefail

log(){ echo "[preflight] $*"; }
die(){ echo "ERROR: $*" >&2; exit 1; }

check_root(){
  [[ "${EUID:-$(id -u)}" -eq 0 ]] || die "Run as root"
}

check_cmd(){
  command -v "$1" >/dev/null 2>&1 || die "Missing command: $1"
}

check_vlan_support(){
  log "Checking 802.1Q VLAN support..."

  if ! lsmod | grep -q '^8021q'; then
    log "8021q module not loaded; loading"
    modprobe 8021q || die "Unable to load 8021q module"
  fi

  mkdir -p /etc/modules-load.d
  if [[ ! -f /etc/modules-load.d/8021q.conf ]] || ! grep -q '^8021q$' /etc/modules-load.d/8021q.conf; then
    echo "8021q" > /etc/modules-load.d/8021q.conf
    log "Persisted: /etc/modules-load.d/8021q.conf"
  fi

  log "802.1Q support OK"
}

check_nm_running(){
  check_cmd nmcli
  nmcli general status >/dev/null 2>&1 || die "NetworkManager not responding"
}

warn_trunk_assumption(){
  local trunk_if="$1"
  log "NOTE: Upstream switch port on ${trunk_if} must be configured as a TRUNK (tagged) allowing VLAN IDs you set."
}
