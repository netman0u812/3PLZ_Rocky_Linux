#!/usr/bin/env bash
set -euo pipefail
# gw-inspectctl.sh — v0.1.0
VERSION="0.1.0"

die(){ echo "ERROR: $*" >&2; exit 1; }
usage(){
  cat <<'EOF'
gw-inspectctl.sh (v0.1.0)

Usage:
  gw-inspectctl.sh apply  <tenant>
  gw-inspectctl.sh remove <tenant>
  gw-inspectctl.sh status <tenant>

Reads:
  /opt/gw-builder/tenants/<tenant>.conf

Required (tap):
  INSPECTION_EXPORT_MODE=tap
  DECRYPT_IFACE=dec-<tenant>
  INSPECTION_TAP_TYPE=erspan|vxlan
  INSPECTION_TAP_DST_IP=<appliance>
  INSPECTION_TAP_KEY=<erspan key or vxlan vni>
Optional:
  INSPECTION_TAP_RATE_BPS=<0 unlimited>
EOF
}

CMD="${1:-}"
TENANT="${2:-}"
[[ -n "$CMD" ]] || { usage; exit 1; }
[[ -n "$TENANT" ]] || die "tenant required"

CONF="/opt/gw-builder/tenants/${TENANT}.conf"
[[ -f "$CONF" ]] || die "tenant conf not found: $CONF"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck disable=SC1090
source "${SCRIPT_DIR}/inspect-tap.sh"

mode="$(grep -E '^INSPECTION_EXPORT_MODE=' "$CONF" | tail -n1 | cut -d= -f2- || echo off)"
case "$CMD" in
  apply)
    [[ "$mode" == "tap" || "$mode" == "tap+nflog" ]] || { echo "Mode=$mode; nothing to do."; exit 0; }
    tap_apply "$TENANT" "$CONF"
    ;;
  remove) tap_remove "$TENANT" "$CONF" ;;
  status) tap_status "$TENANT" "$CONF" ;;
  -h|--help|help) usage ;;
  *) die "Unknown command: $CMD" ;;
esac
