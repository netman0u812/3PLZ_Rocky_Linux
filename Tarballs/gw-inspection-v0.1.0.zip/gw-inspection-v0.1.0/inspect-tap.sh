#!/usr/bin/env bash
set -euo pipefail
# inspect-tap.sh — v0.1.0
die(){ echo "ERROR: $*" >&2; exit 1; }
kv(){ local k="$1" f="$2"; grep -E "^${k}=" "$f" | tail -n1 | cut -d= -f2- || true; }
tap_ifname(){ local tenant="$1" type="$2"; echo "${type}-${tenant}"; }

ensure_tc_ingress(){ local dev="$1"; tc qdisc add dev "$dev" ingress 2>/dev/null || true; }

tap_apply(){
  local tenant="$1" conf="$2"
  local dev type dst key rate
  dev="$(kv DECRYPT_IFACE "$conf")"
  type="$(kv INSPECTION_TAP_TYPE "$conf")"
  dst="$(kv INSPECTION_TAP_DST_IP "$conf")"
  key="$(kv INSPECTION_TAP_KEY "$conf")"
  rate="$(kv INSPECTION_TAP_RATE_BPS "$conf")"
  [[ -n "$dev" ]] || die "DECRYPT_IFACE missing"
  [[ -n "$type" ]] || type="erspan"
  [[ -n "$dst" && "$dst" != "0.0.0.0" ]] || die "INSPECTION_TAP_DST_IP must be set"
  [[ -n "$key" && "$key" != "0" ]] || die "INSPECTION_TAP_KEY must be set"
  [[ -n "$rate" ]] || rate="0"

  ip link show "$dev" >/dev/null 2>&1 || die "DECRYPT_IFACE not found: $dev"

  local tif
  tif="$(tap_ifname "$tenant" "$type")"

  if [[ "$type" == "erspan" ]]; then
    ip link show "$tif" >/dev/null 2>&1 || ip link add "$tif" type erspan remote "$dst" key "$key" erspan_ver 2
  elif [[ "$type" == "vxlan" ]]; then
    ip link show "$tif" >/dev/null 2>&1 || ip link add "$tif" type vxlan id "$key" remote "$dst" dstport 4789
  else
    die "Unsupported INSPECTION_TAP_TYPE: $type"
  fi
  ip link set "$tif" up

  ensure_tc_ingress "$dev"
  tc filter del dev "$dev" ingress 2>/dev/null || true

  if [[ "$rate" != "0" ]]; then
    tc filter add dev "$dev" ingress protocol all prio 10 flower       action police rate "${rate}bps" burst 1m conform-exceed drop       action mirred egress mirror dev "$tif"
  else
    tc filter add dev "$dev" ingress protocol all prio 10 flower       action mirred egress mirror dev "$tif"
  fi

  echo "Applied tap: tenant=$tenant dev=$dev tunnel=$tif dst=$dst key=$key rate_bps=$rate"
}

tap_remove(){
  local tenant="$1" conf="$2"
  local dev type
  dev="$(kv DECRYPT_IFACE "$conf")"
  type="$(kv INSPECTION_TAP_TYPE "$conf")"
  [[ -n "$type" ]] || type="erspan"
  local tif
  tif="$(tap_ifname "$tenant" "$type")"

  if [[ -n "$dev" ]]; then
    tc filter del dev "$dev" ingress 2>/dev/null || true
    tc qdisc del dev "$dev" ingress 2>/dev/null || true
  fi
  ip link del "$tif" 2>/dev/null || true
  echo "Removed tap: tenant=$tenant dev=$dev tunnel=$tif"
}

tap_status(){
  local tenant="$1" conf="$2"
  local dev type
  dev="$(kv DECRYPT_IFACE "$conf")"
  type="$(kv INSPECTION_TAP_TYPE "$conf")"
  [[ -n "$type" ]] || type="erspan"
  local tif
  tif="$(tap_ifname "$tenant" "$type")"
  echo "tenant=$tenant dev=$dev tunnel=$tif type=$type"
  ip -d link show "$tif" 2>/dev/null || echo "(tunnel missing)"
  tc -s filter show dev "$dev" ingress 2>/dev/null || true
}
