GW Inspection Export Add-on (Option A) — v0.1.0
==============================================

Install
-------
Copy to /opt/gw-inspection:
  sudo mkdir -p /opt/gw-inspection
  sudo cp gw-inspectctl.sh inspect-tap.sh README.txt /opt/gw-inspection/
  sudo chmod +x /opt/gw-inspection/*.sh

Configure (per tenant)
----------------------
Edit /opt/gw-builder/tenants/<tenant>.conf:

  INSPECTION_EXPORT_MODE=tap
  DECRYPT_IFACE=dec-<tenant>
  INSPECTION_TAP_TYPE=erspan
  INSPECTION_TAP_DST_IP=<appliance-ip>
  INSPECTION_TAP_KEY=<unique-key-per-tenant>
  INSPECTION_TAP_RATE_BPS=0

Run
---
  sudo /opt/gw-inspection/gw-inspectctl.sh apply <tenant>
  /opt/gw-inspection/gw-inspectctl.sh status <tenant>
  sudo /opt/gw-inspection/gw-inspectctl.sh remove <tenant>

Notes
-----
- Mirrors are fail-open: forwarding continues even if mirror drops.
- Use unique key/VNI per tenant to preserve isolation.
