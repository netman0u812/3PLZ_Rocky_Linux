#!/usr/bin/env bash
set -euo pipefail
PREFIX="/opt/gw-inspection"
mkdir -p "$PREFIX"
install -m 0755 gw-inspectctl.sh "$PREFIX/gw-inspectctl.sh"
install -m 0755 inspect-tap.sh "$PREFIX/inspect-tap.sh"
install -m 0644 README.txt "$PREFIX/README.txt"
echo "Installed to $PREFIX"
