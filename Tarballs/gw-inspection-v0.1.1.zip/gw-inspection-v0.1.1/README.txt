GW Inspection Export Add-on (Option A) — v0.1.1
==============================================

Purpose
-------
Per-tenant export of decrypted traffic to an external DPI appliance without modifying GW core.
Mirrors packets on the tenant plaintext hop (DECRYPT_IFACE) using tc mirred, exporting copies via
ERSPAN or VXLAN.

New in v0.1.1
-------------
- Bidirectional mirroring: tc ingress + egress (clsact)
- nftables allow-list guardrail:
  - optional collector IP allow-list (comma-separated)
  - optional egress-interface scoping to safely add a drop rule

Install
-------
Copy to /opt/gw-inspection:
  sudo mkdir -p /opt/gw-inspection
  sudo cp gw-inspectctl.sh inspect-tap.sh README.txt /opt/gw-inspection/
  sudo chmod +x /opt/gw-inspection/*.sh

Per-tenant configuration
------------------------
Edit /opt/gw-builder/tenants/<tenant>.conf:

  INSPECTION_EXPORT_MODE=tap
  DECRYPT_IFACE=dec-<tenant>

  INSPECTION_TAP_TYPE=erspan
  INSPECTION_TAP_DST_IP=<appliance-ip>
  INSPECTION_TAP_KEY=<unique-key-per-tenant>
  INSPECTION_TAP_RATE_BPS=0

  # Allow-list guardrail (optional)
  INSPECTION_TAP_ALLOWLIST=<comma-separated collector IPs>
  INSPECTION_TAP_EGRESS_IF=eth0

Notes:
- The allow-list adds ACCEPT rules for allowed collectors.
- A DROP rule is only added when INSPECTION_TAP_EGRESS_IF is set (to avoid broad impact).
