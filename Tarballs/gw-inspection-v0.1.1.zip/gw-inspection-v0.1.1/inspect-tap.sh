#!/usr/bin/env bash
set -euo pipefail
# inspect-tap.sh — v0.1.1
die(){ echo "ERROR: $*" >&2; exit 1; }
kv(){ local k="$1" f="$2"; grep -E "^${k}=" "$f" | tail -n1 | cut -d= -f2- || true; }
tap_ifname(){ local tenant="$1" type="$2"; echo "${type}-${tenant}"; }

ensure_ingress(){ local dev="$1"; tc qdisc add dev "$dev" ingress 2>/dev/null || true; }
ensure_clsact(){ local dev="$1"; tc qdisc add dev "$dev" clsact 2>/dev/null || true; }

ALLOW_TABLE="gw_inspect_allow"
ALLOW_CHAIN="output_guard"

nft_allow_apply() {
  local tenant="$1" dst="$2" allowlist="$3" eif="$4"
  [[ -n "$allowlist" ]] || allowlist="$dst"

  nft list table inet "$ALLOW_TABLE" >/dev/null 2>&1 || nft -f - <<EOF
table inet $ALLOW_TABLE {
  chain $ALLOW_CHAIN {
    type filter hook output priority 0; policy accept;
  }
}
EOF

  # delete prior tenant rules by comment handle
  while read -r handle; do
    [[ -n "$handle" ]] || continue
    nft delete rule inet "$ALLOW_TABLE" "$ALLOW_CHAIN" handle "$handle" 2>/dev/null || true
  done < <(nft -a list chain inet "$ALLOW_TABLE" "$ALLOW_CHAIN" 2>/dev/null | awk -v t="$tenant" '/comment "gw-inspect:'"$tenant"'"/ {print $NF}')

  # add allow rules (scoped to egress IF if provided)
  IFS=',' read -ra ips <<<"$allowlist"
  for ip in "${ips[@]}"; do
    ip="$(echo "$ip" | xargs)"
    [[ -n "$ip" ]] || continue
    if [[ -n "$eif" ]]; then
      nft add rule inet "$ALLOW_TABLE" "$ALLOW_CHAIN" oifname "$eif" ip daddr "$ip" accept comment "gw-inspect:${tenant}"
    else
      nft add rule inet "$ALLOW_TABLE" "$ALLOW_CHAIN" ip daddr "$ip" accept comment "gw-inspect:${tenant}"
    fi
  done

  # Only add an explicit drop when egress IF is specified (safer).
  if [[ -n "$eif" ]]; then
    local set_elems
    set_elems="$(printf "%s, " "${ips[@]}" | sed 's/, $//')"
    nft add rule inet "$ALLOW_TABLE" "$ALLOW_CHAIN" oifname "$eif" ip daddr != { $set_elems } drop comment "gw-inspect:${tenant}"
  fi
}

nft_allow_remove() {
  local tenant="$1"
  nft list table inet "$ALLOW_TABLE" >/dev/null 2>&1 || return 0
  while read -r handle; do
    [[ -n "$handle" ]] || continue
    nft delete rule inet "$ALLOW_TABLE" "$ALLOW_CHAIN" handle "$handle" 2>/dev/null || true
  done < <(nft -a list chain inet "$ALLOW_TABLE" "$ALLOW_CHAIN" 2>/dev/null | awk -v t="$tenant" '/comment "gw-inspect:'"$tenant"'"/ {print $NF}')
}

apply_mirror() {
  local dev="$1" tif="$2" rate="$3"
  # ingress
  ensure_ingress "$dev"
  tc filter del dev "$dev" ingress 2>/dev/null || true
  if [[ "$rate" != "0" ]]; then
    tc filter add dev "$dev" ingress protocol all prio 10 flower       action police rate "${rate}bps" burst 1m conform-exceed drop       action mirred egress mirror dev "$tif"
  else
    tc filter add dev "$dev" ingress protocol all prio 10 flower       action mirred egress mirror dev "$tif"
  fi

  # egress via clsact
  ensure_clsact "$dev"
  tc filter del dev "$dev" egress 2>/dev/null || true
  if [[ "$rate" != "0" ]]; then
    tc filter add dev "$dev" egress protocol all prio 10 flower       action police rate "${rate}bps" burst 1m conform-exceed drop       action mirred egress mirror dev "$tif"
  else
    tc filter add dev "$dev" egress protocol all prio 10 flower       action mirred egress mirror dev "$tif"
  fi
}

tap_apply() {
  local tenant="$1" conf="$2"
  local dev type dst key rate allowlist eif
  dev="$(kv DECRYPT_IFACE "$conf")"
  type="$(kv INSPECTION_TAP_TYPE "$conf")"; [[ -n "$type" ]] || type="erspan"
  dst="$(kv INSPECTION_TAP_DST_IP "$conf")"
  key="$(kv INSPECTION_TAP_KEY "$conf")"
  rate="$(kv INSPECTION_TAP_RATE_BPS "$conf")"; [[ -n "$rate" ]] || rate="0"
  allowlist="$(kv INSPECTION_TAP_ALLOWLIST "$conf")"
  eif="$(kv INSPECTION_TAP_EGRESS_IF "$conf")"

  [[ -n "$dev" ]] || die "DECRYPT_IFACE missing"
  [[ -n "$dst" && "$dst" != "0.0.0.0" ]] || die "INSPECTION_TAP_DST_IP must be set"
  [[ -n "$key" && "$key" != "0" ]] || die "INSPECTION_TAP_KEY must be set"
  ip link show "$dev" >/dev/null 2>&1 || die "DECRYPT_IFACE not found: $dev"

  local tif
  tif="$(tap_ifname "$tenant" "$type")"

  if [[ "$type" == "erspan" ]]; then
    ip link show "$tif" >/dev/null 2>&1 || ip link add "$tif" type erspan remote "$dst" key "$key" erspan_ver 2
  elif [[ "$type" == "vxlan" ]]; then
    ip link show "$tif" >/dev/null 2>&1 || ip link add "$tif" type vxlan id "$key" remote "$dst" dstport 4789
  else
    die "Unsupported INSPECTION_TAP_TYPE: $type"
  fi
  ip link set "$tif" up

  apply_mirror "$dev" "$tif" "$rate"

  # allow-list guardrail (optional)
  if [[ -n "$allowlist" || -n "$eif" ]]; then
    nft_allow_apply "$tenant" "$dst" "$allowlist" "$eif"
  fi

  echo "Applied tap (bidir): tenant=$tenant dev=$dev tunnel=$tif dst=$dst key=$key rate_bps=$rate"
}

tap_remove() {
  local tenant="$1" conf="$2"
  local dev type
  dev="$(kv DECRYPT_IFACE "$conf")"
  type="$(kv INSPECTION_TAP_TYPE "$conf")"; [[ -n "$type" ]] || type="erspan"
  local tif
  tif="$(tap_ifname "$tenant" "$type")"

  if [[ -n "$dev" ]]; then
    tc filter del dev "$dev" ingress 2>/dev/null || true
    tc filter del dev "$dev" egress 2>/dev/null || true
    tc qdisc del dev "$dev" ingress 2>/dev/null || true
    tc qdisc del dev "$dev" clsact 2>/dev/null || true
  fi
  ip link del "$tif" 2>/dev/null || true
  nft_allow_remove "$tenant" || true
  echo "Removed tap: tenant=$tenant dev=$dev tunnel=$tif"
}

tap_status() {
  local tenant="$1" conf="$2"
  local dev type
  dev="$(kv DECRYPT_IFACE "$conf")"
  type="$(kv INSPECTION_TAP_TYPE "$conf")"; [[ -n "$type" ]] || type="erspan"
  local tif
  tif="$(tap_ifname "$tenant" "$type")"
  echo "tenant=$tenant dev=$dev tunnel=$tif type=$type"
  ip -d link show "$tif" 2>/dev/null || echo "(tunnel missing)"
  if [[ -n "$dev" ]]; then
    tc -s filter show dev "$dev" ingress 2>/dev/null || true
    tc -s filter show dev "$dev" egress 2>/dev/null || true
  fi
  nft list table inet "$ALLOW_TABLE" 2>/dev/null || true
}
