#!/bin/bash
# gw-totp-setup.sh — Configure PAM + Google Authenticator TOTP for portal SSH login.
# Run once on the Admin Portal node after gw-admin-portal is installed.
# Usage:
#   gw-totp-setup.sh install          # Install PAM module + configure SSH
#   gw-totp-setup.sh enroll <user>    # Enroll a user (generates QR + secret)
#   gw-totp-setup.sh verify <user>    # Verify TOTP is working for a user
#   gw-totp-setup.sh revoke  <user>   # Remove TOTP for a user
#   gw-totp-setup.sh status           # Show enrollment status for all admin users
set -euo pipefail

# ── Portable compatibility (Linux + macOS) ──────────────────────
sha256_cmd() {
  if command -v sha256sum >/dev/null 2>&1; then sha256sum "$@"; else shasum -a 256 "$@"; fi
}
isotime() {
  python3 -c "from datetime import datetime,timezone; print(datetime.now(timezone.utc).astimezone().isoformat(timespec='seconds'))"
}
# ─────────────────────────────────────────────────────────────────

CONF="${CONF:-/etc/gw-admin-portal/admin-portal.conf}"
PAM_SSHD=/etc/pam.d/sshd
SSHD_CONF=/etc/ssh/sshd_config
SSHD_DROPIN=/etc/ssh/sshd_config.d/gw-totp.conf
LOG=/var/log/gw-totp-setup.log

die()  { echo "ERROR: $*" >&2; exit 1; }
log()  { echo "[$(isotime)] $*" | tee -a "$LOG"; }
need() { command -v "$1" >/dev/null 2>&1 || die "Missing: $1"; }

require_root() { [[ "${EUID:-$(id -u)}" -eq 0 ]] || die "Run as root"; }

# Load admin users list from portal conf if available
load_admin_users() {
  ADMIN_USERS_LIST=()
  if [[ -f "$CONF" ]]; then
    # shellcheck disable=SC1090
    source "$CONF" 2>/dev/null || true
    IFS=' ' read -ra ADMIN_USERS_LIST <<< "${ADMIN_USERS:-}"
  fi
}

cmd_install() {
  require_root
  log "Installing TOTP support..."

  # Install google-authenticator PAM module
  if ! rpm -q google-authenticator >/dev/null 2>&1; then
    dnf install -y epel-release 2>/dev/null || true
    dnf install -y google-authenticator pam 2>/dev/null \
      || die "Could not install google-authenticator. Enable EPEL: dnf install epel-release"
  fi
  need google-authenticator

  # Configure PAM sshd — add TOTP as second factor
  # We insert BEFORE the default auth stack so TOTP + password are both required
  if ! grep -q 'pam_google_authenticator' "$PAM_SSHD" 2>/dev/null; then
    # Back up existing PAM config
    cp "$PAM_SSHD" "${PAM_SSHD}.bak.$(date +%Y%m%d-%H%M%S)"
    # Prepend TOTP requirement (nullok during enrollment, remove after all users enrolled)
    sed -i '1s/^/auth required pam_google_authenticator.so nullok\n/' "$PAM_SSHD"
    log "PAM sshd: added pam_google_authenticator.so"
  else
    log "PAM sshd: pam_google_authenticator already present"
  fi

  # Configure sshd to use both pubkey AND keyboard-interactive (TOTP)
  mkdir -p "$(dirname "$SSHD_DROPIN")"
  cat > "$SSHD_DROPIN" << 'EOF'
# gw-totp.conf — Enable TOTP second factor for portal SSH
# Requires: pam_google_authenticator installed + user enrolled
AuthenticationMethods publickey,keyboard-interactive
KbdInteractiveAuthentication yes
ChallengeResponseAuthentication yes
UsePAM yes
EOF
  log "sshd dropin written: $SSHD_DROPIN"

  # Validate sshd config before reload
  sshd -t || die "sshd config validation failed after TOTP dropin — check $SSHD_DROPIN"

  # Reload sshd
  systemctl reload sshd || systemctl reload ssh 2>/dev/null || true
  log "sshd reloaded"

  log "TOTP install complete."
  echo ""
  echo "Next steps:"
  echo "  1. Enroll each admin user:  gw-totp-setup.sh enroll <username>"
  echo "  2. Verify each user:        gw-totp-setup.sh verify <username>"
  echo "  3. After ALL users enrolled, remove 'nullok' from $PAM_SSHD"
  echo "     (nullok allows login without TOTP — remove once all users have a token)"
}

cmd_enroll() {
  local user="${1:-}"
  [[ -n "$user" ]] || die "Usage: gw-totp-setup.sh enroll <username>"
  require_root
  id "$user" >/dev/null 2>&1 || die "User does not exist: $user"

  local ga_conf="/home/${user}/.google_authenticator"
  if [[ -f "$ga_conf" ]]; then
    log "WARN: $user already has a TOTP token. Re-enrolling will invalidate the old one."
    read -r -p "Proceed with re-enrollment? [yes/N] " confirm
    [[ "$confirm" == "yes" ]] || { echo "Aborted."; exit 0; }
  fi

  log "Enrolling TOTP for user: $user"

  # Generate TOTP secret for the user
  # -t: time-based, -d 3: 3 valid codes (skew), -r 3 -R 30: rate limit
  # -W: window size, -f: force write without prompt, -q: quiet
  su - "$user" -c "google-authenticator -t -d -f -r 3 -R 30 -W" \
    || die "google-authenticator enrollment failed for $user"

  # Set secure permissions
  chown "${user}:${user}" "$ga_conf" 2>/dev/null || true
  chmod 400 "$ga_conf"

  log "TOTP enrolled for $user. User must scan the QR code or save the secret key shown above."
  echo ""
  echo "IMPORTANT: $user must save their backup scratch codes and secret key."
  echo "Recovery without the secret key is not possible."
}

cmd_verify() {
  local user="${1:-}"
  [[ -n "$user" ]] || die "Usage: gw-totp-setup.sh verify <username>"

  local ga_conf="/home/${user}/.google_authenticator"
  if [[ -f "$ga_conf" ]]; then
    echo "[OK] $user has a TOTP token enrolled at $ga_conf"
    echo "     To fully verify, SSH as $user and confirm TOTP prompt appears."
  else
    echo "[FAIL] $user does not have a TOTP token. Run: gw-totp-setup.sh enroll $user"
    exit 1
  fi
}

cmd_revoke() {
  local user="${1:-}"
  [[ -n "$user" ]] || die "Usage: gw-totp-setup.sh revoke <username>"
  require_root

  local ga_conf="/home/${user}/.google_authenticator"
  if [[ -f "$ga_conf" ]]; then
    rm -f "$ga_conf"
    log "TOTP revoked for $user"
    echo "NOTE: $user can no longer log in until re-enrolled (unless nullok is set in PAM)."
  else
    echo "$user has no TOTP token to revoke."
  fi
}

cmd_status() {
  load_admin_users
  echo "=== TOTP Enrollment Status ==="
  echo ""

  # PAM state
  if grep -q 'pam_google_authenticator' "$PAM_SSHD" 2>/dev/null; then
    if grep -q 'nullok' "$PAM_SSHD"; then
      echo "PAM:   Configured (nullok mode — users without token can still log in)"
      echo "       Remove 'nullok' from $PAM_SSHD after all users are enrolled."
    else
      echo "PAM:   Configured (enforcing — all users require TOTP)"
    fi
  else
    echo "PAM:   NOT configured (run: gw-totp-setup.sh install)"
  fi

  echo ""
  echo "sshd dropin: $([[ -f "$SSHD_DROPIN" ]] && echo 'present' || echo 'MISSING')"
  echo ""
  echo "User enrollment:"

  local users=("${ADMIN_USERS_LIST[@]}")
  if [[ "${#users[@]}" -eq 0 ]]; then
    # Fall back to listing users with .google_authenticator files
    while IFS= read -r home; do
      local u; u="$(basename "$home")"
      users+=("$u")
    done < <(find /home -maxdepth 2 -name '.google_authenticator' -exec dirname {} \; 2>/dev/null || true)
  fi

  for u in "${users[@]}"; do
    local ga_conf="/home/${u}/.google_authenticator"
    if [[ -f "$ga_conf" ]]; then
      echo "  [OK]   $u — enrolled"
    else
      echo "  [MISS] $u — not enrolled"
    fi
  done
}

case "${1:-}" in
  install) cmd_install ;;
  enroll)  cmd_enroll  "${2:-}" ;;
  verify)  cmd_verify  "${2:-}" ;;
  revoke)  cmd_revoke  "${2:-}" ;;
  status)  cmd_status  ;;
  -h|--help|help|"")
    echo "gw-totp-setup.sh — Portal SSH TOTP enrollment"
    echo "Usage: gw-totp-setup.sh <install|enroll|verify|revoke|status>"
    ;;
  *) die "Unknown command: ${1}" ;;
esac
