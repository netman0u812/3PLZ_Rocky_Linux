GW-Platform-RC3.4-CertDeliver
════════════════════════════════════════════════════════════════
Package:   GW-Platform-RC3.4-CertDeliver.zip
Version:   RC3.4
Role:      Optional add-on — per-tenant mTLS client certificate
           generation and one-time HTTPS delivery server

WHAT THIS IS
─────────────
  gw-cert-deliver.sh is a self-contained optional add-on that:
    - Issues per-user P12 certificate bundles from the tenant intermediate CA
    - Delivers them via a temporary HTTPS server on a non-standard port (8443)
    - Protects each bundle with a unique one-time password
    - Logs source IP, timestamp, and email claimed for every download attempt
    - Auto-shuts the delivery server when all certs for the tenant are downloaded

  This add-on has NO dependencies on the portal's existing nftables chains,
  nginx configuration, or any running services. It is a single script.

PREREQUISITES
─────────────
  - GW Platform RC3.3 AdminPortal installed and operational
  - pki-bootstrap.sh init-tenant <tenant> completed for the target tenant
  - gw-pki-backup.sh backup-tenant <tenant> confirmed
  - python3, openssl, sqlite3, nft — all present in RC3.3 base install

INSTALLATION
─────────────
  1. Extract the add-on package:
       unzip GW-Platform-RC3.4-CertDeliver.zip

  2. Copy script to path:
       cp rc34-certdeliver/scripts/gw-cert-deliver.sh /usr/local/bin/
       chmod +x /usr/local/bin/gw-cert-deliver.sh

  3. Verify install:
       gw-cert-deliver.sh help

  No portal restart required. No systemd unit. No config file changes
  required unless SMTP password delivery is wanted (see below).

OPTIONAL — SMTP PASSWORD DELIVERY
───────────────────────────────────
  To have the portal email one-time passwords directly to users, add to
  /etc/gw-admin-portal/conf/portal.conf:

    SMTP_ENABLED=yes
    SMTP_HOST=smtp.office365.com       # Office 365
    SMTP_PORT=587
    SMTP_TLS=starttls
    SMTP_USER=notify@yourdomain.com
    SMTP_PASS=<app-password>
    SMTP_FROM=notify@yourdomain.com

  Office 365: use an app password or service account with SMTP AUTH enabled.
  Gmail:      SMTP_HOST=smtp.gmail.com — use an app password (requires 2FA).
  Generic:    Any SMTP relay — set SMTP_TLS=none if relay does not support TLS.

  If SMTP is not configured, the engineer distributes passwords manually
  from the manifest file at /opt/gw-cert-delivery/<tenant>/manifest.txt.

OPTIONAL — NON-DEFAULT PORT OR WINDOW
───────────────────────────────────────
  Add to /etc/gw-admin-portal/conf/portal.conf to override defaults:

    DELIVER_PORT=8443                  # Non-standard HTTPS port (default: 8443)
    DELIVER_VALIDITY_DAYS=365          # Certificate validity in days (default: 365)
    DELIVER_WINDOW_MINUTES=15          # Download window per user (default: 15)
    DELIVER_MAX_ATTEMPTS=3             # Max download attempts in window (default: 3)

WORKFLOW
─────────
  1. Create user email list (one address per line, # for comments):
       vi /tmp/tenant-users.txt

  2. Generate certificates and one-time passwords:
       gw-cert-deliver.sh generate <tenant> /tmp/tenant-users.txt
       # Creates P12 per user, generates manifest with passwords

  3. Distribute passwords to users:
       SMTP:   gw-cert-deliver.sh send-passwords <tenant>
       Manual: cat /opt/gw-cert-delivery/<tenant>/manifest.txt
               (distribute passwords via secure channel — NOT the same channel as the download link)

  4. Start the delivery server:
       gw-cert-deliver.sh start <tenant>
       # Opens port 8443, restricts to tenant declared source networks (Sheet 4)
       # Use --open-firewall flag to override network restriction (logged)

  5. Share the download URL with users:
       https://<portal-hostname>:8443/
       Users enter their email address and one-time password.
       P12 bundle downloads automatically.
       Password valid for 15 minutes / 3 attempts from first access.

  6. Monitor progress:
       gw-cert-deliver.sh status <tenant>

  7. Server auto-stops when all certs downloaded.

  8. Review audit trail:
       gw-cert-deliver.sh report <tenant>

NFTABLES
─────────
  The add-on creates its own isolated nftables table (gw_certdeliver_<tenant>).
  No modifications to the portal's existing nftables configuration are made.
  The table is created on start and fully removed on stop.
  By default, access is restricted to the tenant's declared source networks
  from the onboarding workbook (Sheet 4 — Remote Networks).

POST-INSTALL VERIFICATION
──────────────────────────
    gw-cert-deliver.sh help             # Script accessible and version correct
    gw-cert-deliver.sh status <tenant>  # After generate — shows cert inventory

UNINSTALL
──────────
    gw-cert-deliver.sh stop <tenant>    # Stop server + remove nftables table
    rm /usr/local/bin/gw-cert-deliver.sh
    rm -rf /opt/gw-cert-delivery/       # Remove all cert bundles and state

SECURITY NOTES
───────────────
  - P12 bundles and manifest (with plain text passwords) are stored at
    /opt/gw-cert-delivery/<tenant>/ — root-owned, mode 700/600.
  - The delivery server uses a self-signed 7-day TLS cert (separate from
    tenant PKI). Users will see a browser TLS warning — this is expected
    and documented in the password delivery email.
  - Email address is used as an access credential (identity assertion only).
    It does not verify that the user controls the email address. Tighter
    binding (token sent to email) is planned for a future release.
  - One-time passwords are valid for the full 15-minute download window.
    They do not expire on first download.

SEE ALSO
─────────
  RC3-Architecture.txt section 9   — PKI Architecture and cert delivery overview
  RC3-Feature-Reference.txt        — Full feature reference
  README-AdminPortal.txt           — Admin Portal installation
