#!/bin/bash
# gw-cert-deliver.sh v RC3.4 — mTLS client certificate generation and delivery.
#
# WORKFLOW:
#   1. Engineer uploads a text file of user email addresses (one per line)
#   2. Script generates a cert per user from the tenant intermediate CA
#   3. Script generates a random one-time password per user, protects P12 bundle
#   4. Engineer receives a manifest: email → one-time password (plain text for support)
#   5. Optionally: script emails each user their password via configured SMTP relay
#   6. Engineer starts the delivery server for the tenant
#   7. Users navigate to https://<portal>:<DELIVER_PORT>, enter email + password
#   8. P12 bundle served for download — password valid for full 15-minute window
#   9. Source IP, timestamp, and email logged for audit
#  10. Server auto-shuts when all certs have been downloaded
#
# DOWNLOAD POLICY: 3 attempts within 15 minutes of first access per user.
#                  Password remains valid for the full window after first access.
#
# nftables: delivery port restricted to tenant declared source networks by default.
#           Engineer can override with --open-firewall flag.
#
# Usage:
#   gw-cert-deliver.sh generate  <tenant> <email-list.txt>  Generate certs + manifest
#   gw-cert-deliver.sh start     <tenant> [--open-firewall]  Start delivery server
#   gw-cert-deliver.sh stop      <tenant>                    Stop delivery server
#   gw-cert-deliver.sh status    <tenant>                    Server + delivery state
#   gw-cert-deliver.sh report    <tenant>                    Audit report
#   gw-cert-deliver.sh list      <tenant>                    List certs + download state
#   gw-cert-deliver.sh send-passwords <tenant>               Email passwords via SMTP
#   gw-cert-deliver.sh revoke    <tenant> <email>            Block a user's download

set -euo pipefail
VERSION="RC3.4"

# ── Portable helpers ──────────────────────────────────────────────
isotime() {
  python3 -c "from datetime import datetime,timezone; \
print(datetime.now(timezone.utc).astimezone().isoformat(timespec='seconds'))"
}
sha256_cmd() {
  if command -v sha256sum >/dev/null 2>&1; then sha256sum "$@"; else shasum -a 256 "$@"; fi
}

# ── Configuration (overridable via portal.conf or environment) ────
PKI_BASE="${PKI_BASE:-/etc/gateway/pki}"
DELIVER_BASE="${DELIVER_BASE:-/opt/gw-cert-delivery}"
DELIVER_PORT="${DELIVER_PORT:-8443}"
DELIVER_VALIDITY_DAYS="${DELIVER_VALIDITY_DAYS:-365}"
DELIVER_WINDOW_MINUTES="${DELIVER_WINDOW_MINUTES:-15}"
DELIVER_MAX_ATTEMPTS="${DELIVER_MAX_ATTEMPTS:-3}"

# SMTP settings (set in /etc/gw-admin-portal/conf/portal.conf)
SMTP_ENABLED="${SMTP_ENABLED:-no}"
SMTP_HOST="${SMTP_HOST:-}"
SMTP_PORT="${SMTP_PORT:-587}"
SMTP_USER="${SMTP_USER:-}"
SMTP_PASS="${SMTP_PASS:-}"
SMTP_FROM="${SMTP_FROM:-}"
SMTP_TLS="${SMTP_TLS:-starttls}"   # starttls | ssl | none

LOG=/var/log/gw-cert-deliver.log

# ── Internals ─────────────────────────────────────────────────────
die()  { echo "ERROR: $*" >&2; log "ERROR: $*" 2>/dev/null || true; exit 1; }
log()  { echo "[$(isotime)] $*" | tee -a "$LOG"; }
warn() { echo "WARN:  $*" | tee -a "$LOG"; }
require_root() { [[ "${EUID:-$(id -u)}" -eq 0 ]] || die "Run as root"; }
need() { command -v "$1" >/dev/null 2>&1 || die "Required: $1 — install it first"; }

tenant_dir()  { echo "${DELIVER_BASE}/${1}"; }
cert_dir()    { echo "${DELIVER_BASE}/${1}/certs"; }
state_file()  { echo "${DELIVER_BASE}/${1}/state.db"; }    # sqlite3
manifest()    { echo "${DELIVER_BASE}/${1}/manifest.txt"; }
pid_file()    { echo "${DELIVER_BASE}/${1}/server.pid"; }
server_cert() { echo "${DELIVER_BASE}/${1}/tls/server.crt"; }
server_key()  { echo "${DELIVER_BASE}/${1}/tls/server.key"; }
audit_log()   { echo "${DELIVER_BASE}/${1}/audit.log"; }

gen_password() {
  python3 -c "import secrets,string; \
a=string.ascii_letters+string.digits; \
print(''.join(secrets.choice(a) for _ in range(20)))"
}

# ── State DB (sqlite3) ────────────────────────────────────────────
db_init() {
  local tenant="$1"
  local db; db="$(state_file "$tenant")"
  sqlite3 "$db" << 'SQL'
CREATE TABLE IF NOT EXISTS certs (
  email          TEXT PRIMARY KEY,
  p12_path       TEXT NOT NULL,
  password_hash  TEXT NOT NULL,
  password_plain TEXT NOT NULL,
  status         TEXT NOT NULL DEFAULT 'pending',
  first_access   TEXT,
  attempts       INTEGER DEFAULT 0,
  downloaded_at  TEXT,
  revoked        INTEGER DEFAULT 0,
  source_ip      TEXT
);
SQL
}

db_load() {
  local tenant="$1" email="$2" p12="$3" pass_plain="$4"
  local db; db="$(state_file "$tenant")"
  local pass_hash; pass_hash="$(echo -n "$pass_plain" | sha256_cmd | awk '{print $1}')"
  sqlite3 "$db" \
    "INSERT OR REPLACE INTO certs(email,p12_path,password_hash,password_plain,status) \
     VALUES('${email}','${p12}','${pass_hash}','${pass_plain}','pending');"
}

db_get() {
  local tenant="$1" email="$2" field="$3"
  sqlite3 "$(state_file "$tenant")" \
    "SELECT ${field} FROM certs WHERE email='${email}';"
}

db_set() {
  local tenant="$1" email="$2" field="$3" val="$4"
  sqlite3 "$(state_file "$tenant")" \
    "UPDATE certs SET ${field}='${val}' WHERE email='${email}';"
}

db_all_downloaded() {
  local tenant="$1"
  local pending; pending=$(sqlite3 "$(state_file "$tenant")" \
    "SELECT COUNT(*) FROM certs WHERE status != 'downloaded' AND revoked=0;")
  [[ "$pending" -eq 0 ]]
}

# ── nftables firewall management ──────────────────────────────────
# gw-cert-deliver uses its own isolated nftables table (gw_certdeliver).
# This is intentional — the add-on has zero dependency on the portal's
# existing nftables chains (gw_admin, nftables-portal.conf, etc).
# The table is created on start and fully removed on stop.

fw_open_tenant() {
  local tenant="$1" open_all="${2:-no}"
  local table="gw_certdeliver_${tenant}"
  local chain="input"

  # Tear down any leftover table from a previous run
  nft delete table inet "${table}" 2>/dev/null || true

  # Create isolated table + base input chain
  nft "add table inet ${table}"
  nft "add chain inet ${table} ${chain} { type filter hook input priority 0 ; policy drop ; }"

  # Always allow established/related and loopback
  nft "add rule inet ${table} ${chain} ct state established,related accept"
  nft "add rule inet ${table} ${chain} iif lo accept"

  if [[ "$open_all" == "yes" ]]; then
    nft "add rule inet ${table} ${chain} tcp dport ${DELIVER_PORT} accept"
    warn "Delivery port ${DELIVER_PORT} open to ALL source IPs — override mode"
    log "nftables: table=${table} port=${DELIVER_PORT} OPEN (override) for tenant=${tenant}"
  else
    # Read declared source networks from gwreg
    local nets
    nets=$(gwreg tenant show "$tenant" 2>/dev/null            | grep -E 'remote_prefix|source_network'            | awk '{print $NF}' || echo "")

    if [[ -z "$nets" ]]; then
      warn "No source networks found for tenant=$tenant — delivery port open to all (log only)"
      nft "add rule inet ${table} ${chain}            tcp dport ${DELIVER_PORT} log prefix \"gw-deliver-${tenant}: \" accept"
    else
      while IFS= read -r net; do
        [[ -z "$net" ]] && continue
        nft "add rule inet ${table} ${chain}              ip saddr ${net} tcp dport ${DELIVER_PORT} accept"
        log "nftables: delivery port allowed from ${net} (table=${table})"
      done <<< "$nets"
      # Drop and log everything else hitting the delivery port
      nft "add rule inet ${table} ${chain}            tcp dport ${DELIVER_PORT}            log prefix \"gw-deliver-${tenant}-DENY: \" drop"
    fi
  fi
  log "nftables: table ${table} active"
}

fw_close_tenant() {
  local tenant="$1"
  local table="gw_certdeliver_${tenant}"
  nft delete table inet "${table}" 2>/dev/null || true
  log "nftables: table ${table} removed"
}

# ── TLS — self-signed delivery cert (separate from tenant PKI) ────
gen_delivery_tls() {
  local tenant="$1"
  local tls_dir; tls_dir="$(tenant_dir "$tenant")/tls"
  mkdir -p "$tls_dir"
  chmod 700 "$tls_dir"

  local portal_hostname; portal_hostname="$(hostname -f 2>/dev/null || hostname)"

  openssl req -x509 -newkey rsa:2048 -nodes \
    -keyout "$(server_key "$tenant")" \
    -out    "$(server_cert "$tenant")" \
    -days   7 \
    -subj   "/CN=${portal_hostname}/O=GW Platform RC3.3/OU=CertDelivery" \
    -addext "subjectAltName=DNS:${portal_hostname},IP:127.0.0.1" \
    2>/dev/null
  chmod 600 "$(server_key "$tenant")" "$(server_cert "$tenant")"
  log "Delivery TLS cert generated: ${portal_hostname} (7-day, self-signed)"
}

# ── Certificate generation ────────────────────────────────────────
gen_user_cert() {
  local tenant="$1" email="$2" outdir="$3" password="$4"
  local intermediate="${PKI_BASE}/${tenant}/intermediate"

  [[ -d "$intermediate" ]] || \
    die "Tenant intermediate CA not found: $intermediate — run pki-bootstrap.sh init-tenant first"

  local safe_email; safe_email="${email//@/_at_}"
  local key="${outdir}/${safe_email}.key.pem"
  local csr="${outdir}/${safe_email}.csr.pem"
  local crt="${outdir}/${safe_email}.cert.pem"
  local p12="${outdir}/${safe_email}.p12"
  local chain="${intermediate}/certs/ca-chain.cert.pem"

  # Generate key + CSR with email in CN and SAN
  openssl req -new -newkey rsa:2048 -nodes \
    -keyout "$key" \
    -out    "$csr" \
    -subj   "/CN=${email}/emailAddress=${email}" \
    -addext "subjectAltName=email:${email}" \
    2>/dev/null

  # Sign with tenant intermediate CA
  openssl ca -batch \
    -config   "${intermediate}/openssl.cnf" \
    -in       "$csr" \
    -out      "$crt" \
    -days     "$DELIVER_VALIDITY_DAYS" \
    -extensions usr_cert \
    2>/dev/null \
    || die "Certificate signing failed for ${email} — check tenant CA config"

  # Package as password-protected P12
  openssl pkcs12 -export \
    -inkey   "$key" \
    -in      "$crt" \
    -certfile "$chain" \
    -out     "$p12" \
    -passout "pass:${password}" \
    -name    "${email}" \
    2>/dev/null

  # Secure the private key — only readable by root
  chmod 600 "$key" "$p12"
  # Remove plaintext key and CSR after P12 is built
  rm -f "$key" "$csr"

  echo "$p12"
}

# ── SMTP password delivery ────────────────────────────────────────
send_password_email() {
  local email="$1" password="$2" tenant="$3" portal_host="$4"
  need python3

  python3 << PYEOF
import smtplib, ssl, sys
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

host    = "${SMTP_HOST}"
port    = int("${SMTP_PORT}")
user    = "${SMTP_USER}"
passwd  = "${SMTP_PASS}"
frm     = "${SMTP_FROM}"
tls     = "${SMTP_TLS}"
to      = "${email}"
portal  = "${portal_host}"
deliver_port = "${DELIVER_PORT}"
tenant  = "${tenant}"
otp     = "${password}"

if not host or not user or not passwd or not frm:
    print("SMTP not configured — skipping", file=sys.stderr)
    sys.exit(1)

subject = f"GW Platform RC3.3 — Your mTLS Certificate is Ready [{tenant}]"
body = f"""Your mTLS client certificate has been issued for the GW Platform RC3.3 secure access edge.

Tenant:         {tenant}
Your identity:  {to}

DOWNLOAD INSTRUCTIONS
---------------------
1. Navigate to:  https://{portal}:{deliver_port}/
2. Enter your email address: {to}
3. Enter your one-time password (below) when prompted
4. Download and import the .p12 certificate bundle into your browser or client

ONE-TIME PASSWORD:  {otp}

IMPORTANT:
- This password is valid for ${DELIVER_WINDOW_MINUTES} minutes from your first access attempt
- You have up to ${DELIVER_MAX_ATTEMPTS} download attempts within that window
- The certificate is bound to your email address ({to})
- The download server uses a self-signed TLS certificate — you may see a browser warning, this is expected

If you have difficulty downloading, contact your provisioning engineer.

GW Platform RC3.3 — Automated Certificate Delivery
"""

msg = MIMEMultipart()
msg['From']    = frm
msg['To']      = to
msg['Subject'] = subject
msg.attach(MIMEText(body, 'plain'))

try:
    if tls == 'ssl':
        ctx = ssl.create_default_context()
        with smtplib.SMTP_SSL(host, port, context=ctx) as s:
            s.login(user, passwd)
            s.sendmail(frm, to, msg.as_string())
    else:
        with smtplib.SMTP(host, port) as s:
            if tls == 'starttls':
                s.starttls(context=ssl.create_default_context())
            s.login(user, passwd)
            s.sendmail(frm, to, msg.as_string())
    print(f"OK: email sent to {to}")
except Exception as e:
    print(f"FAIL: {to}: {e}", file=sys.stderr)
    sys.exit(1)
PYEOF
}

# ── HTTPS delivery server (Python) ───────────────────────────────
write_server_script() {
  local tenant="$1"
  local srv_script; srv_script="$(tenant_dir "$tenant")/delivery_server.py"

  cat > "$srv_script" << PYEOF
#!/usr/bin/env python3
"""
GW Platform RC3.3 — mTLS Certificate Delivery Server
Tenant: ${tenant}
"""
import ssl, os, sys, json, sqlite3, hashlib, time, signal
from http.server import HTTPServer, BaseHTTPRequestHandler
from urllib.parse import parse_qs, urlparse
from datetime import datetime, timezone
from pathlib import Path

TENANT       = "${tenant}"
DB_PATH      = "$(state_file "$tenant")"
AUDIT_LOG    = "$(audit_log "$tenant")"
CERT_PATH    = "$(server_cert "$tenant")"
KEY_PATH     = "$(server_key "$tenant")"
PORT         = int("${DELIVER_PORT}")
MAX_ATTEMPTS = int("${DELIVER_MAX_ATTEMPTS}")
WINDOW_MINS  = int("${DELIVER_WINDOW_MINUTES}")

def now_iso():
    return datetime.now(timezone.utc).astimezone().isoformat(timespec='seconds')

def audit(msg):
    with open(AUDIT_LOG, 'a') as f:
        f.write(f"[{now_iso()}] {msg}\n")

def get_db():
    return sqlite3.connect(DB_PATH)

def hash_pass(p):
    return hashlib.sha256(p.encode()).hexdigest()

def all_downloaded():
    with get_db() as db:
        n = db.execute(
            "SELECT COUNT(*) FROM certs WHERE status != 'downloaded' AND revoked=0"
        ).fetchone()[0]
    return n == 0

HTML_FORM = """<!DOCTYPE html>
<html><head><meta charset="utf-8">
<title>GW Platform RC3.3 — Certificate Delivery</title>
<style>
  body {{ font-family: Arial, sans-serif; max-width: 480px; margin: 80px auto;
          color: #3A4A5A; background: #F5F7FA; }}
  h2 {{ color: #0F2744; }}
  .box {{ background: #fff; border-radius: 6px; padding: 32px;
          box-shadow: 0 2px 8px rgba(0,0,0,0.10); }}
  label {{ display: block; margin-top: 16px; font-weight: bold; font-size: 13px; }}
  input {{ width: 100%; padding: 8px; margin-top: 4px; border: 1px solid #D0D8E0;
           border-radius: 4px; box-sizing: border-box; font-size: 14px; }}
  button {{ margin-top: 24px; width: 100%; padding: 10px; background: #0F2744;
            color: #fff; border: none; border-radius: 4px; font-size: 15px;
            cursor: pointer; }}
  .note {{ margin-top: 20px; font-size: 12px; color: #6A7A8A; }}
  .err  {{ color: #7A1818; background: #FFE4E4; padding: 10px;
           border-radius: 4px; margin-top: 16px; font-size: 13px; }}
</style></head>
<body><div class="box">
<h2>Certificate Download</h2>
<p>GW Platform RC3.3 — Tenant: <strong>{tenant}</strong></p>
{error}
<form method="POST" action="/download">
  <label>Your email address</label>
  <input type="email" name="email" required placeholder="you@example.com">
  <label>One-time password</label>
  <input type="password" name="otp" required placeholder="Provided by your engineer">
  <button type="submit">Download Certificate</button>
</form>
<p class="note">
  Your certificate bundle (.p12) will download automatically.<br>
  The password expires after your first successful download.<br>
  You have {max_attempts} attempts within {window_mins} minutes of first access.
</p>
</div></body></html>"""

class DeliveryHandler(BaseHTTPRequestHandler):

    def log_message(self, fmt, *args):
        pass   # suppress default httpd logging — we write our own audit log

    def client_ip(self):
        return self.client_address[0]

    def send_form(self, error=""):
        err_html = f'<div class="err">{error}</div>' if error else ""
        body = HTML_FORM.format(
            tenant=TENANT, error=err_html,
            max_attempts=MAX_ATTEMPTS, window_mins=WINDOW_MINS
        ).encode()
        self.send_response(200)
        self.send_header('Content-Type', 'text/html; charset=utf-8')
        self.send_header('Content-Length', len(body))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        if self.path in ('/', '/index.html'):
            self.send_form()
        else:
            self.send_response(404)
            self.end_headers()

    def do_POST(self):
        if self.path != '/download':
            self.send_response(404)
            self.end_headers()
            return

        length = int(self.headers.get('Content-Length', 0))
        body   = self.rfile.read(length).decode()
        params = parse_qs(body)
        email  = params.get('email', [''])[0].strip().lower()
        otp    = params.get('otp',   [''])[0].strip()
        ip     = self.client_ip()

        if not email or not otp:
            self.send_form("Email and password are required.")
            return

        with get_db() as db:
            row = db.execute(
                "SELECT p12_path, password_hash, status, first_access, "
                "attempts, revoked FROM certs WHERE email=?", (email,)
            ).fetchone()

        if not row:
            audit(f"UNKNOWN email={email} ip={ip}")
            self.send_form("Email address not found. Contact your provisioning engineer.")
            return

        p12_path, pass_hash, status, first_access, attempts, revoked = row

        if revoked:
            audit(f"REVOKED email={email} ip={ip}")
            self.send_form("This certificate has been revoked. Contact your provisioning engineer.")
            return

        if status == 'downloaded':
            audit(f"ALREADY_DOWNLOADED email={email} ip={ip}")
            self.send_form("Certificate already downloaded. Contact your engineer if you need a reissue.")
            return

        now_ts = time.time()

        # Record first access
        if not first_access:
            with get_db() as db:
                db.execute(
                    "UPDATE certs SET first_access=?, source_ip=? WHERE email=?",
                    (now_iso(), ip, email)
                )
            first_access = now_iso()

        # Check window expiry
        first_ts = datetime.fromisoformat(first_access).timestamp()
        if (now_ts - first_ts) > (WINDOW_MINS * 60):
            audit(f"WINDOW_EXPIRED email={email} ip={ip}")
            self.send_form(
                f"Download window expired ({WINDOW_MINS} minutes). "
                "Contact your provisioning engineer to request a new window."
            )
            return

        # Check attempt count
        if attempts >= MAX_ATTEMPTS:
            audit(f"MAX_ATTEMPTS email={email} ip={ip} attempts={attempts}")
            self.send_form(
                f"Maximum download attempts ({MAX_ATTEMPTS}) exceeded. "
                "Contact your provisioning engineer."
            )
            return

        # Increment attempt counter
        with get_db() as db:
            db.execute(
                "UPDATE certs SET attempts=attempts+1, source_ip=? WHERE email=?",
                (ip, email)
            )

        # Verify password
        if hash_pass(otp) != pass_hash:
            audit(f"WRONG_PASSWORD email={email} ip={ip} attempt={attempts+1}")
            remaining = MAX_ATTEMPTS - attempts - 1
            self.send_form(
                f"Incorrect password. {remaining} attempt(s) remaining."
            )
            return

        # Verify P12 file exists
        if not Path(p12_path).exists():
            audit(f"P12_MISSING email={email} ip={ip}")
            self.send_form("Certificate file not found. Contact your provisioning engineer.")
            return

        # Serve the P12
        p12_data = Path(p12_path).read_bytes()
        filename = f"{email.replace('@','_at_')}.p12"

        self.send_response(200)
        self.send_header('Content-Type', 'application/x-pkcs12')
        self.send_header('Content-Disposition', f'attachment; filename="{filename}"')
        self.send_header('Content-Length', len(p12_data))
        self.send_header('Cache-Control', 'no-store')
        self.end_headers()
        self.wfile.write(p12_data)

        # Mark as downloaded — password is now spent
        with get_db() as db:
            db.execute(
                "UPDATE certs SET status='downloaded', downloaded_at=?, source_ip=? WHERE email=?",
                (now_iso(), ip, email)
            )
        audit(f"DOWNLOADED email={email} ip={ip}")

        # Check if all certs delivered — auto-shutdown
        if all_downloaded():
            audit(f"ALL_DOWNLOADED tenant={TENANT} — initiating auto-shutdown")
            # Signal self to shutdown gracefully
            os.kill(os.getpid(), signal.SIGTERM)

def run():
    ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    ctx.load_cert_chain(CERT_PATH, KEY_PATH)
    ctx.minimum_version = ssl.TLSVersion.TLSv1_2

    httpd = HTTPServer(('0.0.0.0', PORT), DeliveryHandler)
    httpd.socket = ctx.wrap_socket(httpd.socket, server_side=True)

    def shutdown(sig, frame):
        audit(f"SERVER_STOP tenant={TENANT}")
        httpd.server_close()
        sys.exit(0)

    signal.signal(signal.SIGTERM, shutdown)
    signal.signal(signal.SIGINT,  shutdown)

    audit(f"SERVER_START tenant={TENANT} port={PORT}")
    print(f"[{datetime.now().isoformat(timespec='seconds')}] "
          f"Delivery server running on port {PORT} for tenant={TENANT}")
    httpd.serve_forever()

if __name__ == '__main__':
    run()
PYEOF
  chmod 700 "$srv_script"
}

# ══════════════════════════════════════════════════════════════════
# COMMANDS
# ══════════════════════════════════════════════════════════════════

cmd_generate() {
  local tenant="${1:-}" email_list="${2:-}"
  [[ -n "$tenant" ]]     || die "Usage: gw-cert-deliver.sh generate <tenant> <email-list.txt>"
  [[ -n "$email_list" ]] || die "Usage: gw-cert-deliver.sh generate <tenant> <email-list.txt>"
  [[ -f "$email_list" ]] || die "Email list file not found: $email_list"
  require_root; need openssl; need sqlite3; need python3

  local tdir; tdir="$(tenant_dir "$tenant")"
  local cdir; cdir="$(cert_dir "$tenant")"
  mkdir -p "$tdir" "$cdir"
  chmod 700 "$tdir" "$cdir"

  db_init "$tenant"

  # Count valid emails
  local total=0
  while IFS= read -r line; do
    line="$(echo "$line" | tr -d '[:space:]')"
    [[ -z "$line" || "$line" == \#* ]] && continue
    total=$(( total + 1 ))
  done < "$email_list"
  [[ "$total" -gt 0 ]] || die "No valid email addresses found in $email_list"

  log "Generating $total client cert(s) for tenant=$tenant"
  echo ""
  echo "=== Generating mTLS client certificates ==="
  echo "Tenant:     $tenant"
  echo "Users:      $total"
  echo "Validity:   ${DELIVER_VALIDITY_DAYS} days"
  echo "CA:         ${PKI_BASE}/${tenant}/intermediate"
  echo ""

  # Write manifest header
  local mf; mf="$(manifest "$tenant")"
  cat > "$mf" << HDR
# GW Platform RC3.3 — Certificate Delivery Manifest
# Tenant:    $tenant
# Generated: $(isotime)
# 
# SECURITY: This manifest contains one-time passwords in plain text.
#           Store securely. Distribute passwords to users via a separate channel.
#           Each password is valid for the full 15-minute download window from first access.
#
# FORMAT: email | one-time-password | status
#
HDR

  local count=0
  while IFS= read -r line; do
    line="$(echo "$line" | tr -d '[:space:]' | tr '[:upper:]' '[:lower:]')"
    [[ -z "$line" || "$line" == \#* ]] && continue

    local password; password="$(gen_password)"
    local p12; p12="$(gen_user_cert "$tenant" "$line" "$cdir" "$password")"

    db_load "$tenant" "$line" "$p12" "$password"
    echo "${line} | ${password} | pending" >> "$mf"
    count=$(( count + 1 ))
    log "  Generated: $line"
    echo "  [${count}/${total}] $line — OK"
  done < "$email_list"

  chmod 600 "$mf"

  echo ""
  echo "=== Generation complete ==="
  echo "Manifest:   $mf"
  echo "Certs:      $cdir"
  echo ""
  echo "NEXT STEPS:"
  echo "  1. Review manifest:           cat $mf"
  echo "  2. Send passwords to users:"
  echo "       SMTP:   gw-cert-deliver.sh send-passwords $tenant"
  echo "       Manual: distribute passwords from $mf via secure channel"
  echo "  3. Start delivery server:     gw-cert-deliver.sh start $tenant"
  echo "  4. Monitor:                   gw-cert-deliver.sh status $tenant"
  log "Generation complete: tenant=$tenant certs=$count"
}

cmd_start() {
  local tenant="${1:-}" open_fw="no"
  [[ -n "$tenant" ]] || die "Usage: gw-cert-deliver.sh start <tenant> [--open-firewall]"
  [[ "${2:-}" == "--open-firewall" ]] && open_fw="yes"
  require_root; need python3; need openssl; need nft

  local tdir; tdir="$(tenant_dir "$tenant")"
  [[ -d "$tdir" ]] || die "No certs generated for tenant=$tenant — run generate first"

  local pid; pid="$(pid_file "$tenant")"
  if [[ -f "$pid" ]] && kill -0 "$(cat "$pid")" 2>/dev/null; then
    die "Delivery server already running for tenant=$tenant (PID $(cat "$pid"))"
  fi

  # Generate delivery TLS cert if not present
  [[ -f "$(server_cert "$tenant")" ]] || gen_delivery_tls "$tenant"

  # Write server script
  write_server_script "$tenant"

  # Open nftables
  fw_open_tenant "$tenant" "$open_fw"

  # Start server in background
  python3 "$(tenant_dir "$tenant")/delivery_server.py" \
    >> "$(audit_log "$tenant")" 2>&1 &
  echo $! > "$pid"

  log "Delivery server started: tenant=$tenant port=${DELIVER_PORT} PID=$!"
  echo ""
  echo "Delivery server started."
  echo "  URL:    https://$(hostname -f 2>/dev/null || hostname):${DELIVER_PORT}/"
  echo "  Tenant: $tenant"
  echo "  PID:    $(cat "$pid")"
  [[ "$open_fw" == "yes" ]] && \
    echo "  WARNING: Firewall open to ALL IPs (override mode)"
  echo ""
  echo "Monitor:  gw-cert-deliver.sh status $tenant"
  echo "Stop:     gw-cert-deliver.sh stop $tenant"
}

cmd_stop() {
  local tenant="${1:-}"
  [[ -n "$tenant" ]] || die "Usage: gw-cert-deliver.sh stop <tenant>"
  require_root

  local pid; pid="$(pid_file "$tenant")"
  if [[ -f "$pid" ]] && kill -0 "$(cat "$pid")" 2>/dev/null; then
    kill "$(cat "$pid")"
    rm -f "$pid"
    log "Delivery server stopped: tenant=$tenant"
    echo "Delivery server stopped for tenant=$tenant"
  else
    echo "No running delivery server found for tenant=$tenant"
  fi
  fw_close_tenant "$tenant"
}

cmd_status() {
  local tenant="${1:-}"
  [[ -n "$tenant" ]] || die "Usage: gw-cert-deliver.sh status <tenant>"
  need sqlite3

  local pid; pid="$(pid_file "$tenant")"
  echo "=== Delivery Server Status: $tenant ==="
  if [[ -f "$pid" ]] && kill -0 "$(cat "$pid")" 2>/dev/null; then
    echo "Server:  RUNNING (PID $(cat "$pid")) on port ${DELIVER_PORT}"
  else
    echo "Server:  STOPPED"
  fi

  echo ""
  echo "=== Certificate Delivery State ==="
  local db; db="$(state_file "$tenant")"
  [[ -f "$db" ]] || { echo "(no certs generated)"; return; }

  printf "%-40s %-12s %-6s %s\n" "Email" "Status" "Tries" "Downloaded At"
  printf "%-40s %-12s %-6s %s\n" "-----" "------" "-----" "-------------"
  sqlite3 "$db" \
    "SELECT email, status, attempts, COALESCE(downloaded_at,'—'), \
            COALESCE(source_ip,'—'), revoked \
     FROM certs ORDER BY email;" | while IFS='|' read -r em st at dt ip rv; do
    local flag=""
    [[ "$rv" == "1" ]] && flag=" [REVOKED]"
    printf "%-40s %-12s %-6s %s  IP: %s%s\n" "$em" "$st" "$at" "$dt" "$ip" "$flag"
  done

  echo ""
  local total pend done_n
  total=$(sqlite3 "$db" "SELECT COUNT(*) FROM certs;")
  pend=$(sqlite3  "$db" "SELECT COUNT(*) FROM certs WHERE status='pending' AND revoked=0;")
  done_n=$(sqlite3  "$db" "SELECT COUNT(*) FROM certs WHERE status='downloaded';")
  echo "Total: $total   Pending: $pend   Downloaded: $done_n"
}

cmd_report() {
  local tenant="${1:-}"
  [[ -n "$tenant" ]] || die "Usage: gw-cert-deliver.sh report <tenant>"
  local alog; alog="$(audit_log "$tenant")"
  echo "=== Audit Report: $tenant ==="
  [[ -f "$alog" ]] && cat "$alog" || echo "(no audit log)"
}

cmd_list() {
  local tenant="${1:-}"
  [[ -n "$tenant" ]] || die "Usage: gw-cert-deliver.sh list <tenant>"
  cmd_status "$tenant"
}

cmd_send_passwords() {
  local tenant="${1:-}"
  [[ -n "$tenant" ]] || die "Usage: gw-cert-deliver.sh send-passwords <tenant>"
  [[ "$SMTP_ENABLED" == "yes" ]] || \
    die "SMTP not enabled — set SMTP_ENABLED=yes and SMTP_* vars in portal.conf"

  local db; db="$(state_file "$tenant")"
  [[ -f "$db" ]] || die "No certs generated for tenant=$tenant"

  local portal_host; portal_host="$(hostname -f 2>/dev/null || hostname)"
  local sent=0 failed=0

  echo "=== Sending passwords via SMTP ==="
  echo "Relay: ${SMTP_HOST}:${SMTP_PORT}  From: ${SMTP_FROM}"
  echo ""

  sqlite3 "$db" "SELECT email, password_plain FROM certs WHERE revoked=0;" \
  | while IFS='|' read -r email password; do
    echo -n "  Sending to $email ... "
    if send_password_email "$email" "$password" "$tenant" "$portal_host"; then
      log "SMTP sent: email=$email tenant=$tenant"
      echo "OK"
    else
      log "SMTP failed: email=$email tenant=$tenant"
      echo "FAILED"
    fi
  done
}

cmd_revoke() {
  local tenant="${1:-}" email="${2:-}"
  [[ -n "$tenant" && -n "$email" ]] || \
    die "Usage: gw-cert-deliver.sh revoke <tenant> <email>"
  require_root; need sqlite3

  db_set "$tenant" "$email" "revoked" "1"
  db_set "$tenant" "$email" "status"  "revoked"
  log "REVOKED: email=$email tenant=$tenant"
  echo "Revoked: $email — download blocked"
}

# ── Dispatch ──────────────────────────────────────────────────────
case "${1:-}" in
  generate)       cmd_generate      "${2:-}" "${3:-}" ;;
  start)          cmd_start         "${2:-}" "${3:-}" ;;
  stop)           cmd_stop          "${2:-}" ;;
  status)         cmd_status        "${2:-}" ;;
  report)         cmd_report        "${2:-}" ;;
  list)           cmd_list          "${2:-}" ;;
  send-passwords) cmd_send_passwords "${2:-}" ;;
  revoke)         cmd_revoke        "${2:-}" "${3:-}" ;;
  -h|--help|help|"")
    echo "gw-cert-deliver.sh $VERSION — mTLS client certificate generation and delivery"
    echo ""
    echo "Usage:"
    echo "  gw-cert-deliver.sh generate  <tenant> <email-list.txt>  Generate certs + manifest"
    echo "  gw-cert-deliver.sh start     <tenant> [--open-firewall]  Start delivery server"
    echo "  gw-cert-deliver.sh stop      <tenant>                    Stop server + close firewall"
    echo "  gw-cert-deliver.sh status    <tenant>                    Server + delivery state"
    echo "  gw-cert-deliver.sh report    <tenant>                    Full audit log"
    echo "  gw-cert-deliver.sh list      <tenant>                    List certs + state"
    echo "  gw-cert-deliver.sh send-passwords <tenant>               Email passwords via SMTP"
    echo "  gw-cert-deliver.sh revoke    <tenant> <email>            Block a user's download"
    echo ""
    echo "Workflow:"
    echo "  1. Create email list:  vi /tmp/tenant-users.txt   (one email per line)"
    echo "  2. Generate certs:     gw-cert-deliver.sh generate <tenant> /tmp/tenant-users.txt"
    echo "  3. Send passwords:     gw-cert-deliver.sh send-passwords <tenant>"
    echo "     OR distribute manifest manually: cat ${DELIVER_BASE}/<tenant>/manifest.txt"
    echo "  4. Start server:       gw-cert-deliver.sh start <tenant>"
    echo "  5. Monitor:            gw-cert-deliver.sh status <tenant>"
    echo "  6. Server auto-stops when all certs downloaded"
    echo "  7. Audit trail:        gw-cert-deliver.sh report <tenant>"
    echo ""
    echo "Configuration (portal.conf):"
    echo "  DELIVER_PORT             (default: 8443)"
    echo "  DELIVER_VALIDITY_DAYS    (default: 365)"
    echo "  DELIVER_WINDOW_MINUTES   (default: 15)"
    echo "  DELIVER_MAX_ATTEMPTS     (default: 3)"
    echo "  SMTP_ENABLED             yes|no"
    echo "  SMTP_HOST / SMTP_PORT / SMTP_USER / SMTP_PASS / SMTP_FROM"
    echo "  SMTP_TLS                 starttls|ssl|none"
    ;;
  *) die "Unknown command: ${1} — run gw-cert-deliver.sh help" ;;
esac
