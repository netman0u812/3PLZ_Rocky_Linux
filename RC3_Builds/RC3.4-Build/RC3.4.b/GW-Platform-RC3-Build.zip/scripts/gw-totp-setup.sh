#!/bin/bash
# gw-totp-setup.sh v RC3.4 — Admin portal TOTP enrollment and management.
#
# Manages TOTP second-factor authentication for admin portal SSH access.
# Uses PAM + Google Authenticator (libpam-google-authenticator).
# Compatible with any RFC 6238 TOTP app:
#   Google Authenticator, Authy, Microsoft Authenticator, 1Password, etc.
#
# Enrollment flow:
#   1. Generates TOTP secret for the user
#   2. Renders ASCII QR code to terminal (scan with phone)
#   3. Shows manual entry key as fallback
#   4. Prompts user to enter a valid code to confirm before finalizing
#   5. Writes ~/.google_authenticator for the user
#
# Usage:
#   gw-totp-setup.sh enroll   <username>   Enroll a new admin user
#   gw-totp-setup.sh reenroll <username>   Re-enroll (lost authenticator)
#   gw-totp-setup.sh revoke   <username>   Revoke TOTP access
#   gw-totp-setup.sh verify   <username>   Test a user's TOTP without login
#   gw-totp-setup.sh list                  List all enrolled admin users
#   gw-totp-setup.sh status   <username>   Show enrollment status for a user

set -euo pipefail
VERSION="RC3.4"

# ── Helpers ───────────────────────────────────────────────────────
isotime() {
    python3 -c "from datetime import datetime,timezone; \
print(datetime.now(timezone.utc).astimezone().isoformat(timespec='seconds'))"
}

die()  { echo ""; echo "ERROR: $*" >&2; exit 1; }
info() { echo "  $*"; }
ok()   { echo "  ✓ $*"; }
warn() { echo "  ⚠ $*"; }

require_root() {
    [[ "${EUID:-$(id -u)}" -eq 0 ]] || die "Run as root"
}

need() {
    command -v "$1" >/dev/null 2>&1 || \
        die "Required tool not found: $1 — install with: dnf install $2"
}

LOG=/var/log/gw-totp-setup.log
log() { echo "[$(isotime)] $*" >> "$LOG" 2>/dev/null || true; }

PORTAL_ISSUER="${PORTAL_ISSUER:-GW-Platform-RC3}"
TOTP_WINDOW="${TOTP_WINDOW:-1}"         # +/- 1 window = 90s grace
TOTP_RATE_LIMIT="${TOTP_RATE_LIMIT:-3}" # 3 attempts per 30s

# ── Dependency check ──────────────────────────────────────────────
check_deps() {
    need google-authenticator google-authenticator-libpam
    need python3               python3
    need oathtool              oathtool 2>/dev/null || true  # for verify cmd
}

# ── QR code rendering ─────────────────────────────────────────────
# Renders an otpauth:// URI as ASCII QR code using Python qrcode library.
# Falls back to a clear manual entry instruction if qrcode not installed.
render_qr() {
    local uri="$1"

    # Try qrcode library first
    if python3 -c "import qrcode" 2>/dev/null; then
        python3 << PYEOF
import qrcode, sys
uri = "${uri}"
qr = qrcode.QRCode(
    version=None,
    error_correction=qrcode.constants.ERROR_CORRECT_M,
    box_size=1,
    border=2,
)
qr.add_data(uri)
qr.make(fit=True)
# ASCII render — works over any SSH session
matrix = qr.get_matrix()
for row in matrix:
    line = ""
    for cell in row:
        line += "██" if cell else "  "
    print(line)
PYEOF
        return 0
    fi

    # Fallback — instruct user to use manual entry
    warn "Python qrcode library not installed — use manual entry key below"
    warn "Install for QR support: pip3 install qrcode --break-system-packages"
    return 1
}

# ── TOTP secret generation ────────────────────────────────────────
generate_secret() {
    # 20 bytes = 160 bits = base32 secret compatible with all TOTP apps
    python3 -c "
import os, base64
raw = os.urandom(20)
secret = base64.b32encode(raw).decode().rstrip('=')
print(secret)
"
}

# ── Build otpauth URI ─────────────────────────────────────────────
build_uri() {
    local secret="$1" username="$2"
    local portal_host; portal_host="$(hostname -f 2>/dev/null || hostname)"
    # URI format: otpauth://totp/<issuer>:<account>?secret=<secret>&issuer=<issuer>
    echo "otpauth://totp/${PORTAL_ISSUER}:${username}@${portal_host}?secret=${secret}&issuer=${PORTAL_ISSUER}&algorithm=SHA1&digits=6&period=30"
}

# ── Write google_authenticator file ──────────────────────────────
write_ga_file() {
    local username="$1" secret="$2"
    local home; home="$(getent passwd "$username" | cut -d: -f6)"
    [[ -n "$home" ]] || die "Cannot determine home directory for user: $username"
    [[ -d "$home" ]] || die "Home directory does not exist: $home"

    local ga_file="${home}/.google_authenticator"

    # Format expected by pam_google_authenticator:
    # Line 1: secret
    # Line 2: options
    # Lines 3+: emergency scratch codes (8-digit one-time use)
    local scratch_codes
    scratch_codes=$(python3 -c "
import random
codes = [str(random.randint(10000000, 99999999)) for _ in range(5)]
print('\n'.join(codes))
")

    cat > "$ga_file" << GAEOF
${secret}
\" RATE_LIMIT ${TOTP_RATE_LIMIT} 30
\" WINDOW_SIZE ${TOTP_WINDOW}
\" DISALLOW_REUSE
\" TOTP_AUTH
${scratch_codes}
GAEOF

    chmod 600 "$ga_file"
    chown "${username}:${username}" "$ga_file" 2>/dev/null || \
        chown "${username}" "$ga_file"

    echo "$scratch_codes"
}

# ── Validate a TOTP code against a secret ────────────────────────
validate_code() {
    local secret="$1" code="$2"

    # Use oathtool if available
    if command -v oathtool >/dev/null 2>&1; then
        local expected; expected=$(oathtool --totp --base32 "$secret" 2>/dev/null)
        [[ "$code" == "$expected" ]] && return 0

        # Also check +/- 1 window (30s grace each side)
        local prev next
        prev=$(oathtool --totp --base32 "$secret" --now "-30 seconds" 2>/dev/null || true)
        next=$(oathtool --totp --base32 "$secret" --now "+30 seconds" 2>/dev/null || true)
        [[ "$code" == "$prev" || "$code" == "$next" ]] && return 0
        return 1
    fi

    # Fallback — Python HMAC-based TOTP
    python3 << PYEOF
import hmac, hashlib, struct, time, base64, sys

def totp(secret, offset=0):
    try:
        key = base64.b32decode(secret.upper() + '=' * (-len(secret) % 8))
    except Exception:
        sys.exit(2)
    t = int((time.time() + offset * 30) / 30)
    msg = struct.pack('>Q', t)
    h = hmac.new(key, msg, hashlib.sha1).digest()
    o = h[-1] & 0xf
    code = (struct.unpack('>I', h[o:o+4])[0] & 0x7fffffff) % 1000000
    return f"{code:06d}"

entered = "${code}"
secret  = "${secret}"
valid = any(totp(secret, o) == entered for o in (-1, 0, 1))
sys.exit(0 if valid else 1)
PYEOF
}

# ── Enrollment confirmation loop ──────────────────────────────────
confirm_enrollment() {
    local secret="$1" username="$2"
    local attempts=0 max_attempts=5

    echo ""
    echo "  ─────────────────────────────────────────────"
    echo "  ENROLLMENT CONFIRMATION"
    echo "  ─────────────────────────────────────────────"
    echo "  Open your authenticator app, find the entry"
    echo "  for '${PORTAL_ISSUER} / ${username}'"
    echo "  and enter the current 6-digit code below."
    echo ""
    echo "  You have ${max_attempts} attempts."
    echo "  ─────────────────────────────────────────────"
    echo ""

    while [[ $attempts -lt $max_attempts ]]; do
        local code
        read -r -p "  Enter 6-digit code: " code
        code="${code//[[:space:]]/}"

        if [[ ! "$code" =~ ^[0-9]{6}$ ]]; then
            warn "Code must be exactly 6 digits"
            attempts=$(( attempts + 1 ))
            continue
        fi

        if validate_code "$secret" "$code"; then
            echo ""
            ok "Code verified — enrollment confirmed"
            return 0
        else
            attempts=$(( attempts + 1 ))
            local remaining=$(( max_attempts - attempts ))
            if [[ $remaining -gt 0 ]]; then
                warn "Incorrect code. ${remaining} attempt(s) remaining."
                warn "Make sure your phone clock is accurate."
            fi
        fi
    done

    echo ""
    warn "Enrollment confirmation failed after ${max_attempts} attempts."
    warn "Enrollment has NOT been saved."
    return 1
}

# ══════════════════════════════════════════════════════════════════
# COMMANDS
# ══════════════════════════════════════════════════════════════════

cmd_enroll() {
    local username="${1:-}"
    [[ -n "$username" ]] || die "Usage: gw-totp-setup.sh enroll <username>"
    require_root
    check_deps

    # Verify user exists
    id "$username" >/dev/null 2>&1 || die "User does not exist: $username"

    local home; home="$(getent passwd "$username" | cut -d: -f6)"
    local ga_file="${home}/.google_authenticator"

    # Warn if already enrolled
    if [[ -f "$ga_file" ]]; then
        echo ""
        warn "User $username is already enrolled."
        read -r -p "  Re-enroll and replace existing TOTP secret? [y/N] " confirm
        [[ "${confirm,,}" == "y" ]] || { echo "  Cancelled."; exit 0; }
        # Backup existing
        cp "$ga_file" "${ga_file}.bak.$(date +%Y%m%d%H%M%S)"
        info "Existing config backed up"
    fi

    local portal_host; portal_host="$(hostname -f 2>/dev/null || hostname)"
    local secret; secret="$(generate_secret)"
    local uri;    uri="$(build_uri "$secret" "$username")"

    echo ""
    echo "══════════════════════════════════════════════════════"
    echo "  TOTP ENROLLMENT — ${username}@${portal_host}"
    echo "══════════════════════════════════════════════════════"
    echo ""
    echo "  Scan the QR code below with your authenticator app."
    echo ""

    # Render QR
    render_qr "$uri"
    echo ""

    # Always show manual entry key — some apps prefer it
    echo "  ─────────────────────────────────────────────"
    echo "  MANUAL ENTRY (if QR scan is not available)"
    echo "  ─────────────────────────────────────────────"
    echo ""
    echo "  Account:  ${username}@${portal_host}"
    echo "  Issuer:   ${PORTAL_ISSUER}"
    echo "  Key:      ${secret}"
    echo "  Type:     Time-based (TOTP)"
    echo "  Digits:   6"
    echo "  Period:   30 seconds"
    echo ""
    echo "  ─────────────────────────────────────────────"

    # Confirm enrollment with a live code
    if ! confirm_enrollment "$secret" "$username"; then
        log "ENROLL_FAILED: user=${username} reason=confirmation_failed"
        exit 1
    fi

    # Write google_authenticator file
    local scratch_codes; scratch_codes="$(write_ga_file "$username" "$secret")"

    echo ""
    echo "  ─────────────────────────────────────────────"
    echo "  EMERGENCY SCRATCH CODES"
    echo "  ─────────────────────────────────────────────"
    echo "  Save these codes securely. Each can be used"
    echo "  once if you lose access to your TOTP app."
    echo "  STORE SEPARATELY from your device."
    echo ""
    while IFS= read -r code; do
        echo "    $code"
    done <<< "$scratch_codes"
    echo ""
    echo "  ─────────────────────────────────────────────"
    echo ""
    ok "TOTP enrollment complete for: ${username}"
    echo ""
    echo "  The next SSH login for ${username} will require"
    echo "  a valid TOTP code from your authenticator app."
    echo ""

    log "ENROLLED: user=${username} host=${portal_host}"
}

cmd_reenroll() {
    local username="${1:-}"
    [[ -n "$username" ]] || die "Usage: gw-totp-setup.sh reenroll <username>"
    require_root

    local home; home="$(getent passwd "$username" | cut -d: -f6)"
    local ga_file="${home}/.google_authenticator"

    echo ""
    warn "Re-enrolling ${username} — existing TOTP secret will be replaced."
    read -r -p "  Confirm re-enrollment? [y/N] " confirm
    [[ "${confirm,,}" == "y" ]] || { echo "  Cancelled."; exit 0; }

    # Remove existing config to force clean enroll
    if [[ -f "$ga_file" ]]; then
        cp "$ga_file" "${ga_file}.bak.$(date +%Y%m%d%H%M%S)"
        rm -f "$ga_file"
        info "Previous config archived"
    fi

    log "REENROLL_START: user=${username}"
    cmd_enroll "$username"
}

cmd_revoke() {
    local username="${1:-}"
    [[ -n "$username" ]] || die "Usage: gw-totp-setup.sh revoke <username>"
    require_root

    local home; home="$(getent passwd "$username" | cut -d: -f6)"
    local ga_file="${home}/.google_authenticator"

    echo ""
    if [[ ! -f "$ga_file" ]]; then
        warn "User ${username} has no TOTP enrollment to revoke"
        exit 0
    fi

    warn "Revoking TOTP access for: ${username}"
    read -r -p "  Confirm revocation? [y/N] " confirm
    [[ "${confirm,,}" == "y" ]] || { echo "  Cancelled."; exit 0; }

    # Archive before removal
    cp "$ga_file" "${ga_file}.revoked.$(date +%Y%m%d%H%M%S)"
    rm -f "$ga_file"

    ok "TOTP access revoked for: ${username}"
    warn "User ${username} will be unable to SSH to the portal until re-enrolled"
    echo ""

    log "REVOKED: user=${username}"
}

cmd_verify() {
    local username="${1:-}"
    [[ -n "$username" ]] || die "Usage: gw-totp-setup.sh verify <username>"
    require_root

    local home; home="$(getent passwd "$username" | cut -d: -f6)"
    local ga_file="${home}/.google_authenticator"

    [[ -f "$ga_file" ]] || die "User ${username} is not enrolled"

    local secret; secret="$(head -1 "$ga_file")"

    echo ""
    echo "  Verifying TOTP for: ${username}"
    echo "  Enter the current 6-digit code from your authenticator app."
    echo ""
    read -r -p "  Code: " code
    code="${code//[[:space:]]/}"

    if validate_code "$secret" "$code"; then
        echo ""
        ok "Code is valid — TOTP is working correctly for ${username}"
        echo ""
        log "VERIFY_OK: user=${username}"
    else
        echo ""
        warn "Code is INVALID for ${username}"
        warn "Check that your phone clock is accurate (within 30 seconds)"
        warn "If the problem persists, re-enroll: gw-totp-setup.sh reenroll ${username}"
        echo ""
        log "VERIFY_FAIL: user=${username}"
        exit 1
    fi
}

cmd_list() {
    require_root
    echo ""
    echo "=== Enrolled Admin TOTP Users ==="
    echo ""
    printf "  %-20s %-12s %s\n" "Username" "Status" "Enrolled / Last Modified"
    printf "  %-20s %-12s %s\n" "--------" "------" "------------------------"

    local found=0
    while IFS=: read -r username _ uid _ _ home _; do
        # Only consider users with UID >= 1000 or explicit admin group membership
        [[ "$uid" -ge 1000 ]] 2>/dev/null || continue
        local ga_file="${home}/.google_authenticator"
        if [[ -f "$ga_file" ]]; then
            local modified; modified=$(stat -c '%y' "$ga_file" 2>/dev/null | cut -d'.' -f1 || \
                                       stat -f '%Sm' "$ga_file" 2>/dev/null || echo "unknown")
            printf "  %-20s %-12s %s\n" "$username" "ENROLLED" "$modified"
            found=$(( found + 1 ))
        fi
    done < /etc/passwd

    # Also check for revoked backups
    while IFS=: read -r username _ uid _ _ home _; do
        [[ "$uid" -ge 1000 ]] 2>/dev/null || continue
        local ga_file="${home}/.google_authenticator"
        if [[ ! -f "$ga_file" ]] && ls "${ga_file}.revoked."* >/dev/null 2>&1; then
            local revoked_file; revoked_file=$(ls -t "${ga_file}.revoked."* 2>/dev/null | head -1)
            local revoked_time; revoked_time=$(basename "$revoked_file" | sed 's/.*revoked\.//')
            printf "  %-20s %-12s %s\n" "$username" "REVOKED" "$revoked_time"
        fi
    done < /etc/passwd

    echo ""
    if [[ $found -eq 0 ]]; then
        info "No users currently enrolled"
    else
        info "Total enrolled: ${found}"
    fi
    echo ""
}

cmd_status() {
    local username="${1:-}"
    [[ -n "$username" ]] || die "Usage: gw-totp-setup.sh status <username>"
    require_root

    id "$username" >/dev/null 2>&1 || die "User does not exist: $username"
    local home; home="$(getent passwd "$username" | cut -d: -f6)"
    local ga_file="${home}/.google_authenticator"

    echo ""
    echo "=== TOTP Status: ${username} ==="
    echo ""

    if [[ -f "$ga_file" ]]; then
        local modified; modified=$(stat -c '%y' "$ga_file" 2>/dev/null | cut -d'.' -f1 || \
                                   stat -f '%Sm' "$ga_file" 2>/dev/null || echo "unknown")
        ok "Status:    ENROLLED"
        info "Config:    ${ga_file}"
        info "Modified:  ${modified}"

        # Count scratch codes remaining
        local scratch_count; scratch_count=$(grep -cE '^[0-9]{8}$' "$ga_file" 2>/dev/null || echo 0)
        info "Scratch codes remaining: ${scratch_count}"

        # Check PAM config
        if grep -q 'pam_google_authenticator' /etc/pam.d/sshd 2>/dev/null; then
            ok "PAM:       pam_google_authenticator configured in /etc/pam.d/sshd"
        else
            warn "PAM:       pam_google_authenticator NOT found in /etc/pam.d/sshd"
            warn "           Run: gw-totp-setup.sh install-pam  to configure"
        fi
    else
        warn "Status:    NOT ENROLLED"
        if ls "${ga_file}.revoked."* >/dev/null 2>&1; then
            local revoked_file; revoked_file=$(ls -t "${ga_file}.revoked."* 2>/dev/null | head -1)
            warn "           Previously revoked — backup at: ${revoked_file}"
        fi
        info "Enroll:    gw-totp-setup.sh enroll ${username}"
    fi
    echo ""
}

cmd_install_pam() {
    require_root
    echo ""
    info "Configuring PAM for TOTP SSH authentication..."

    local pam_sshd="/etc/pam.d/sshd"
    local sshd_config="/etc/ssh/sshd_config"

    [[ -f "$pam_sshd" ]] || die "PAM sshd config not found: $pam_sshd"

    # Backup PAM config
    cp "$pam_sshd" "${pam_sshd}.bak.$(date +%Y%m%d%H%M%S)"

    # Add google-authenticator to PAM if not already present
    if grep -q 'pam_google_authenticator' "$pam_sshd"; then
        ok "pam_google_authenticator already in ${pam_sshd}"
    else
        # Insert at top of auth stack — required before password
        sed -i '1s/^/auth required pam_google_authenticator.so nullok\n/' "$pam_sshd"
        ok "Added pam_google_authenticator to ${pam_sshd}"
    fi

    # Ensure SSH ChallengeResponseAuthentication is enabled
    if [[ -f "$sshd_config" ]]; then
        cp "$sshd_config" "${sshd_config}.bak.$(date +%Y%m%d%H%M%S)"
        # Enable keyboard-interactive
        sed -i 's/^#*ChallengeResponseAuthentication.*/ChallengeResponseAuthentication yes/' "$sshd_config"
        sed -i 's/^#*KbdInteractiveAuthentication.*/KbdInteractiveAuthentication yes/' "$sshd_config"
        # Require both pubkey and TOTP for admin users
        if ! grep -q 'AuthenticationMethods' "$sshd_config"; then
            echo "" >> "$sshd_config"
            echo "# GW Platform RC3.4 — Require pubkey + TOTP for all users" >> "$sshd_config"
            echo "AuthenticationMethods publickey,keyboard-interactive" >> "$sshd_config"
        fi
        ok "sshd_config updated"
    fi

    # Reload sshd
    if systemctl reload sshd 2>/dev/null || systemctl reload ssh 2>/dev/null; then
        ok "sshd reloaded"
    else
        warn "Could not reload sshd — reload manually: systemctl reload sshd"
    fi

    echo ""
    ok "PAM TOTP configuration complete"
    warn "Existing SSH sessions are NOT affected"
    warn "New logins will require TOTP — ensure at least one user is enrolled"
    warn "before closing this session"
    echo ""
    log "PAM_INSTALLED: host=$(hostname)"
}

# ── Dispatch ──────────────────────────────────────────────────────
case "${1:-}" in
    enroll)      cmd_enroll      "${2:-}" ;;
    reenroll)    cmd_reenroll    "${2:-}" ;;
    revoke)      cmd_revoke      "${2:-}" ;;
    verify)      cmd_verify      "${2:-}" ;;
    list)        cmd_list ;;
    status)      cmd_status      "${2:-}" ;;
    install-pam) cmd_install_pam ;;
    -h|--help|help|"")
        echo ""
        echo "gw-totp-setup.sh ${VERSION} — Admin portal TOTP enrollment and management"
        echo ""
        echo "Usage:"
        echo "  gw-totp-setup.sh enroll      <username>   Enroll a new admin user"
        echo "  gw-totp-setup.sh reenroll    <username>   Re-enroll (lost authenticator)"
        echo "  gw-totp-setup.sh revoke      <username>   Revoke TOTP access"
        echo "  gw-totp-setup.sh verify      <username>   Test TOTP without a login"
        echo "  gw-totp-setup.sh list                     List all enrolled users"
        echo "  gw-totp-setup.sh status      <username>   Show enrollment status"
        echo "  gw-totp-setup.sh install-pam              Configure PAM + sshd for TOTP"
        echo ""
        echo "First-time setup:"
        echo "  1. gw-totp-setup.sh install-pam           Configure PAM (once per portal)"
        echo "  2. gw-totp-setup.sh enroll <username>     Enroll each admin user"
        echo "  3. gw-totp-setup.sh verify <username>     Confirm working before logout"
        echo ""
        echo "Compatible authenticator apps (any RFC 6238 TOTP app):"
        echo "  Google Authenticator, Authy, Microsoft Authenticator, 1Password"
        echo ""
        echo "Configuration (portal.conf):"
        echo "  PORTAL_ISSUER    Label shown in authenticator app (default: GW-Platform-RC3)"
        echo "  TOTP_WINDOW      Clock skew window in 30s steps (default: 1)"
        echo "  TOTP_RATE_LIMIT  Max attempts per 30s period (default: 3)"
        echo ""
        ;;
    *) die "Unknown command: ${1} — run gw-totp-setup.sh help" ;;
esac
