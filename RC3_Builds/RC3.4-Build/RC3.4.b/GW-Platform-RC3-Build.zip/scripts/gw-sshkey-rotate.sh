#!/usr/bin/env bash
# gw-sshkey-rotate.sh — Generate new portal SSH keypair, distribute to GW nodes.
# Rotates local admin authorized_keys AND pushes directly to GW nodes.
# Keeps last 2 key generations; prunes older files.
set -euo pipefail

# ── Portable compatibility (Linux + macOS) ──────────────────────
sha256_cmd() {
  if command -v sha256sum >/dev/null 2>&1; then sha256sum "$@"; else shasum -a 256 "$@"; fi
}
isotime() {
  python3 -c "from datetime import datetime,timezone; print(datetime.now(timezone.utc).astimezone().isoformat(timespec=\'seconds\'))"
}
epoch_to_date() {
  python3 -c "from datetime import datetime; print(datetime.fromtimestamp(int(\'$1\')).strftime(\'%Y-%m-%d %H:%M:%S\'))"
}
# ─────────────────────────────────────────────────────────────────

CONF="${CONF:-/etc/gw-admin-portal/admin-portal.conf}"
KNOWN_HOSTS=/etc/ssh/ssh_known_hosts

die() { echo "ERROR: $*" >&2; exit 1; }
log() { echo "[gw-sshkey-rotate] $*"; }

[[ "${EUID:-$(id -u)}" -eq 0 ]] || die "Run as root"
[[ -f "$CONF" ]] || die "Missing config $CONF"
# shellcheck disable=SC1090
source "$CONF"

keydir="${SSH_KEY_DIR:-/var/lib/gw-admin-portal/sshkeys}"
keyname="${SSH_KEY_NAME:-gwportal_ed25519}"
keep_generations=2

mkdir -p "$keydir"
chmod 700 "$keydir"

stamp="$(date +%Y%m%d-%H%M%S)"
new_priv="${keydir}/${keyname}.${stamp}"
new_pub="${new_priv}.pub"

# Generate new keypair
ssh-keygen -t ed25519 -N "" -f "$new_priv" -C "gw-admin-portal ${stamp}" >/dev/null
chmod 600 "$new_priv"
chmod 644 "$new_pub"

# Update symlinks atomically
ln -sfn "$(basename "$new_priv")" "${keydir}/${keyname}"
ln -sfn "$(basename "$new_pub")"  "${keydir}/${keyname}.pub"

log "New keypair: $new_priv"

# Update authorized_keys for each admin user on portal
for u in ${ADMIN_USERS:-}; do
  home="/home/${u}"
  sshdir="${home}/.ssh"
  auth="${sshdir}/authorized_keys"
  mkdir -p "$sshdir"
  chmod 700 "$sshdir"
  chown "$u:$u" "$sshdir" 2>/dev/null || true

  # Strip old portal keys, add new one
  if [[ -f "$auth" ]]; then
    grep -v 'gw-admin-portal' "$auth" > "${auth}.tmp" || true
  else
    : > "${auth}.tmp"
  fi
  cat "$new_pub" >> "${auth}.tmp"
  mv "${auth}.tmp" "$auth"
  chmod 600 "$auth"
  chown "$u:$u" "$auth" 2>/dev/null || true
  log "Updated portal authorized_keys for ${u}"
done

# Push new public key directly to each GW node (does not rely on NFS)
# GW nodes must be listed in /etc/hosts as gw-* and enrolled in known_hosts
PUSH_FAIL=0
while IFS= read -r line; do
  gw_name="$(echo "$line" | awk '{print $2}')"
  [[ "$gw_name" =~ ^gw- ]] || continue
  for u in ${ADMIN_USERS:-}; do
    if ssh -i "${keydir}/${keyname}" \
           -o StrictHostKeyChecking=yes \
           -o UserKnownHostsFile="$KNOWN_HOSTS" \
           -o ConnectTimeout=10 \
           -o BatchMode=yes \
           "${u}@${gw_name}" \
           "mkdir -p ~/.ssh && chmod 700 ~/.ssh && \
            grep -v 'gw-admin-portal' ~/.ssh/authorized_keys 2>/dev/null > ~/.ssh/authorized_keys.tmp || true; \
            cat >> ~/.ssh/authorized_keys.tmp; \
            mv ~/.ssh/authorized_keys.tmp ~/.ssh/authorized_keys; \
            chmod 600 ~/.ssh/authorized_keys" \
           < "$new_pub" 2>/dev/null; then
      log "[OK]   Pushed to ${gw_name} for ${u}"
    else
      log "[WARN] Could not push to ${gw_name} for ${u} — NFS fallback may apply"
      PUSH_FAIL=$(( PUSH_FAIL + 1 ))
    fi
  done
done < <(grep -E '^[^#]+[[:space:]]+gw-' /etc/hosts 2>/dev/null || true)

[[ "$PUSH_FAIL" -gt 0 ]] && log "WARNING: $PUSH_FAIL push(es) failed. Verify GW node connectivity."

# Prune old key generations — keep only last $keep_generations
mapfile -t old_keys < <(
  find "$keydir" -maxdepth 1 -name "${keyname}.[0-9]*" ! -name "*.pub" \
  | sort | head -n "-${keep_generations}" 2>/dev/null || true
)
for k in "${old_keys[@]}"; do
  rm -f "$k" "${k}.pub"
  log "Pruned old key: $k"
done

log "Rotation complete. Active key: ${keydir}/${keyname}"
