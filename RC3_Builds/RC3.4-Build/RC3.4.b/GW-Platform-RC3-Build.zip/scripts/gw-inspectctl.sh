#!/bin/bash
# gw-inspectctl.sh — Traffic inspection tap management (ERSPAN/VXLAN mirror).
# Version: 0.1.1
# Usage:
#   gw-inspectctl.sh install
#   gw-inspectctl.sh apply  <tenant>
#   gw-inspectctl.sh status <tenant>
#   gw-inspectctl.sh remove <tenant>
#   gw-inspectctl.sh version
set -euo pipefail

VERSION="0.1.1"
MIN_GWCTL_VERSION="1.1.3"
MIN_GWREG_VERSION="0.1.1"

# ── Portable compatibility (Linux + macOS) ──────────────────────
sha256_cmd() {
  if command -v sha256sum >/dev/null 2>&1; then sha256sum "$@"; else shasum -a 256 "$@"; fi
}
isotime() {
  python3 -c "from datetime import datetime,timezone; print(datetime.now(timezone.utc).astimezone().isoformat(timespec='seconds'))"
}
# ─────────────────────────────────────────────────────────────────

CONF_DIR="${GW_CONF_DIR:-/etc/gateway/tenants}"
LOG=/var/log/gw-inspection.log

die()  { echo "ERROR: $*" >&2; exit 1; }
log()  { echo "[$(isotime)] $*" | tee -a "$LOG"; }
warn() { echo "WARN:  $*" | tee -a "$LOG"; }
need() { command -v "$1" >/dev/null 2>&1 || die "Missing dependency: $1"; }

# ── Version guard ─────────────────────────────────────────────────
version_gte() {
  # Returns 0 if $1 >= $2 (semver comparison)
  python3 -c "
from functools import reduce
def v(s): return [int(x) for x in s.split('.')]
import sys
a, b = sys.argv[1], sys.argv[2]
sys.exit(0 if v(a) >= v(b) else 1)
" "$1" "$2"
}

check_component_versions() {
  local gwctl_ver gwreg_ver
  gwctl_ver="$(gwctl --version 2>/dev/null | grep -oE '[0-9]+\.[0-9]+\.[0-9]+' | head -1 || echo '')"
  gwreg_ver="$(gwreg --version 2>/dev/null | grep -oE '[0-9]+\.[0-9]+\.[0-9]+' | head -1 || echo '')"

  if [[ -z "$gwctl_ver" ]]; then
    die "gwctl not found or --version failed. Ensure gw-builder is installed before gw-inspection."
  fi
  if [[ -z "$gwreg_ver" ]]; then
    die "gwreg not found or --version failed. Ensure gw-registry is installed before gw-inspection."
  fi

  version_gte "$gwctl_ver" "$MIN_GWCTL_VERSION" \
    || die "gwctl version $gwctl_ver is below minimum $MIN_GWCTL_VERSION required by gw-inspection $VERSION"
  version_gte "$gwreg_ver" "$MIN_GWREG_VERSION" \
    || die "gwreg version $gwreg_ver is below minimum $MIN_GWREG_VERSION required by gw-inspection $VERSION"

  log "Version check OK: gwctl=$gwctl_ver gwreg=$gwreg_ver"
}

load_tenant_conf() {
  local tenant="$1"
  local conf="${CONF_DIR}/${tenant}.conf"
  [[ -f "$conf" ]] || die "Tenant conf not found: $conf"
  # shellcheck disable=SC1090
  source "$conf"
}

# ── Tap helpers ───────────────────────────────────────────────────
tap_remove_idempotent() {
  # Remove existing tc filters and mirror tunnel for a tenant — safe to call
  # even if nothing exists. Clears state before a fresh apply.
  local tenant="$1"
  local decrypt_if="${DECRYPT_IFACE:-dec-${tenant}}"

  # Remove tc ingress + egress filters
  tc qdisc del dev "$decrypt_if" ingress 2>/dev/null || true
  tc qdisc del dev "$decrypt_if" clsact  2>/dev/null || true

  # Remove mirror tunnel interface
  ip link del "mirror-${tenant}" 2>/dev/null || true

  log "Tap removed (idempotent): tenant=$tenant"
}

apply_erspan_tap() {
  local tenant="$1" dst_ip="$2" key="$3" egress_if="$4" rate_bps="$5"
  local decrypt_if="${DECRYPT_IFACE:-dec-${tenant}}"
  local mirror_if="mirror-${tenant}"

  # Create ERSPAN v2 tunnel
  ip link add "$mirror_if" type erspan \
    remote "$dst_ip" \
    key "$key" \
    erspan_ver 2 \
    erspan_hwid 1 2>/dev/null || true
  ip link set "$mirror_if" up

  # Add ingress qdisc + mirror (inbound plaintext)
  tc qdisc add dev "$decrypt_if" ingress
  tc filter add dev "$decrypt_if" parent ffff: \
    protocol all u32 match u32 0 0 \
    action mirred egress mirror dev "$mirror_if" \
    ${rate_bps:+action police rate ${rate_bps}bps burst $((rate_bps / 8)) drop}

  # Add egress clsact + mirror (outbound plaintext)
  tc qdisc add dev "$decrypt_if" clsact
  tc filter add dev "$decrypt_if" parent ffff:fff1 \
    protocol all u32 match u32 0 0 \
    action mirred egress mirror dev "$mirror_if" \
    ${rate_bps:+action police rate ${rate_bps}bps burst $((rate_bps / 8)) drop}

  log "ERSPAN tap applied: tenant=$tenant dst=$dst_ip key=$key"
}

apply_vxlan_tap() {
  local tenant="$1" dst_ip="$2" key="$3" egress_if="$4" rate_bps="$5"
  local decrypt_if="${DECRYPT_IFACE:-dec-${tenant}}"
  local mirror_if="mirror-${tenant}"

  # Create VXLAN mirror tunnel (no multicast, unicast to collector)
  ip link add "$mirror_if" type vxlan \
    id "$key" \
    remote "$dst_ip" \
    dstport 4789 \
    dev "$egress_if" 2>/dev/null || true
  ip link set "$mirror_if" up

  # Ingress mirror
  tc qdisc add dev "$decrypt_if" ingress
  tc filter add dev "$decrypt_if" parent ffff: \
    protocol all u32 match u32 0 0 \
    action mirred egress mirror dev "$mirror_if" \
    ${rate_bps:+action police rate ${rate_bps}bps burst $((rate_bps / 8)) drop}

  # Egress mirror
  tc qdisc add dev "$decrypt_if" clsact
  tc filter add dev "$decrypt_if" parent ffff:fff1 \
    protocol all u32 match u32 0 0 \
    action mirred egress mirror dev "$mirror_if" \
    ${rate_bps:+action police rate ${rate_bps}bps burst $((rate_bps / 8)) drop}

  log "VXLAN tap applied: tenant=$tenant dst=$dst_ip key=$key"
}

apply_nft_guardrail() {
  # Allow mirror traffic to leave on the designated tap egress interface only
  local tenant="$1" egress_if="$2" dst_ip="$3" tap_type="$4"
  local dport; dport=4789
  [[ "$tap_type" == "erspan" ]] && dport=1998  # GRE-based

  nft add table inet "gw_inspect_allow" 2>/dev/null || true
  nft add chain inet "gw_inspect_allow" "output_${tenant}" \
    '{ type filter hook output priority 0; policy accept; }' 2>/dev/null || true
  nft add rule inet "gw_inspect_allow" "output_${tenant}" \
    oifname "$egress_if" ip daddr "$dst_ip" accept 2>/dev/null || true
  nft add rule inet "gw_inspect_allow" "output_${tenant}" \
    ip daddr "$dst_ip" log prefix "inspect-drop-${tenant}: " drop 2>/dev/null || true

  log "Inspection nftables guardrail applied: tenant=$tenant egress=$egress_if dst=$dst_ip"
}

# ── Commands ─────────────────────────────────────────────────────
cmd_install() {
  need tc
  need ip
  need nft
  check_component_versions
  mkdir -p "$CONF_DIR"
  log "gw-inspection v${VERSION} installed — component version check passed"
}

cmd_apply() {
  local tenant="${1:-}"
  [[ -n "$tenant" ]] || die "Usage: gw-inspectctl.sh apply <tenant>"
  check_component_versions
  load_tenant_conf "$tenant"

  [[ "${INSPECTION_EXPORT_MODE:-}" == "tap" ]] \
    || die "INSPECTION_EXPORT_MODE=tap not set for $tenant"

  local tap_type="${INSPECTION_TAP_TYPE:-}"
  local dst_ip="${INSPECTION_TAP_DST_IP:-}"
  local key="${INSPECTION_TAP_KEY:-}"
  local egress_if="${INSPECTION_TAP_EGRESS_IF:-}"
  local rate_bps="${INSPECTION_TAP_RATE_BPS:-0}"

  [[ -n "$tap_type"  ]] || die "INSPECTION_TAP_TYPE not set (erspan|vxlan)"
  [[ -n "$dst_ip"    ]] || die "INSPECTION_TAP_DST_IP not set"
  [[ -n "$key"       ]] || die "INSPECTION_TAP_KEY not set"
  [[ -n "$egress_if" ]] || die "INSPECTION_TAP_EGRESS_IF not set"

  ip link show "$egress_if" >/dev/null 2>&1 \
    || die "INSPECTION_TAP_EGRESS_IF=$egress_if does not exist on this node"

  # Always remove before re-applying (idempotent)
  tap_remove_idempotent "$tenant"

  case "$tap_type" in
    erspan) apply_erspan_tap "$tenant" "$dst_ip" "$key" "$egress_if" "$rate_bps" ;;
    vxlan)  apply_vxlan_tap  "$tenant" "$dst_ip" "$key" "$egress_if" "$rate_bps" ;;
    *) die "Unknown INSPECTION_TAP_TYPE: $tap_type (must be erspan or vxlan)" ;;
  esac

  apply_nft_guardrail "$tenant" "$egress_if" "$dst_ip" "$tap_type"

  log "Inspection apply complete: tenant=$tenant type=$tap_type"
}

cmd_status() {
  local tenant="${1:-}"
  [[ -n "$tenant" ]] || die "Usage: gw-inspectctl.sh status <tenant>"
  echo "=== gw-inspection status: $tenant ==="
  echo "Version: $VERSION"
  echo ""
  echo "Mirror interface:"
  ip link show "mirror-${tenant}" 2>/dev/null || echo "  (not active)"
  echo ""
  echo "TC filters on ${DECRYPT_IFACE:-dec-${tenant}}:"
  tc filter show dev "${DECRYPT_IFACE:-dec-${tenant}}" parent ffff: 2>/dev/null || echo "  (none)"
  echo ""
  echo "nftables guardrail:"
  nft list table inet gw_inspect_allow 2>/dev/null | grep "$tenant" || echo "  (not applied)"
}

cmd_remove() {
  local tenant="${1:-}"
  [[ -n "$tenant" ]] || die "Usage: gw-inspectctl.sh remove <tenant>"
  load_tenant_conf "$tenant" 2>/dev/null || true
  tap_remove_idempotent "$tenant"

  # Remove nftables guardrail chain for this tenant
  nft delete chain inet gw_inspect_allow "output_${tenant}" 2>/dev/null || true

  log "Inspection removed: tenant=$tenant"
}

cmd_version() {
  echo "gw-inspectctl.sh version $VERSION (requires gwctl>=$MIN_GWCTL_VERSION gwreg>=$MIN_GWREG_VERSION)"
}

case "${1:-}" in
  install) cmd_install ;;
  apply)   cmd_apply   "${2:-}" ;;
  status)  cmd_status  "${2:-}" ;;
  remove)  cmd_remove  "${2:-}" ;;
  version) cmd_version ;;
  -h|--help|help|"")
    echo "gw-inspectctl.sh v${VERSION}"
    echo "Usage: gw-inspectctl.sh <install|apply|status|remove|version>"
    ;;
  *) die "Unknown command: ${1}" ;;
esac
