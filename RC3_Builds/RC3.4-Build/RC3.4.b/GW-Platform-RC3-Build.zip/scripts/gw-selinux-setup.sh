#!/bin/bash
# gw-selinux-setup.sh — Build and apply targeted SELinux enforcing policy.
# Must be run on a node that has been operating in permissive mode long enough
# to have accumulated AVC denials that represent normal operation.
#
# Usage:
#   gw-selinux-setup.sh audit          # Show AVC denials to review before applying
#   gw-selinux-setup.sh build          # Generate policy module from AVC log
#   gw-selinux-setup.sh apply          # Apply generated policy module
#   gw-selinux-setup.sh enforce        # Switch node to enforcing mode
#   gw-selinux-setup.sh permissive     # Switch back to permissive (rollback)
#   gw-selinux-setup.sh status         # Show current mode + module status
#   gw-selinux-setup.sh full-setup     # audit + build + apply + enforce in one pass
set -euo pipefail

# ── Portable compatibility (Linux + macOS) ──────────────────────
sha256_cmd() {
  if command -v sha256sum >/dev/null 2>&1; then sha256sum "$@"; else shasum -a 256 "$@"; fi
}
isotime() {
  python3 -c "from datetime import datetime,timezone; print(datetime.now(timezone.utc).astimezone().isoformat(timespec='seconds'))"
}
# ─────────────────────────────────────────────────────────────────

MODULE_NAME="gw_platform"
MODULE_DIR="/etc/gateway/selinux"
POLICY_TE="${MODULE_DIR}/${MODULE_NAME}.te"
POLICY_PP="${MODULE_DIR}/${MODULE_NAME}.pp"
AUDIT_LOG="/var/log/audit/audit.log"
LOG=/var/log/gw-selinux-setup.log

die()  { echo "ERROR: $*" >&2; exit 1; }
log()  { echo "[$(isotime)] $*" | tee -a "$LOG"; }
warn() { echo "WARN:  $*" | tee -a "$LOG"; }
need() { command -v "$1" >/dev/null 2>&1 || die "Missing: $1"; }

require_root() { [[ "${EUID:-$(id -u)}" -eq 0 ]] || die "Run as root"; }

cmd_audit() {
  need audit2allow
  echo "=== AVC Denials (last 500 entries) ==="
  echo "Review these carefully before building policy."
  echo "Remove any denials that represent illegitimate access."
  echo ""
  ausearch -m avc -ts recent 2>/dev/null \
    | audit2allow 2>/dev/null \
    | head -100 \
    || grep 'avc:.*denied' "$AUDIT_LOG" 2>/dev/null | tail -50 \
    || echo "No AVC denials found. Either audit logging is off or permissive mode hasn't run yet."
  echo ""
  echo "Total AVC entries: $(grep -c 'avc:.*denied' "$AUDIT_LOG" 2>/dev/null || echo 0)"
}

cmd_build() {
  require_root
  need audit2allow
  need checkmodule
  need semodule_package

  [[ -f "$AUDIT_LOG" ]] || die "Audit log not found: $AUDIT_LOG. Is auditd running?"

  local avc_count
  avc_count="$(grep -c 'avc:.*denied' "$AUDIT_LOG" 2>/dev/null || echo 0)"
  [[ "$avc_count" -gt 0 ]] || {
    warn "No AVC denials found in $AUDIT_LOG — node may not have run in permissive mode yet"
    warn "Run the node in permissive mode through a full operational cycle before building policy"
    exit 1
  }

  log "Building policy from $avc_count AVC denial(s)..."
  mkdir -p "$MODULE_DIR"

  # Generate type enforcement file from AVC log
  ausearch -m avc -ts boot 2>/dev/null \
    | audit2allow -m "$MODULE_NAME" > "$POLICY_TE" \
    || grep 'avc:.*denied' "$AUDIT_LOG" \
       | audit2allow -m "$MODULE_NAME" > "$POLICY_TE"

  # Compile to binary module
  checkmodule -M -m -o "${MODULE_DIR}/${MODULE_NAME}.mod" "$POLICY_TE"
  semodule_package -o "$POLICY_PP" -m "${MODULE_DIR}/${MODULE_NAME}.mod"

  log "Policy built: $POLICY_PP (from $avc_count AVC entries)"
  echo ""
  echo "Policy written to: $POLICY_PP"
  echo "Review the type enforcement rules before applying:"
  echo "  cat $POLICY_TE"
}

cmd_apply() {
  require_root
  need semodule
  [[ -f "$POLICY_PP" ]] || die "Policy module not found: $POLICY_PP — run 'build' first"

  log "Applying SELinux policy module: $MODULE_NAME"
  semodule -i "$POLICY_PP"
  log "Policy module applied: $MODULE_NAME"

  # Restore file contexts for GW platform paths
  local paths=(
    /opt/gw-registry
    /opt/gw-admin-portal
    /opt/gw-builder-v1.1.3
    /opt/gw-perfmon
    /etc/gateway
    /var/lib/gw-admin-portal
    /opt/backups/gwreg
  )
  for p in "${paths[@]}"; do
    [[ -d "$p" ]] && restorecon -Rv "$p" 2>/dev/null && log "Restored context: $p" || true
  done
}

cmd_enforce() {
  require_root

  # Verify module is loaded before switching
  semodule -l 2>/dev/null | grep -q "$MODULE_NAME" \
    || { warn "Policy module $MODULE_NAME not loaded — switching to enforcing without custom policy"; }

  setenforce 1
  sed -i 's/^SELINUX=.*/SELINUX=enforcing/' /etc/selinux/config

  local mode; mode="$(getenforce)"
  log "SELinux mode: $mode"
  [[ "$mode" == "Enforcing" ]] || die "setenforce succeeded but getenforce reports: $mode"
  echo "SELinux is now ENFORCING."
  echo "Monitor denials: ausearch -m avc -ts recent | audit2allow"
}

cmd_permissive() {
  require_root
  setenforce 0
  sed -i 's/^SELINUX=.*/SELINUX=permissive/' /etc/selinux/config
  log "SELinux set to permissive"
  warn "Node is now in permissive mode. Re-run 'enforce' when ready."
}

cmd_status() {
  echo "=== SELinux Status ==="
  getenforce 2>/dev/null || echo "unknown"
  echo ""
  echo "Config (/etc/selinux/config):"
  grep '^SELINUX=' /etc/selinux/config 2>/dev/null || echo "  not found"
  echo ""
  echo "Policy module ($MODULE_NAME):"
  semodule -l 2>/dev/null | grep "$MODULE_NAME" || echo "  not loaded"
  echo ""
  echo "Policy file: $([[ -f "$POLICY_PP" ]] && echo "$POLICY_PP (present)" || echo "not built yet")"
  echo ""
  echo "Recent AVC denials (last 10):"
  ausearch -m avc -ts recent 2>/dev/null | tail -10 || \
    grep 'avc:.*denied' "$AUDIT_LOG" 2>/dev/null | tail -10 || echo "  none"
}

cmd_full_setup() {
  require_root
  log "Full SELinux setup: audit -> build -> apply -> enforce"
  echo "=== Step 1: Current AVC denials ==="
  cmd_audit
  echo ""
  read -r -p "Proceed with building policy from these denials? [yes/N] " confirm
  [[ "$confirm" == "yes" ]] || { echo "Aborted."; exit 0; }
  cmd_build
  echo ""
  echo "=== Policy rules generated ==="
  cat "$POLICY_TE"
  echo ""
  read -r -p "Apply this policy and switch to enforcing mode? [yes/N] " confirm2
  [[ "$confirm2" == "yes" ]] || { echo "Aborted."; exit 0; }
  cmd_apply
  cmd_enforce
  log "Full SELinux setup complete"
}

case "${1:-}" in
  audit)       cmd_audit ;;
  build)       cmd_build ;;
  apply)       cmd_apply ;;
  enforce)     cmd_enforce ;;
  permissive)  cmd_permissive ;;
  status)      cmd_status ;;
  full-setup)  cmd_full_setup ;;
  -h|--help|help|"")
    echo "gw-selinux-setup.sh — Targeted SELinux enforcing policy"
    echo "Usage: gw-selinux-setup.sh <audit|build|apply|enforce|permissive|status|full-setup>"
    ;;
  *) die "Unknown command: ${1}" ;;
esac
