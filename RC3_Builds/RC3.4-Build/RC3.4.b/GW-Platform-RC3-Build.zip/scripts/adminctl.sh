#!/usr/bin/env bash
# adminctl.sh — Admin portal lifecycle management (RC3)
set -euo pipefail

VERSION="v0.2.2-RC3"
CONF="${CONF:-/etc/gw-admin-portal/admin-portal.conf}"
KNOWN_HOSTS=/etc/ssh/ssh_known_hosts
SELF_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(cd "${SELF_DIR}/.." && pwd)"
LIB_DIR="${ROOT_DIR}/lib"

die()  { echo "ERROR: $*" >&2; exit 1; }
log()  { echo "[gw-admin-portal] $*"; }
need() { command -v "$1" >/dev/null 2>&1 || die "Missing dependency: $1"; }

# shellcheck disable=SC1090
source "${LIB_DIR}/preflight.sh"

load_conf() {
  [[ -f "$CONF" ]] || die "Config not found: $CONF"
  # shellcheck disable=SC1090
  source "$CONF"
  : "${INSTALL_PREFIX:=/opt/gw-admin-portal}"
  MGMT_VLAN_IF="${MGMT_TRUNK_IF}.${MGMT_VLAN_ID}"
  NFS_VLAN_IF="${MGMT_TRUNK_IF}.${NFS_VLAN_ID}"
}

usage() {
  cat <<EOF
adminctl.sh ${VERSION}

Usage:
  adminctl.sh install
  adminctl.sh preflight
  adminctl.sh configure-network
  adminctl.sh configure-nfs
  adminctl.sh apply-firewall
  adminctl.sh enroll-gw-keys        # Enroll GW node host keys into $KNOWN_HOSTS
  adminctl.sh enable-key-rotation
  adminctl.sh health
EOF
}

enable_epel() {
  if [[ "${ENABLE_EPEL:-no}" == "yes" ]]; then
    rpm -q epel-release >/dev/null 2>&1 || dnf install -y epel-release
  fi
}

preflight_cmd() {
  load_conf
  check_root
  check_cmd ip
  check_vlan_support
  check_nm_running
  warn_trunk_assumption "${MGMT_TRUNK_IF}"
  log "Preflight OK"
}

install_wrappers() {
  load_conf
  group="${ADMIN_WRAPPER_GROUP:-gwportal}"
  getent group "$group" >/dev/null || groupadd "$group"
  log "Group ready: $group"

  install -d "${INSTALL_PREFIX}/bin"
  install -m 0755 "${ROOT_DIR}/bin/connect"             "${INSTALL_PREFIX}/bin/connect"
  install -m 0755 "${ROOT_DIR}/bin/gateway-exec"        "${INSTALL_PREFIX}/bin/gateway-exec"
  install -m 0755 "${ROOT_DIR}/bin/gw-sshkey-rotate.sh" "${INSTALL_PREFIX}/bin/gw-sshkey-rotate.sh"

  tmp="/tmp/gw-admin-portal-wrappers.$$"
  sed "s/%gwportal/%${group}/g" "${ROOT_DIR}/templates/sudoers/gw-admin-portal-wrappers" > "$tmp"
  install -m 0440 "$tmp" /etc/sudoers.d/gw-admin-portal-wrappers
  rm -f "$tmp"
}

install_cmd() {
  load_conf
  check_root
  enable_epel
  dnf install -y nftables NetworkManager openssh-clients openssh-server \
    rsyslog audit nfs-utils rpcbind jq curl perl coreutils python3

  # SELinux: permissive for RC3 (enforcing applied via gw-selinux-setup.sh)
  setenforce 0 2>/dev/null || true
  if [[ -f /etc/selinux/config ]]; then
    sed -i 's/^SELINUX=.*/SELINUX=disabled/' /etc/selinux/config || true
    log "SELinux disabled"
  fi

  systemctl enable --now NetworkManager nftables rsyslog auditd rpcbind >/dev/null 2>&1 || true

  if [[ "${DISABLE_FIREWALLD:-no}" == "yes" ]]; then
    systemctl disable --now firewalld 2>/dev/null || true
  fi

  preflight_cmd
  install_wrappers
  log "Install complete"
}

configure_network_cmd() {
  load_conf
  check_root
  preflight_cmd
  need nmcli

  con_access="gw-mgmt-access-${MGMT_ACCESS_IF}"
  nmcli -t -f NAME con show | grep -qx "$con_access" \
    || nmcli con add type ethernet ifname "$MGMT_ACCESS_IF" con-name "$con_access"
  nmcli con mod "$con_access" \
    ipv4.addresses "$MGMT_ACCESS_IP" ipv4.gateway "$MGMT_ACCESS_GW" \
    ipv4.method manual ipv6.method ignore

  con_vlan_m="gw-mgmt-vlan${MGMT_VLAN_ID}"
  nmcli -t -f NAME con show | grep -qx "$con_vlan_m" \
    || nmcli con add type vlan ifname "$MGMT_VLAN_IF" con-name "$con_vlan_m" \
         dev "$MGMT_TRUNK_IF" id "$MGMT_VLAN_ID"
  nmcli con mod "$con_vlan_m" ipv4.addresses "$MGMT_VLAN_IP" ipv4.method manual ipv6.method ignore

  con_vlan_n="gw-nfs-vlan${NFS_VLAN_ID}"
  nmcli -t -f NAME con show | grep -qx "$con_vlan_n" \
    || nmcli con add type vlan ifname "$NFS_VLAN_IF" con-name "$con_vlan_n" \
         dev "$MGMT_TRUNK_IF" id "$NFS_VLAN_ID"
  nmcli con mod "$con_vlan_n" ipv4.addresses "$NFS_VLAN_IP" ipv4.method manual ipv6.method ignore

  nmcli con up "$con_access"  || true
  nmcli con up "$con_vlan_m"  || true
  nmcli con up "$con_vlan_n"  || true
  log "Networking configured"
}

configure_nfs_cmd() {
  load_conf
  check_root
  install -m 0644 "${ROOT_DIR}/templates/nfs/nfs-sysconfig.conf" /etc/sysconfig/nfs
  if [[ -f /etc/nfs.conf ]]; then
    grep -q '^\[mountd\]' /etc/nfs.conf \
      || cat "${ROOT_DIR}/templates/nfs/nfs.conf.example" >> /etc/nfs.conf
  else
    install -m 0644 "${ROOT_DIR}/templates/nfs/nfs.conf.example" /etc/nfs.conf
  fi
  export_line="${EXPORT_ROOT}/${EXPORT_GLOB} ${NFS_CLIENT_CIDRS}(rw,sync,no_subtree_check,root_squash)"
  grep -qF "${EXPORT_ROOT}/${EXPORT_GLOB}" /etc/exports 2>/dev/null \
    || echo "$export_line" >> /etc/exports
  systemctl enable --now rpcbind nfs-server
  exportfs -rav
  log "NFS configured"
}

apply_firewall_cmd() {
  load_conf
  check_root
  need nft

  NFT_TEMPLATE="${ROOT_DIR}/templates/nftables/gw-admin-portal.nft"
  [[ -f "$NFT_TEMPLATE" ]] || die "nftables template not found: $NFT_TEMPLATE"

  tmp="/tmp/gw-admin-portal.nft.$$"
  cp "$NFT_TEMPLATE" "$tmp"

  # Substitute all placeholders
  sed -i \
    -e "s|<MGMT_ACCESS_IF>|${MGMT_ACCESS_IF}|g" \
    -e "s|<MGMT_VLAN_IF>|${MGMT_VLAN_IF}|g" \
    -e "s|<NFS_VLAN_IF>|${NFS_VLAN_IF}|g" \
    -e "s|<PORTAL_HTTPS_PORT>|${PORTAL_HTTPS_PORT}|g" \
    -e "s|<SSH_PORT>|${SSH_PORT}|g" \
    -e "s|<NFS_MOUNTD_PORT>|${NFS_MOUNTD_PORT}|g" \
    -e "s|<NFS_STATD_PORT>|${NFS_STATD_PORT}|g" \
    -e "s|<NFS_LOCKD_TCPPORT>|${NFS_LOCKD_TCPPORT}|g" \
    -e "s|<NFS_LOCKD_UDPPORT>|${NFS_LOCKD_UDPPORT}|g" \
    -e "s|<NFS_RQUOTAD_PORT>|${NFS_RQUOTAD_PORT}|g" \
    "$tmp"

  # Verify no placeholders remain
  if grep -q '<[A-Z_]*>' "$tmp"; then
    rm -f "$tmp"
    die "Unreplaced placeholders in nftables template. Check admin-portal.conf."
  fi

  # Load table (table-scoped — does not flush other tables)
  nft -f "$tmp"
  rm -f "$tmp"

  # Populate IP sets
  nft add element inet gw_admin admin_src4 { ${ADMIN_CIDRS//,/ , } }  2>/dev/null || true
  nft add element inet gw_admin gw_mgmt4   { ${GW_MGMT_CIDRS//,/ , } } 2>/dev/null || true
  nft add element inet gw_admin nfs_cli4   { ${NFS_CLIENT_CIDRS//,/ , } } 2>/dev/null || true

  log "Firewall applied (table-scoped; other tables preserved)"
}

enroll_gw_keys_cmd() {
  load_conf
  check_root
  need ssh-keyscan

  mkdir -p "$(dirname "$KNOWN_HOSTS")"
  touch "$KNOWN_HOSTS"
  chmod 644 "$KNOWN_HOSTS"

  enrolled=0
  while IFS= read -r line; do
    gw_name="$(echo "$line" | awk '{print $2}')"
    [[ "$gw_name" =~ ^gw- ]] || continue

    log "Scanning host keys for $gw_name..."
    new_keys="$(ssh-keyscan -T 5 "$gw_name" 2>/dev/null || true)"
    if [[ -z "$new_keys" ]]; then
      log "[WARN] Could not reach $gw_name — skipping. Ensure node is up and SSH is listening."
      continue
    fi

    # Remove old entry for this host, add fresh
    tmp="$(mktemp)"
    grep -v "^${gw_name}[[:space:]]" "$KNOWN_HOSTS" > "$tmp" || true
    echo "$new_keys" >> "$tmp"
    mv "$tmp" "$KNOWN_HOSTS"
    log "[OK] Enrolled host keys for $gw_name"
    enrolled=$(( enrolled + 1 ))
  done < <(grep -E '^[^#]+[[:space:]]+gw-' /etc/hosts 2>/dev/null || true)

  log "Enrollment complete: $enrolled node(s) enrolled in $KNOWN_HOSTS"
  [[ "$enrolled" -gt 0 ]] || log "WARN: No GW nodes enrolled. Add 'gw-*' entries to /etc/hosts first."
}

enable_key_rotation_cmd() {
  load_conf
  check_root
  install -d /etc/systemd/system
  install -m 0644 "${ROOT_DIR}/systemd/gw-sshkey-rotate.service" /etc/systemd/system/
  install -m 0644 "${ROOT_DIR}/systemd/gw-sshkey-rotate.timer"   /etc/systemd/system/
  systemctl daemon-reload
  systemctl enable --now gw-sshkey-rotate.timer
  log "Timer enabled. Run initial rotation now:"
  log "  ${INSTALL_PREFIX}/bin/gw-sshkey-rotate.sh"
}

health_cmd() {
  load_conf
  fail=0

  systemctl is-active nftables >/dev/null || { log "FAIL: nftables not active"; fail=1; }
  nft list table inet gw_admin >/dev/null 2>&1 || { log "FAIL: gw_admin table missing"; fail=1; }
  [[ -x "${INSTALL_PREFIX}/bin/connect" ]]      || { log "FAIL: connect missing";      fail=1; }
  [[ -x "${INSTALL_PREFIX}/bin/gateway-exec" ]] || { log "FAIL: gateway-exec missing"; fail=1; }

  key="${SSH_KEY_DIR:-/var/lib/gw-admin-portal/sshkeys}/${SSH_KEY_NAME:-gwportal_ed25519}"
  [[ -f "$key" ]] || { log "FAIL: SSH key missing ($key)"; fail=1; }

  [[ -f "$KNOWN_HOSTS" ]] || log "WARN: $KNOWN_HOSTS missing — run enroll-gw-keys"

  [[ "$fail" -eq 0 ]] && log "Health: OK" || { log "Health: DEGRADED"; exit 1; }
}

case "${1:-}" in
  install)             install_cmd ;;
  preflight)           preflight_cmd ;;
  configure-network)   configure_network_cmd ;;
  configure-nfs)       configure_nfs_cmd ;;
  apply-firewall)      apply_firewall_cmd ;;
  enroll-gw-keys)      enroll_gw_keys_cmd ;;
  enable-key-rotation) enable_key_rotation_cmd ;;
  health)              health_cmd ;;
  -h|--help|help|"")  usage ;;
  *) die "Unknown command: ${1}" ;;
esac
