#!/bin/bash
# gw-pki-backup.sh v RC3.3 — Encrypted backup and restore of GW Platform CA private keys.
#
# The Admin Portal holds ALL CA private keys:
#   /etc/gateway/pki/root/private/             Root CA private key
#   /etc/gateway/pki/*/intermediate/private/   Per-tenant intermediate CA keys
#
# These are NOT in the seed by design. Without them, the platform cannot issue
# or renew certificates after a portal rebuild. This script writes GPG AES-256
# encrypted archives to a USB drive (primary) and optionally a local path.
#
# USB is the default and preferred destination — air-gapped, physically controlled.
#
# Usage:
#   gw-pki-backup.sh usb-detect              # detect and show connected USB drives
#   gw-pki-backup.sh backup                  # backup all CAs to USB
#   gw-pki-backup.sh backup-root             # backup root CA only to USB
#   gw-pki-backup.sh backup-tenant <tenant>  # backup one tenant CA to USB
#   gw-pki-backup.sh restore <file>          # restore from encrypted archive
#   gw-pki-backup.sh verify  <file>          # verify archive integrity without restoring
#   gw-pki-backup.sh list                    # list backups on USB (and local fallback)
#   gw-pki-backup.sh status                  # show key presence and last backup state
#
# Encryption: GPG symmetric AES-256 (no key infrastructure required)
# Root CA and tenant CAs are written to SEPARATE subdirectories on USB.

VERSION="RC3.3"
set -euo pipefail

# ── Portable compatibility ────────────────────────────────────────
sha256_cmd() {
  if command -v sha256sum >/dev/null 2>&1; then sha256sum "$@"; else shasum -a 256 "$@"; fi
}
isotime() {
  python3 -c "from datetime import datetime,timezone; \
print(datetime.now(timezone.utc).astimezone().isoformat(timespec='seconds'))"
}
# ─────────────────────────────────────────────────────────────────

# ── Configuration ─────────────────────────────────────────────────
PKI_BASE="${PKI_BASE:-/etc/gateway/pki}"

# USB mount point — operator mounts USB before running this script
USB_MOUNT="${USB_MOUNT:-/mnt/pki-backup-usb}"

# Subdirectories on USB — root CA kept separate from tenant CAs
USB_ROOT_DIR="${USB_MOUNT}/root-ca"
USB_TENANT_DIR="${USB_MOUNT}/tenant-ca"

# Optional local fallback copy (in addition to USB)
LOCAL_COPY_ENABLED="${LOCAL_COPY_ENABLED:-no}"
LOCAL_ROOT_DIR="${LOCAL_ROOT_DIR:-/opt/backups/pki-root}"
LOCAL_TENANT_DIR="${LOCAL_TENANT_DIR:-/opt/backups/pki-tenants}"

LOG=/var/log/gw-pki-backup.log

# ─────────────────────────────────────────────────────────────────
die()  { echo "ERROR: $*" >&2; log "ERROR: $*" 2>/dev/null || true; exit 1; }
log()  { echo "[$(isotime)] $*" | tee -a "$LOG"; }
warn() { echo "WARN:  $*" | tee -a "$LOG"; }

require_root() { [[ "${EUID:-$(id -u)}" -eq 0 ]] || die "Run as root"; }
need() { command -v "$1" >/dev/null 2>&1 || die "Missing dependency: $1 — install it first"; }

# ── USB helpers ───────────────────────────────────────────────────
detect_usb() {
  echo "=== Connected USB storage devices ==="
  if command -v lsblk >/dev/null 2>&1; then
    lsblk -o NAME,SIZE,TYPE,MOUNTPOINT,LABEL,VENDOR,MODEL \
      | grep -E 'NAME|disk|part' | grep -v 'loop\|sr0' || true
  fi
  echo ""
  echo "=== Currently mounted USB candidates ==="
  findmnt -t vfat,exfat,ext4,ext3,ntfs --output TARGET,SOURCE,SIZE,LABEL 2>/dev/null \
    | grep -v 'boot\|efi\|TARGET' || echo "  (none found via findmnt)"
  echo ""
  echo "To mount a USB drive:"
  echo "  lsblk                          # find device (e.g. /dev/sdb1)"
  echo "  mount /dev/sdb1 $USB_MOUNT     # mount it"
  echo "  gw-pki-backup.sh backup        # then run backup"
}

check_usb() {
  # Confirm USB_MOUNT is mounted and has enough free space
  mountpoint -q "$USB_MOUNT" 2>/dev/null || \
    die "USB not mounted at $USB_MOUNT — mount it first, or set USB_MOUNT=<path>"

  local free_kb; free_kb="$(df -k "$USB_MOUNT" | awk 'NR==2{print $4}')"
  [[ "$free_kb" -ge 102400 ]] || \
    warn "Less than 100MB free on USB ($((free_kb / 1024))MB) — verify this is enough"

  log "USB confirmed at $USB_MOUNT ($(df -h "$USB_MOUNT" | awk 'NR==2{print $4}') free)"
}

# ── Passphrase handling ───────────────────────────────────────────
get_passphrase() {
  local prompt="${1:-PKI backup passphrase}"
  local pass pass2
  read -r -s -p "${prompt}: " pass; echo >&2
  read -r -s -p "Confirm passphrase: "  pass2; echo >&2
  [[ "$pass" == "$pass2" ]] || die "Passphrases do not match"
  [[ "${#pass}" -ge 16 ]]   || die "Passphrase must be at least 16 characters"
  printf '%s' "$pass"
}

get_passphrase_once() {
  local prompt="${1:-Passphrase}"
  local pass
  read -r -s -p "${prompt}: " pass; echo >&2
  printf '%s' "$pass"
}

# ── Encryption / decryption ───────────────────────────────────────
encrypt_to_usb() {
  local src_dir="$1"
  local usb_dest_dir="$2"
  local passphrase="$3"
  local label="$4"

  mkdir -p "$usb_dest_dir"
  chmod 700 "$usb_dest_dir"

  local ts; ts="$(date +%Y%m%d-%H%M%S)"
  local out="${usb_dest_dir}/${label}-${ts}.tar.gz.gpg"
  local tmp_tar; tmp_tar="$(mktemp /tmp/gw-pki-XXXXXX.tar.gz)"

  # Archive source directory
  tar -czf "$tmp_tar" -C "$(dirname "$src_dir")" "$(basename "$src_dir")"

  # Checksum plaintext archive before encryption
  local checksum; checksum="$(sha256_cmd "$tmp_tar" | awk '{print $1}')"

  # GPG symmetric AES-256 encrypt directly to USB
  gpg --batch --yes \
      --cipher-algo AES256 \
      --s2k-mode 3 \
      --s2k-digest-algo SHA512 \
      --s2k-count 65536 \
      --compress-algo none \
      --passphrase-fd 3 \
      --symmetric \
      --output "$out" \
      "$tmp_tar" \
      3<<<"$passphrase"

  # Write checksum file to USB alongside archive
  echo "$checksum  $(basename "$out")" > "${out}.sha256"

  # Sync to ensure data is written to USB before unmounting
  sync

  rm -f "$tmp_tar"
  log "Written to USB: $out"

  # Optional local copy
  if [[ "$LOCAL_COPY_ENABLED" == "yes" ]]; then
    local local_dest
    if [[ "$label" == root-ca ]]; then
      local_dest="$LOCAL_ROOT_DIR"
    else
      local_dest="${LOCAL_TENANT_DIR}/${label#tenant-}"
    fi
    mkdir -p "$local_dest"
    chmod 700 "$local_dest"
    cp "$out" "${out}.sha256" "$local_dest/"
    log "Local copy written: $local_dest"
  fi

  echo "$out"
}

decrypt_archive() {
  local in_file="$1" out_dir="$2" passphrase="$3"
  local tmp_tar; tmp_tar="$(mktemp /tmp/gw-pki-XXXXXX.tar.gz)"

  gpg --batch --yes \
      --passphrase-fd 3 \
      --decrypt \
      --output "$tmp_tar" \
      "$in_file" \
      3<<<"$passphrase" \
      || { rm -f "$tmp_tar"; die "Decryption failed — wrong passphrase or corrupt archive"; }

  # Verify checksum if present
  local checksum_file="${in_file}.sha256"
  if [[ -f "$checksum_file" ]]; then
    local expected; expected="$(awk '{print $1}' "$checksum_file")"
    local actual;   actual="$(sha256_cmd "$tmp_tar" | awk '{print $1}')"
    if [[ "$expected" != "$actual" ]]; then
      rm -f "$tmp_tar"
      die "CHECKSUM MISMATCH — archive corrupt or tampered.\n  Expected: $expected\n  Got:      $actual"
    fi
    log "Checksum verified: $actual"
  else
    warn "No .sha256 file alongside archive — skipping integrity check"
  fi

  mkdir -p "$out_dir"
  tar -xzf "$tmp_tar" -C "$out_dir"
  rm -f "$tmp_tar"
}

# ── Commands ─────────────────────────────────────────────────────
cmd_usb_detect() {
  detect_usb
}

cmd_backup_root() {
  require_root; need gpg
  check_usb

  local root_private="${PKI_BASE}/root/private"
  [[ -d "$root_private" ]] || die "Root CA private directory not found: $root_private"
  [[ -n "$(ls -A "$root_private" 2>/dev/null)" ]] || die "Root CA private directory is empty"

  echo "" >&2
  echo "=== ROOT CA BACKUP → USB ===" >&2
  echo "Source:      ${PKI_BASE}/root" >&2
  echo "Destination: ${USB_ROOT_DIR}/" >&2
  echo "" >&2
  echo "IMPORTANT: This passphrase protects the Root CA private key." >&2
  echo "Write it down and store it SEPARATE from this USB drive." >&2
  echo "Loss of passphrase = unrecoverable backup." >&2
  echo "" >&2

  local pass; pass="$(get_passphrase "Root CA passphrase")"
  local out; out="$(encrypt_to_usb "${PKI_BASE}/root" "$USB_ROOT_DIR" "$pass" "root-ca")"

  log "Root CA backup complete → USB"
  echo ""
  echo "  Backup file: $out"
  echo "  Checksum:    ${out}.sha256"
  echo ""
  echo "  USB is safe to unmount now (sync has been called)."
  echo "  Store USB in a physically secure location."
}

cmd_backup_tenant() {
  local tenant="${1:-}"
  [[ -n "$tenant" ]] || die "Usage: gw-pki-backup.sh backup-tenant <tenant>"
  require_root; need gpg
  check_usb

  local tenant_private="${PKI_BASE}/${tenant}/intermediate/private"
  [[ -d "$tenant_private" ]] || die "Tenant intermediate CA private directory not found: $tenant_private"
  [[ -n "$(ls -A "$tenant_private" 2>/dev/null)" ]] || die "Tenant CA private directory is empty"

  echo "" >&2
  echo "=== TENANT CA BACKUP → USB: $tenant ===" >&2
  echo "Source:      ${PKI_BASE}/${tenant}/intermediate" >&2
  echo "Destination: ${USB_TENANT_DIR}/${tenant}/" >&2
  echo "" >&2

  local pass; pass="$(get_passphrase "Tenant CA passphrase [$tenant]")"
  local out; out="$(encrypt_to_usb \
    "${PKI_BASE}/${tenant}/intermediate" \
    "${USB_TENANT_DIR}/${tenant}" \
    "$pass" \
    "tenant-${tenant}")"

  log "Tenant CA backup complete: tenant=$tenant → USB"
  echo ""
  echo "  Backup file: $out"
  echo "  Checksum:    ${out}.sha256"
}

cmd_backup_all() {
  require_root; need gpg
  check_usb

  log "Starting full PKI backup to USB"
  echo "" >&2
  echo "=== FULL PKI BACKUP → USB ===" >&2
  echo "USB: $USB_MOUNT" >&2
  echo "" >&2
  echo "Root CA and all tenant intermediate CAs will be backed up." >&2
  echo "You will be prompted for a passphrase for each." >&2
  echo "Each CA can have a different passphrase — or use the same one." >&2
  echo "" >&2

  cmd_backup_root

  local count=0
  for tenant_dir in "${PKI_BASE}"/*/; do
    local tenant; tenant="$(basename "$tenant_dir")"
    [[ "$tenant" == "root" ]] && continue
    local priv="${tenant_dir}intermediate/private"
    if [[ -d "$priv" ]] && [[ -n "$(ls -A "$priv" 2>/dev/null)" ]]; then
      echo "" >&2
      cmd_backup_tenant "$tenant"
      count=$(( count + 1 ))
    fi
  done

  log "Full PKI backup complete: root + $count tenant CA(s) → USB"
  echo ""
  echo "Full backup complete."
  echo "  Root CA:    ${USB_ROOT_DIR}/"
  echo "  Tenant CAs: ${USB_TENANT_DIR}/"
  echo ""
  echo "USB is safe to unmount:  umount $USB_MOUNT"
  echo "Store USB in a physically secure, off-site location."
}

cmd_restore() {
  local in_file="${1:-}"
  [[ -n "$in_file" ]] || die "Usage: gw-pki-backup.sh restore <encrypted-file>"
  [[ -f "$in_file"  ]] || die "File not found: $in_file"
  require_root; need gpg

  echo "" >&2
  echo "=== PKI RESTORE ===" >&2
  echo "Source: $in_file" >&2
  echo "Target: $PKI_BASE" >&2
  echo "" >&2
  echo "WARNING: This extracts CA private keys onto this server." >&2
  echo "Existing files will NOT be overwritten automatically." >&2
  echo "" >&2
  read -r -p "Proceed? [yes/N] " confirm
  [[ "$confirm" == "yes" ]] || { echo "Aborted."; exit 0; }

  local pass; pass="$(get_passphrase_once "Restore passphrase")"
  local tmp_restore; tmp_restore="$(mktemp -d /tmp/gw-pki-restore-XXXXXX)"
  decrypt_archive "$in_file" "$tmp_restore" "$pass"

  echo "" >&2
  echo "Archive contents (preview):" >&2
  find "$tmp_restore" -type f | sort >&2
  echo "" >&2
  read -r -p "Copy these files into $PKI_BASE? [yes/N] " confirm2
  if [[ "$confirm2" == "yes" ]]; then
    cp -rn "$tmp_restore"/. "$PKI_BASE/"   # -n = no overwrite
    # Re-secure permissions
    find "$PKI_BASE" -name 'private' -type d        -exec chmod 700 {} \;
    find "$PKI_BASE" -name '*.key.pem'              -exec chmod 600 {} \;
    find "$PKI_BASE" -path '*/private/*.pem'        -exec chmod 600 {} \;
    rm -rf "$tmp_restore"
    log "PKI restore complete from: $in_file"
    echo ""
    echo "Restore complete. Run: gw-pki-backup.sh status"
  else
    echo "Aborted — files remain in $tmp_restore for manual review."
    exit 0
  fi
}

cmd_verify() {
  local in_file="${1:-}"
  [[ -n "$in_file" ]] || die "Usage: gw-pki-backup.sh verify <encrypted-file>"
  [[ -f "$in_file"  ]] || die "File not found: $in_file"
  need gpg

  echo "Verifying: $in_file" >&2
  local pass; pass="$(get_passphrase_once "Backup passphrase")"
  local tmp_tar; tmp_tar="$(mktemp /tmp/gw-pki-XXXXXX.tar.gz)"

  gpg --batch --yes \
      --passphrase-fd 3 \
      --decrypt \
      --output "$tmp_tar" \
      "$in_file" \
      3<<<"$pass" \
      || { rm -f "$tmp_tar"; die "Decryption failed — wrong passphrase or corrupt archive"; }

  local checksum_file="${in_file}.sha256"
  if [[ -f "$checksum_file" ]]; then
    local expected; expected="$(awk '{print $1}' "$checksum_file")"
    local actual;   actual="$(sha256_cmd "$tmp_tar" | awk '{print $1}')"
    if [[ "$expected" == "$actual" ]]; then
      echo "[OK] Checksum verified: $actual"
    else
      rm -f "$tmp_tar"
      die "CHECKSUM MISMATCH\n  Expected: $expected\n  Got:      $actual"
    fi
  else
    warn "No .sha256 file — skipping checksum verification"
  fi

  echo ""
  echo "Archive contents:"
  tar -tzf "$tmp_tar" | sort
  rm -f "$tmp_tar"
  echo ""
  echo "[OK] Archive is valid and decryptable."
}

cmd_list() {
  echo "=== Backups on USB ($USB_MOUNT) ==="
  if mountpoint -q "$USB_MOUNT" 2>/dev/null; then
    echo "Root CA:"
    find "${USB_ROOT_DIR}" -name '*.gpg' 2>/dev/null | sort | \
      while read -r f; do echo "  $(ls -lh "$f" | awk '{print $5, $6, $7, $8}')  $f"; done
    [[ -n "$(find "${USB_ROOT_DIR}" -name '*.gpg' 2>/dev/null)" ]] || echo "  (none)"
    echo ""
    echo "Tenant CAs:"
    find "${USB_TENANT_DIR}" -name '*.gpg' 2>/dev/null | sort | \
      while read -r f; do echo "  $(ls -lh "$f" | awk '{print $5, $6, $7, $8}')  $f"; done
    [[ -n "$(find "${USB_TENANT_DIR}" -name '*.gpg' 2>/dev/null)" ]] || echo "  (none)"
  else
    echo "  USB not mounted at $USB_MOUNT"
  fi

  if [[ "$LOCAL_COPY_ENABLED" == "yes" ]]; then
    echo ""
    echo "=== Local copies ==="
    find "$LOCAL_ROOT_DIR" "$LOCAL_TENANT_DIR" -name '*.gpg' 2>/dev/null | sort | \
      while read -r f; do echo "  $(ls -lh "$f" | awk '{print $5, $6, $7, $8}')  $f"; done || true
  fi
}

cmd_status() {
  echo "=== PKI Key Status ==="
  echo ""

  # Root CA
  echo "Root CA:"
  local root_private="${PKI_BASE}/root/private"
  if [[ -d "$root_private" ]] && [[ -n "$(ls -A "$root_private" 2>/dev/null)" ]]; then
    echo "  [PRESENT] $root_private"
  else
    echo "  [MISSING] $root_private — root CA not yet initialised"
  fi

  # Check for most recent backup — USB first, then local
  local latest=""
  mountpoint -q "$USB_MOUNT" 2>/dev/null && \
    latest="$(find "${USB_ROOT_DIR}" -name '*.gpg' 2>/dev/null | sort | tail -1 || true)"
  [[ -z "$latest" ]] && [[ "$LOCAL_COPY_ENABLED" == "yes" ]] && \
    latest="$(find "${LOCAL_ROOT_DIR}" -name '*.gpg' 2>/dev/null | sort | tail -1 || true)"

  if [[ -n "$latest" ]]; then
    echo "  Last backup: $latest"
  else
    echo "  Last backup: *** NONE — root CA has never been backed up ***"
  fi

  echo ""
  echo "Tenant CAs:"
  local found=false
  for tenant_dir in "${PKI_BASE}"/*/; do
    local tenant; tenant="$(basename "$tenant_dir")"
    [[ "$tenant" == "root" ]] && continue
    local priv="${tenant_dir}intermediate/private"
    found=true
    if [[ -d "$priv" ]] && [[ -n "$(ls -A "$priv" 2>/dev/null)" ]]; then
      echo "  [PRESENT] $tenant"
      local latest_t=""
      mountpoint -q "$USB_MOUNT" 2>/dev/null && \
        latest_t="$(find "${USB_TENANT_DIR}/${tenant}" -name '*.gpg' 2>/dev/null | sort | tail -1 || true)"
      [[ -z "$latest_t" ]] && [[ "$LOCAL_COPY_ENABLED" == "yes" ]] && \
        latest_t="$(find "${LOCAL_TENANT_DIR}/${tenant}" -name '*.gpg' 2>/dev/null | sort | tail -1 || true)"
      if [[ -n "$latest_t" ]]; then
        echo "            Last backup: $latest_t"
      else
        echo "            Last backup: *** NONE — never backed up ***"
      fi
    else
      echo "  [MISSING] $tenant — intermediate CA not yet initialised"
    fi
  done
  $found || echo "  (no tenant CAs found)"

  echo ""
  echo "USB mount: $USB_MOUNT"
  mountpoint -q "$USB_MOUNT" 2>/dev/null && echo "  [MOUNTED]" || echo "  [NOT MOUNTED]"
  echo "Local copy: $LOCAL_COPY_ENABLED"
}

# ── Dispatch ──────────────────────────────────────────────────────
case "${1:-}" in
  usb-detect)     cmd_usb_detect ;;
  backup)         cmd_backup_all ;;
  backup-root)    cmd_backup_root ;;
  backup-tenant)  cmd_backup_tenant "${2:-}" ;;
  restore)        cmd_restore "${2:-}" ;;
  verify)         cmd_verify  "${2:-}" ;;
  list)           cmd_list ;;
  status)         cmd_status ;;
  -h|--help|help|"")
    echo "gw-pki-backup.sh $VERSION — Encrypted PKI CA key backup and restore (USB)"
    echo ""
    echo "Usage:"
    echo "  gw-pki-backup.sh usb-detect              Detect connected USB drives"
    echo "  gw-pki-backup.sh backup                  Backup root + all tenant CAs to USB"
    echo "  gw-pki-backup.sh backup-root             Backup root CA only to USB"
    echo "  gw-pki-backup.sh backup-tenant <tenant>  Backup one tenant CA to USB"
    echo "  gw-pki-backup.sh restore <file>          Restore from encrypted archive"
    echo "  gw-pki-backup.sh verify  <file>          Verify archive integrity"
    echo "  gw-pki-backup.sh list                    List backups on USB"
    echo "  gw-pki-backup.sh status                  Show key and backup state"
    echo ""
    echo "Workflow:"
    echo "  1. Insert USB drive"
    echo "  2. mount /dev/sdX1 /mnt/pki-backup-usb"
    echo "  3. gw-pki-backup.sh backup"
    echo "  4. umount /mnt/pki-backup-usb"
    echo "  5. Store USB securely — separate from this server"
    echo ""
    echo "Configuration (environment variables):"
    echo "  USB_MOUNT           USB mount point   (default: /mnt/pki-backup-usb)"
    echo "  PKI_BASE            PKI directory     (default: /etc/gateway/pki)"
    echo "  LOCAL_COPY_ENABLED  yes|no            (default: no)"
    echo "  LOCAL_ROOT_DIR      Local root backup (default: /opt/backups/pki-root)"
    echo "  LOCAL_TENANT_DIR    Local tenant dir  (default: /opt/backups/pki-tenants)"
    ;;
  *) die "Unknown command: ${1} — run gw-pki-backup.sh help" ;;
esac
