GW-Platform-RC3-Documentation
════════════════════════════════════════════════════════════════
Package:   GW-Platform-RC3-Documentation-<date>.zip
Version:   RC3.3
Role:      Reference documentation for the GW Platform RC3.3

CONTENTS
─────────
  RC3-Architecture.txt              Full system architecture — components,
                                    security model, PKI, SSH proxy, capacity
                                    model, known limitations

  RC3-Installation-Instructions.txt Step-by-step build guide — portal,
                                    GW nodes, PKI, tenant onboarding workflow

  RC3-Feature-Reference.txt         Feature inventory and CLI reference for
                                    all RC3.3 scripts and tools

  RC3-Runbook.txt                   Day-2 operations — tenant provisioning,
                                    promotion, PKI backup, cert delivery,
                                    monitoring, incident response

  RC3-Testing-Plan.txt              Test cases and acceptance criteria

  README-AdminPortal.txt            Installation README — Admin Portal package
  README-GWNode.txt                 Installation README — GW Node package
  README-Seed.txt                   Installation README — Seed package
  README-Complete.txt               Installation README — Complete package
  README-Documentation.txt          This file

INSTALLATION
─────────────
  No installation required. This package contains documentation only.
  Distribute to project stakeholders, operations team, and archive
  alongside the deployment record.

  Recommended storage locations:
    /opt/gw-admin-portal/docs/    On the Admin Portal node
    SharePoint / Confluence       Project document repository
    Alongside deployment record   Linked to ServiceNow change record

SEE ALSO
─────────
  RC3-Architecture.txt — start here for a full system overview
