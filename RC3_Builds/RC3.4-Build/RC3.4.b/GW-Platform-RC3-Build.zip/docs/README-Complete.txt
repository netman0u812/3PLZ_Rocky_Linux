GW-Platform-RC3-Complete
════════════════════════════════════════════════════════════════
Package:   GW-Platform-RC3-Complete-<date>.zip
Version:   RC3.3
Role:      Full platform package — Admin Portal + GW Node + Seed +
           Documentation in a single zip. Use for air-gapped installs
           or when distributing the full platform as a single artefact.

PREREQUISITES
─────────────
  See README-AdminPortal.txt and README-GWNode.txt for per-role
  prerequisites. The Complete package contains all components — install
  order is: Admin Portal first, then GW nodes.

CONTENTS
─────────
  All scripts, configs, docs, and seed structure from:
    GW-Platform-RC3-AdminPortal-<date>.zip
    GW-Platform-RC3-GWNode-<date>.zip
    GW-Platform-RC3-Seed-<date>.zip
    GW-Platform-RC3-Documentation-<date>.zip

INSTALLATION ORDER
───────────────────
  1. Admin Portal node
       See README-AdminPortal.txt — full installation procedure

  2. Seed population
       See README-Seed.txt — populate /opt/gw-seed/ and configure NFS

  3. GW nodes (one at a time)
       See README-GWNode.txt — repeat for each gateway node

  4. Per-tenant provisioning
       See RC3-Installation-Instructions.txt Step 5 onwards

POST-INSTALL VERIFICATION
──────────────────────────
  Run from Admin Portal after all nodes installed:

    gwreg status                        # Registry healthy
    gwreg node list                     # All GW nodes registered
    gw-seed-verify                      # Seed integrity OK
    chronyc tracking                    # Portal at Stratum 1
    connect <node> "chronyc tracking"   # Each node at Stratum 2
    gw-pki-backup.sh status             # Root CA backed up

UPGRADE
────────
  RC3.3 is the initial production release. No upgrade path from RC2.
  Full reinstall required for portal. GW nodes can be replaced
  individually via gwctl-promote without tenant downtime.

ROLLBACK
─────────
  See README-AdminPortal.txt and README-GWNode.txt for component-level
  rollback procedures. For a full platform rollback, restore from the
  registry backup and re-deploy GW nodes from seed.

RC3.4 OPTIONAL ADD-ON
──────────────────────
  mTLS client certificate delivery is available as a separate optional
  add-on package: GW-Platform-RC3.4-CertDeliver.zip
  Install AFTER the Complete package. See that package's README.txt
  for the single-command installation procedure.

SEE ALSO
─────────
  RC3-Architecture.txt              — start here for a full system overview
  RC3-Installation-Instructions.txt — detailed step-by-step build guide
  RC3-Runbook.txt                   — day-2 operations reference
