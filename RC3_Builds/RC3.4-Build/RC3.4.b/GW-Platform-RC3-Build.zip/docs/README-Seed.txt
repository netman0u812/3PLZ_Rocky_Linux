GW-Platform-RC3-Seed
════════════════════════════════════════════════════════════════
Package:   GW-Platform-RC3-Seed-<date>.zip
Version:   RC3.3
Role:      Seed structure — portal resilience, GW node bootstrap,
           offline rebuild capability

WHAT THIS PACKAGE IS
─────────────────────
  The Seed package provides the directory structure and source packages
  that live at /opt/gw-seed/ on the Admin Portal. GW nodes mount this
  via NFS (read-only) and maintain a local persistent copy.

  The seed is NOT a standalone installer. It is populated during portal
  initialization and updated continuously by gwreg and gwctl operations.

PREREQUISITES
─────────────
  Admin Portal must be installed (README-AdminPortal.txt) before the
  seed is meaningful. GW nodes require the seed to be populated before
  installation (Step 1 of README-GWNode.txt).

CONTENTS
─────────
  seed/packages/    Source zip packages + RC3-packages.sha256 checksums
  seed/registry/    Live registry DB snapshot (written per gwreg mutation)
  seed/portal/      Admin portal config and scripts
  seed/pki/         CA certificates and node certs (NO private keys)
  seed/manifests/   Latest rendered tenant manifests

INSTALLATION
─────────────
  Step 1 — Extract to portal
    unzip GW-Platform-RC3-Seed-<date>.zip -d /opt/gw-seed/

  Step 2 — Populate packages directory with source packages
    cp gw-registry-v0.1.1-RC1.zip       /opt/gw-seed/packages/
    cp gw-admin-portal-v0.2.2-RC3.zip   /opt/gw-seed/packages/
    cp gw-builder-v1.1.3-RC1.zip        /opt/gw-seed/packages/
    cp gw-builder-pki-tools-v1.1.1-RC1.zip /opt/gw-seed/packages/
    cp gw-perfmon-v0.1.0.zip            /opt/gw-seed/packages/
    cp gw-sshproxy-v0.1.2.zip           /opt/gw-seed/packages/
    cp gw-inspection-v0.1.1.zip         /opt/gw-seed/packages/
    cp gw-registry-v0.1.1-RC1.zip       /opt/gw-seed/packages/

  Step 3 — Generate checksums
    cd /opt/gw-seed/packages/
    sha256sum *.zip > RC3-packages.sha256

  Step 4 — Configure NFS export
    echo "/opt/gw-seed  <mgmt-subnet>/24(ro,no_subtree_check,no_root_squash)" \
      >> /etc/exports
    exportfs -ra

  Step 5 — Verify from a GW node
    mount -t nfs <portal-ip>:/opt/gw-seed /mnt/portal-shadow -o ro,soft,timeo=30
    gw-seed-verify

POST-INSTALL VERIFICATION
──────────────────────────
    gw-seed-verify                      # Checksums + registry DB readable
    exportfs -v                         # NFS export active
    ls /opt/gw-seed/packages/*.sha256   # Checksum file present

SECURITY NOTE
──────────────
  Private keys (*.key, *.pem private material) are NEVER placed in the seed.
  The seed is mounted read-only by GW nodes. If a GW node is compromised,
  the attacker gains access to CA certificates but NOT CA private keys.
  CA private keys are backed up separately via gw-pki-backup.sh to USB.

ROLLBACK
─────────
  Seed is rebuilt from source packages — no rollback needed.
  Registry snapshot is updated automatically per-write by gwreg-safe.
  In a portal loss event: gw-portal-redeploy --local (from GW node local copy).

SEE ALSO
─────────
  RC3-Architecture.txt section 4 — Seed Architecture (Resilience)
  README-AdminPortal.txt            — Portal installation
  README-GWNode.txt                 — GW node installation
