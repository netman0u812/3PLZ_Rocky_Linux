GW-Platform-RC3-AdminPortal
════════════════════════════════════════════════════════════════
Package:   GW-Platform-RC3-AdminPortal-<date>.zip
Version:   RC3.3
Role:      Admin Portal node — management plane, registry, PKI, bastion

PREREQUISITES
─────────────
  OS:        Rocky Linux 9 (minimal install)
  Hardware:  GPS receiver on /dev/ttyS0, PPS on /dev/pps0 (NTP source)
  Network:   Static IP on mgmt subnet, reachable from all GW nodes
  Prior:     None — this is the first node installed

  Required packages (installed by installer):
    dnf install -y sqlite python3 openssl nftables chrony nfs-utils \
                   rsync jq haproxy google-authenticator-libpam \
                   pam nfs-kernel-server

INSTALLATION
─────────────
  Step 1 — Extract package
    unzip GW-Platform-RC3-AdminPortal-<date>.zip -d /opt/gw-admin-portal/

  Step 2 — Run installer
    cd /opt/gw-admin-portal/
    bash install.sh

    The installer will:
      - Install required system packages
      - Configure nftables (portal ruleset)
      - Configure chronyd (GPS-PPS Stratum 1)
      - Configure NFS seed export
      - Enable systemd services: gw-registry, gw-admin-portal, chronyd, nfs-server

  Step 3 — Initialize registry
    gwreg init
    gwreg status

  Step 4 — Initialize PKI
    pki-bootstrap.sh init-root
    pki-bootstrap.sh init-platform

  Step 5 — Backup root CA keys (MANDATORY before proceeding)
    mount /dev/sdX1 /mnt/pki-backup-usb
    gw-pki-backup.sh backup-root
    umount /mnt/pki-backup-usb
    # Store USB off-server. Store passphrase separately.

  Step 6 — Enroll admin users (TOTP)
    gw-totp-setup.sh enroll <username>
    # QR code rendered to terminal — user scans with authenticator app

  Step 7 — Enroll GW node SSH host keys (after GW nodes are installed)
    adminctl enroll-gw-keys <gw-node-ip>

POST-INSTALL VERIFICATION
──────────────────────────
    gwreg status                        # Registry responding
    systemctl is-active gw-registry     # Service running
    systemctl is-active chronyd         # NTP running
    chronyc tracking                    # Confirm GPS lock (Stratum 1)
    exportfs -v                         # NFS seed export active
    nft list ruleset                    # nftables loaded
    gw-pki-backup.sh status             # Root CA backed up

UPGRADE
────────
  RC3.3 is the initial production release. No upgrade path from RC2.
  Full reinstall required. Registry data is preserved via seed backup.

ROLLBACK
─────────
  Registry: gwreg-rollback <minutes>
  Portal:   gw-portal-redeploy --local  (from local seed copy)
  CA keys:  gw-pki-backup.sh restore <backup-file>

SEE ALSO
─────────
  RC3-Installation-Instructions.txt — full step-by-step platform build
  RC3-Architecture.txt              — full system architecture
  RC3-Runbook.txt                   — day-2 operations
