GW-Platform-RC3-GWNode
════════════════════════════════════════════════════════════════
Package:   GW-Platform-RC3-GWNode-<date>.zip
Version:   RC3.3
Role:      Gateway node — IPsec termination, VRF/VXLAN tenant fabric,
           BGP peering, SSH proxy (optional per tenant)

PREREQUISITES
─────────────
  OS:        Rocky Linux 9 (minimal install)
  Hardware:  Two NICs — eth0 (WAN), eth1 (LAN/mgmt)
  Network:   Reachable from Admin Portal on mgmt subnet
  Prior:     Admin Portal must be installed and operational
             gwreg must have at least one GW node slot registered

  Required packages (installed by installer):
    dnf install -y strongswan frr nftables iproute jq sqlite \
                   python3 chrony nfs-utils rsync haproxy

INSTALLATION
─────────────
  Step 1 — Mount seed from Admin Portal
    mount -t nfs <portal-ip>:/opt/gw-seed /mnt/portal-shadow -o ro,soft,timeo=30,retrans=3

  Step 2 — Verify seed integrity
    gw-seed-verify

  Step 3 — Extract GWNode package from seed
    unzip /mnt/portal-shadow/packages/GW-Platform-RC3-GWNode-<date>.zip -d /opt/

  Step 4 — Run installer
    bash /opt/gw-node/install.sh

    The installer will:
      - Install required system packages
      - Configure nftables (GW node ruleset)
      - Configure chronyd (sync to Admin Portal, Stratum 2)
      - Configure NFS shadow mount + local seed rsync cron (every 5 min)
      - Enable systemd services: strongswan, frr, nftables, chronyd

  Step 5 — Register node in registry (run on Admin Portal)
    gwreg node add <node-hostname> --ip <node-ip> --role gateway

  Step 6 — Enroll SSH host keys (run on Admin Portal)
    adminctl enroll-gw-keys <node-ip>

  Step 7 — Apply initial manifest for any pre-existing tenants
    gw-manifest-push <manifest-file> <tenant>

POST-INSTALL VERIFICATION
──────────────────────────
    gwreg node show <hostname>          # Node registered in registry
    systemctl is-active strongswan      # IPsec service running
    systemctl is-active frr             # BGP service running
    systemctl is-active chronyd         # NTP running
    chronyc tracking                    # Confirm sync to portal (Stratum 2)
    gw-seed-verify                      # Seed integrity OK
    connect <node-hostname> "ip vrf show"  # VRF table visible (after tenant alloc)

UPGRADE
────────
  No in-place upgrade path in RC3.3.
  Procedure: register replacement node → migrate tenants via gwctl-promote
  → decommission old node via gwreg node remove.

ROLLBACK
─────────
  Manifest:  gw-manifest-push <previous-manifest> <tenant>
  Node:      gwctl-promote <tenant> --backup  (promote backup to primary)
  Full:      gw-portal-redeploy --target <node-ip> --user <admin-user>

SEE ALSO
─────────
  RC3-Installation-Instructions.txt — full step-by-step platform build
  RC3-Architecture.txt              — full system architecture
  RC3-Runbook.txt                   — day-2 operations
