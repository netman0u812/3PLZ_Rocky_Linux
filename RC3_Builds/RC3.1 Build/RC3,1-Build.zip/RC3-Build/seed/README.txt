GW PLATFORM RC3 — SEED STRUCTURE
==================================
Date: 2026-03-04
Deploy to /opt/gw-seed on Admin Console.
Rsynced every 5 minutes to /home/gw-seed on each GW node.

POPULATE AFTER PORTAL INIT (see Step 3 of RC3-Installation-Instructions.txt):
  sqlite3 /opt/gw-registry/data/registry.db ".backup '/opt/gw-seed/registry/registry.db'"
  cp -r /opt/gw-admin-portal/* /opt/gw-seed/portal/
  cp /etc/gateway/pki/ca.crt   /opt/gw-seed/pki/
  cp /etc/gateway/pki/*.crt    /opt/gw-seed/pki/   # node certs only
  cp *.zip *.sha256             /opt/gw-seed/packages/

SECURITY: Private keys (.key files) are NEVER included in the seed.
          gw-seed-sync excludes pki/*.key via rsync --exclude rule.
NFS export uses no_root_squash to allow root cron read access on GW nodes.
The export is read-only. No write path exists from GW nodes to the seed.
